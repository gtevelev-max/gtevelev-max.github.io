# Tube geometry and source charts

`tube-routing.js` consumes the output of `cut_to_planar.py`. It adds the missing collars as three-dimensional tubes, closes the single outer triangle underneath the plane, and retains a piecewise affine chart to every original quotient chamber. `positions` stores shared three-dimensional vertices; each `patches` entry stores its source chamber, its three vertex indices, and the three source barycentric coordinates.

The cut construction removes a collar of positive width: the two boundary copies lie at parameters .45 and .55 on each crossed edge; the original seam lies at .5. Each half of a tube maps affinely back to its half collar. The seam is included as an explicit cross-section. Boundary rings have the same source labels and origins, in reverse cyclic order. No extra source triangle is invented, and the source patches partition each original triangle.

The cap center lies strictly inside the kernel of its star-shaped boundary polygon. The tube radius is chosen as

`rho = .04 * minimum center separation`.

Each endpoint foot circle has radius `min(.2 * its own cap clearance, rho)`. The planar collar from the star-shaped polygon to that circle lies inside its removed cap. A conical transition above the plane widens the small foot to radius rho. This avoids making all handles as thin as the narrowest planar cap. Other cap polygons are disjoint, and the full flared stems lie in pairwise-disjoint radius-rho cylinders.

For M11, the builder first tries a straight horizontal center path, then deterministic two-segment paths through a displaced midpoint. Every segment is tested against every other stem center and must have clearance at least 3 rho. The angle at the intermediate point is at most 90 degrees. This reduces the M11 mesh to 681,878 refinement triangles with a maximum of 15 cross-sections per handle.

If no simple route works, it uses circular obstacle detours; A6 intentionally retains this deterministic route to reproduce the already verified mesh. A straight route approaching another stem center within 3 rho follows a polygonal arc of radius 8 rho instead. The obstacle centers are separated by at least 25 rho, so all these detour disks are disjoint. Other unencountered stems remain separated as well. The implementation computes the actual minimum distance from every route segment to every other stem center and requires that it exceed 2 rho, the sum of the tube radii.

Different horizontal tube paths lie at different heights, separated by at least 5 rho. Their closed radius-rho neighborhoods are therefore disjoint. These geometric inequalities certify the separation of different tubes. The tube mesh uses transported cross-section frames and adaptive subdivisions that limit each ring-to-ring angular advance to pi/3. The original seam uses an existing cross-section, avoiding short segments immediately before a bend. Every segment must have length greater than `rho * (tan(turn_at_start/2) + tan(turn_at_end/2))`, so neighboring miter planes cannot overlap. It also needs a separate local triangle-intersection check to certify that its individual ruled strips do not fold through one another near a bend; manifoldness or Euler characteristic alone does not establish this.

The original outer triangle is replaced by a three-triangle cone below the plane. Its barycentric subdivision leaves its source chamber unchanged. All other planar triangles lie in the opposite closed half-space, and tubes lie above it.

The generator verifies two oppositely oriented faces at every edge, the expected Euler characteristic, positive source-patch areas, and that the sum of those areas is exactly one original triangle to floating precision. It outputs tube centerlines, radii, endpoint centers, patch index ranges, obstacle clearances, and height separation for independent verification and handle-focused display.

## Reproduction

Run `node tube-routing.js a6-planar.json a6-tubes.json` or the corresponding command for `m11`. The input ID selects the verified A6 circular-detour route or the compact M11 two-segment route. The builder requires no npm packages. The optional adjacent `../quotient-data/<id>.json` is used to verify every transition between source chambers against the exact original neighbor table.

A6 mesh SHA-256: `3c729ed023a3ef07092037f931dd989eae4427293c32fe1acd27122adbc5ce25`. M11 mesh SHA-256: `f57c160430a446bf0dc740322c4a69ed36a9c8ac2280bac88fae4663264470fa`.

The A6 independent audit checks all 720 source-chamber disks and 321,856 candidate pairs of local tube triangles and finds no excess intersection. The M11 independent audit checks all 15,840 source-chamber disks and 35,594,186 candidate pairs, resolves 19,944 ill-conditioned candidates with exact rational predicates, and finds no excess intersection. The maximum source-area errors are 2.22e-16 and 3.33e-16, respectively. These geometric audits are additional to the topology and source-chart checks; the report files are included alongside this document.
