#!/usr/bin/env python3
"""Reproduce the exact Macbeath embedding in original quotient vertex IDs.

Usage: python3 research-build-macbeath.py [D2|D3|S2]
Requires only the Python standard library. The shared exact-intersection checker
is maintained in ../surface-embedding/build_klein_embedding.py.
"""
import importlib.util
import json
import sys
from collections import defaultdict, deque
from fractions import Fraction as Q
from pathlib import Path

ROOT = Path(__file__).resolve().parent
s = importlib.util.spec_from_file_location('exact_geometry', ROOT.parent/'surface-embedding'/'build_klein_embedding.py')
checker = importlib.util.module_from_spec(s)
s.loader.exec_module(checker)


def main():
    symmetry = sys.argv[1] if len(sys.argv) > 1 else 'D2'
    lines = (ROOT / ('research-macbeath-' + symmetry + '.obj')).read_text().splitlines()
    v = [[Q(x) for x in l.split()[1:]] for l in lines if l.startswith('v ')]
    f = [[int(x.split('/')[0])-1 for x in l.split()[1:]] for l in lines if l.startswith('f ')]
    assert len(v) == 72 and len(f) == 168 and all(len(t) == 3 for t in f)
    checks = checker.verify_embedding(v, f)
    edges = sorted({tuple(sorted((t[i], t[(i+1)%3]))) for t in f for i in range(3)})
    assert len(edges) == 252
    eids = {e:i for i,e in enumerate(edges)}
    # Types: edge midpoint (order 2), face center (order 3), vertex (order 7).
    positions = [tuple((v[a][k]+v[b][k])/2 for k in range(3)) for a,b in edges]
    positions += [tuple(sum(v[a][k] for a in t)/3 for k in range(3)) for t in f]
    positions += [tuple(p) for p in v]
    flags = []
    for j,t in enumerate(f):
        for i in range(3):
            a,b = t[i],t[(i+1)%3]
            e = eids[tuple(sorted((a,b)))]
            flags += [(e,252+j,420+a),(e,252+j,420+b)]
    incidences = defaultdict(list)
    for j,flag in enumerate(flags):
        for side in range(3):
            incidences[tuple(flag[k] for k in range(3) if k != side)].append((j,side))
    assert len(incidences) == 1512
    neighbors = [[None]*3 for _ in flags]
    for values in incidences.values():
        assert len(values) == 2
        (i,s),(j,t) = values
        assert s == t
        neighbors[i][s],neighbors[j][s] = j,i
    data = json.loads((ROOT.parent/'quotient-data'/'macbeath.json').read_text())
    face_map, vertex_map, queue = {0:0}, {}, deque([0])
    while queue:
        i = queue.popleft()
        j = face_map[i]
        for a,b in zip(data['faceVertices'][i],flags[j]):
            assert a not in vertex_map or vertex_map[a] == b
            vertex_map[a] = b
        for s in range(3):
            a,b = data['neighbors'][i][s],neighbors[j][s]
            if a in face_map: assert face_map[a] == b
            else: face_map[a] = b; queue.append(a)
    assert len(face_map) == len(set(face_map.values())) == 1008
    assert len(vertex_map) == len(set(vertex_map.values())) == 492
    original_positions = [positions[vertex_map[i]] for i in range(492)]
    reverse = {b:a for a,b in vertex_map.items()}
    # Positivity of 1/2 and 1/3 barycentric weights proves the small triangles
    # subdivide each original face without introducing any new intersection.
    chamber_f = [flags[face_map[i]][1]-252 for i in range(1008)]
    assert all(chamber_f.count(j) == 6 for j in range(168))
    out = {
        'id':'macbeath',
        'title':'Fricke–Macbeath surface — Bokowski–CodeParade polyhedral embedding',
        'description':'An embedded topological genus-7 surface. Its 168 larger triangular faces are barycentrically subdivided into the exact 1008 original quotient chambers. Euclidean lengths and angles do not represent its intrinsic hyperbolic metric.',
        'positions':[[float(x) for x in p] for p in original_positions],
        'coarseFaces':[[reverse[420+i] for i in t] for t in f],
        'coarseFaceForChamber':chamber_f,
        'sourceVertices':[[str(x) for x in p] for p in v],
        'sourceFaces':f,
        'quotientVertexToSourceBarycentricVertex':[vertex_map[i] for i in range(492)],
        'quotientChamberToSourceFlag':[face_map[i] for i in range(1008)],
        'sources':[
            {'title':'Bokowski and Kevin H. (2025), Polyhedral Embeddings of Triangular Regular Maps, §5.7 and Appendix A','url':'https://doi.org/10.3390/sym17040622'},
            {'title':'CodeParade, public numerical R7.1_' + symmetry + ' OBJ data','url':'http://codeparade.net/embeddings/models/R7.1_' + symmetry + '.obj'},
            {'title':'Bokowski and Cuntz (2018), Hurwitz’s regular map (3,7) of genus 7: a polyhedral realization','url':'https://doi.org/10.26493/2590-9770.1186.258'}
        ],
        'verification':{
            'coarseVertexCount':72, 'coarseEdgeCount':252, 'coarseFaceCount':168,
            'vertexCount':492, 'edgeCount':1512, 'chamberCount':1008, 'euler':-12, 'genus':7,
            'sideLabeledChamberGraphIsomorphism':True,
            'exactRationalCoarseTrianglePairIntersectionChecks':checks,
            'extraneousTriangleIntersections':0,
            'allSmallTrianglesArePositiveBarycentricSubdivisions':True,
            'allSharedEdgesAndVerticesCoincide':True,
            'displayedEuclideanSymmetry':symmetry
        }
    }
    (ROOT/'macbeath-embedding.json').write_text(json.dumps(out,separators=(',',':'))+'\n')
    print(json.dumps(out['verification'],indent=2))

if __name__ == '__main__': main()
