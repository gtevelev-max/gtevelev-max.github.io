/* Check that explanatory outlines are actual sheet/handle interfaces. */
'use strict';
const fs=require('fs'),path=require('path'),assert=require('assert');
const root=path.resolve(__dirname,'../../github-homepage/triangle-quotients');
global.window=global;
require(path.join(root,'refined-model.js'));
const manifest=JSON.parse(fs.readFileSync(path.join(root,'surface-data/manifest.json')));
const key=(a,b,n)=>Math.min(a,b)*n+Math.max(a,b);
const close=(a,b)=>a.length===b.length&&a.every((x,j)=>Math.abs(x-b[j])<1e-12);

(async()=>{
 for(const id of process.argv.slice(2).length?process.argv.slice(2):['klein','a6','macbeath','m11']){
  for(const file of manifest[id].files)require(path.join(root,file));
  const data=JSON.parse(fs.readFileSync(path.join(__dirname,'../quotient-data',id+'.json')));
  const raw=await RefinedSurfaceModel.load(id),m=RefinedSurfaceModel.build(data,raw);
  const {vertices,chambers,bary,nv,nf}=raw,counts=[0,0,0],rimEdges=new Map(),baseEdges=new Map();
  assert(m.parts instanceof Float32Array);
  assert.equal(m.parts.length,nf);
  assert.equal(m.handles.length,m.genus);
  assert.equal(m.underside.patchEnd-m.underside.patchStart,3);
  assert.equal(m.underside.chamber,0);
  for(let p=0;p<nf;p++){
   const part=m.parts[p];assert(Number.isInteger(part)&&part>=-1&&part<=m.genus);
   counts[part<0?2:part>0?1:0]++;
   if(part<0){assert(p>=m.underside.patchStart&&p<m.underside.patchEnd);assert.equal(chambers[p],0);}
   if(part>0){const h=m.handles[part-1];assert(p>=h.patchStart&&p<h.patchEnd);}
   if(part>0)continue;
   for(let k=0;k<3;k++){
    const a=vertices[3*p+k],b=vertices[3*p+(k+1)%3],e=key(a,b,nv);
    let entry=baseEdges.get(e);if(!entry){entry={sheet:0,tube:0,cap:0};baseEdges.set(e,entry);}
    if(part<0)entry.cap++;else entry.sheet++;
    entry.basePatch=p;
   }
  }
  assert.equal(counts[2],3);assert.equal(counts.reduce((a,b)=>a+b,0),nf);
  assert.equal(counts[1],m.handles.reduce((n,h)=>n+h.patchEnd-h.patchStart,0));
  // Every component occurring in each original chamber must be recoverable
  // from that chamber's source chart, including chambers spanning the base
  // and one or several different handles. Use one strict patch interior per
  // chamber/component pair rather than repeatedly testing the same part.
  let sourcePartSamples=0;
  for(let f=0;f<m.byFace.length;f++){
   const seen=new Set();
   for(const p of m.byFace[f]){
    const part=m.parts[p];if(seen.has(part))continue;seen.add(part);
    const w=[0,1,2].map(j=>(bary[9*p+j]+bary[9*p+3+j]+bary[9*p+6+j])/3);
    assert.equal(m.partAt(f,w),part,`${id}: source chart gives the wrong surface component`);sourcePartSamples++;
   }
  }
  let rimCount=0;
  for(const [h,tube] of m.handles.entries()){
   assert.equal(tube.attachments.length,2);
   for(const [end,attachment] of tube.attachments.entries()){
    rimCount++;const rim=attachment.rim;assert(rim.length>=3);
    assert(close(attachment.center,[...tube.endpointCenters[end],0]));
    const used=new Set();
    for(let i=0;i<rim.length;i++){
     const edge=rim[i],next=rim[(i+1)%rim.length];
     assert.equal(edge.b.v,next.a.v,`${id}: attachment rim does not close`);
     assert(close(edge.b.to,next.a.to));assert(!used.has(edge.a.v));used.add(edge.a.v);
     assert.notEqual(edge.a.v,edge.b.v);assert.equal(edge.a.to[2],0);assert.equal(edge.b.to[2],0);
     for(const point of [edge.a,edge.b]){
      assert(close(point.to,m.pos(point.v)));assert(Math.abs(point.w.reduce((a,b)=>a+b)-1)<1e-12);
      assert(point.w.every(w=>w>=-1e-12&&w<=1+1e-12));
     }
     const e=key(edge.a.v,edge.b.v,nv);assert(!rimEdges.has(e));rimEdges.set(e,{h,edge});
     const incident=baseEdges.get(e);assert(incident,`${id}: rim is not on the base surface`);
     assert.equal(incident.sheet+incident.cap,1);const p=incident.basePatch;assert.equal(chambers[p],edge.f);
     for(const point of [edge.a,edge.b]){
      const k=[0,1,2].find(k=>vertices[3*p+k]===point.v);assert(k!==undefined);
      assert(close(point.w,Array.from(bary.subarray(9*p+3*k,9*p+3*k+3))),`${id}: attachment chart mismatch`);
     }
    }
   }
  }
  // Scan all tube faces, independently finding every base/tube interface.
  // The base includes the closing cap: a rim may meet the cap along one of
  // its outer edges when the removed outer source patch borders that hole.
  // Every claimed rim must have one base face and its designated tube face.
  for(let p=0;p<nf;p++){
   const part=m.parts[p];if(part<=0)continue;
   for(let k=0;k<3;k++){
    const a=vertices[3*p+k],b=vertices[3*p+(k+1)%3],e=key(a,b,nv),entry=baseEdges.get(e);
    if(!entry)continue;
    {
     entry.tube++;const rim=rimEdges.get(e);assert(rim,`${id}: unmarked base/handle attachment`);
     assert.equal(rim.h+1,part);assert.equal(rim.edge.f,chambers[p]);
     for(const point of [rim.edge.a,rim.edge.b]){
      const j=[0,1,2].find(j=>vertices[3*p+j]===point.v);assert(j!==undefined);
      assert(close(point.w,Array.from(bary.subarray(9*p+3*j,9*p+3*j+3))));
     }
    }
   }
  }
  let capSeamEdges=0,capToHandleSeamEdges=0,verifiedRimSegments=0;
  for(const [e,entry] of baseEdges){
   assert.equal(entry.sheet+entry.tube+entry.cap,2,`${id}: open/nonmanifold component seam`);
   if(rimEdges.has(e)){assert.equal(entry.sheet+entry.cap,1);assert.equal(entry.tube,1);verifiedRimSegments++;}
   else{assert.equal(entry.sheet+entry.cap,2);assert.equal(entry.tube,0);}
   if(entry.cap===1){capSeamEdges++;if(entry.tube)capToHandleSeamEdges++;}
  }
  assert.equal(rimCount,2*m.genus);assert.equal(verifiedRimSegments,rimEdges.size);assert.equal(capSeamEdges,3);
  console.log(JSON.stringify({id,genus:m.genus,patches:nf,upperSheetPatches:counts[0],handlePatches:counts[1],undersidePatches:counts[2],undersideChamber:m.underside.chamber,sourcePartSamples,attachmentRims:rimCount,verifiedRimSegments,capSeamEdges,capToHandleSeamEdges,allComponentInterfacesVerified:true,allAttachmentSourceChartsMatch:true}));
 }
})().catch(e=>{console.error(e);process.exitCode=1;});
