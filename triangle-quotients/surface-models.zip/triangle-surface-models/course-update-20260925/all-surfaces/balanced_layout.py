"""Save/replay optimized coordinates without changing any source chart."""
import gzip,hashlib,json,pathlib,sys
ROOT=pathlib.Path(__file__).resolve().parent
FILE=ROOT/'balanced-planar-layouts.json.gz'

def signature(d):
    holes=[{k:v for k,v in h.items() if k!='center'} for h in d['holes']]
    content=[d['id'],d['genus'],d['patches'],d['outerFacePatch'],holes]
    return hashlib.sha256(json.dumps(content,sort_keys=True,separators=(',',':')).encode()).hexdigest()

if sys.argv[1]=='--record':
    layouts={}
    for name in sys.argv[2:]:
        d=json.loads(pathlib.Path(name).read_text())
        layouts[d['id']]={'sourceChartSHA256':signature(d),'positions':d['positions'],'metadata':{k:d[k] for k in ['redistribution','areaRedistribution'] if k in d}}
    FILE.write_bytes(gzip.compress(json.dumps(layouts,separators=(',',':')).encode(),compresslevel=9,mtime=0))
    print('Recorded',list(layouts),'in',FILE)
else:
    d=json.loads(pathlib.Path(sys.argv[1]).read_text());layouts=json.loads(gzip.decompress(FILE.read_bytes()));item=layouts[d['id']]
    assert signature(d)==item['sourceChartSHA256'],'The source charts differ from the certified cut surface'
    assert len(d['positions'])==len(item['positions'])
    d['positions']=item['positions'];d.update(item['metadata'])
    for h in d['holes']:h['center']=d['positions'][h['centerVertex']]
    pathlib.Path(sys.argv[2]).write_text(json.dumps(d,separators=(',',':')))
    print('Restored checked coordinates for',d['id'])
