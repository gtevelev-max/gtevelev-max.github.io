"""Sparse Voronoi graph for tube routing between planar hole centers."""
import json,sys,pathlib,numpy as np
from scipy.spatial import Voronoi
p=sys.argv[1];d=json.load(open(p));c=np.array([h['center'] for h in d['holes']]);n=len(c);lo=c.min(axis=0);hi=c.max(axis=0);mid=(lo+hi)/2;span=max(hi-lo)
a=np.arange(16)*2*np.pi/16;ghost=mid+.8*span*np.c_[np.cos(a),np.sin(a)];v=Voronoi(np.r_[c,ghost]);edges=[e for e in v.ridge_vertices if len(e)==2 and min(e)>=0];nodes=[v.regions[v.point_region[i]] for i in range(n)];assert all(min(x)>=0 for x in nodes)
result={'vertices':v.vertices.tolist(),'edges':edges,'endpointNodes':nodes,'source':pathlib.Path(p).name,'ghostRadiusFactor':.8,'holeCenters':c.tolist()}
out=sys.argv[2] if len(sys.argv)>2 else p.replace('.json','-routes.json');json.dump(result,open(out,'w'),separators=(',',':'));print(len(result['vertices']),'routing vertices,',len(edges),'edges;',out)
