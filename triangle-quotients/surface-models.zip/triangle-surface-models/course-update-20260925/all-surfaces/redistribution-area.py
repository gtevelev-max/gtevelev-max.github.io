#!/usr/bin/env python3
"""Strictly orientation-preserving hole-area optimization of a planar cut surface."""
import json,sys,time,os
import numpy as np

def optimize(data,iterations=3000,weight=.003,capfraction=.8):
 weight=float(os.environ.get('AREA_SHAPE_WEIGHT',weight))
 n=len(data['positions']);outer=np.array(data['outerFacePatch']['vertices']); active=np.ones(n,bool);active[outer]=False
 faces=[p['vertices'] for p in data['patches']]; nb=len(faces); targets=[(1-capfraction)/nb]*nb; theta=[np.pi/3]*nb
 for h in data['holes']:
  vs=h['vertices']; m=len(vs);c=h['centerVertex']
  faces.extend([[c,vs[(i+1)%m],vs[i]] for i in range(m)]);targets.extend([capfraction/(len(data['holes'])*m)]*m);theta.extend([2*np.pi/m]*m)
 F=np.array(faces,np.int32); T=np.array(targets); cost=np.cos(theta);sint=np.sin(theta)
 p=np.array(data['positions'],float);p-=p[outer[0]];p/=np.ptp(p,axis=0).max()
 if np.linalg.det(np.stack([p[F[0,1]]-p[F[0,0]],p[F[0,2]]-p[F[0,0]]]))<0:p[:,1]*=-1
 x=p[active].ravel(); fixed=p.copy()
 precondition=None
 if os.environ.get('AREA_PRECONDITION'):
  from scipy.sparse import coo_matrix
  from scipy.sparse.linalg import factorized
  edges=np.vstack([F[:,[0,1]],F[:,[1,2]],F[:,[2,0]]])
  def makeprecondition(p):
   w=np.ones(len(edges))
   if os.environ.get('AREA_WEIGHTED'):
    aa=p[F[:,1]]-p[F[:,0]];bb=p[F[:,2]]-p[F[:,0]];areas=aa[:,0]*bb[:,1]-aa[:,1]*bb[:,0]
    w=np.tile(T/areas,3)
   ii=np.r_[edges[:,0],edges[:,1]];jj=np.r_[edges[:,1],edges[:,0]]; ww=np.r_[w,w]
   degree=np.bincount(ii,weights=ww,minlength=n)
   L=coo_matrix((np.r_[degree,-ww],(np.r_[np.arange(n),ii],np.r_[np.arange(n),jj])),shape=(n,n)).tocsr()[active][:,active].tocsc()
   solve=factorized(L)
   return lambda q:solve(q.reshape(-1,2)).ravel()
  precondition=makeprecondition(p)
 def unpack(x):
  p=fixed.copy();p[active]=x.reshape(-1,2);return p
 def area(p):
  a=p[F[:,1]]-p[F[:,0]];b=p[F[:,2]]-p[F[:,0]]
  return a[:,0]*b[:,1]-a[:,1]*b[:,0],a,b
 def fun(x):
  p=unpack(x);A,a,b=area(p)
  if min(A)<=0:return np.inf,None
  N=np.sum(a*a+b*b-2*cost[:,None]*a*b,axis=1)/sint
  en=np.sum(T*(-np.log(A)+weight*N/A))
  dA=-T*(1/A+weight*N/A**2);dN=T*weight/A
  ga=dA[:,None]*np.stack([b[:,1],-b[:,0]],axis=1)+dN[:,None]*2*(a-cost[:,None]*b)/sint[:,None]
  gb=dA[:,None]*np.stack([-a[:,1],a[:,0]],axis=1)+dN[:,None]*2*(b-cost[:,None]*a)/sint[:,None]
  grad=np.zeros((n,2))
  for k,g in [(0,-ga-gb),(1,ga),(2,gb)]:
   for j in range(2):grad[:,j]+=np.bincount(F[:,k],weights=g[:,j],minlength=n)
  return en,grad[active].ravel()
 def stepbound(x,d):
  p=unpack(x); dp=np.zeros((n,2));dp[active]=d.reshape(-1,2)
  A,a,b=area(p);D,da,db=area(dp)
  B=a[:,0]*db[:,1]+da[:,0]*b[:,1]-a[:,1]*db[:,0]-da[:,1]*b[:,0]
  discr=B*B-4*D*A;valid=discr>0
  # Cancellation-safe quadratic roots.
  q=-.5*(B[valid]+np.copysign(np.sqrt(discr[valid]),B[valid]))
  roots=np.r_[np.divide(q,D[valid],out=np.full(len(q),np.inf),where=D[valid]!=0),np.divide(A[valid],q,out=np.full(len(q),np.inf),where=q!=0)]
  roots=roots[roots>0]
  return min(1.,.8*min(roots,default=np.inf))
 def report(k,e,g):
  p=unpack(x); A,_,_=area(p);offset=nb; aa=[]; rad=[]
  for h in data['holes']:
   m=len(h['vertices']);aa.append(float(sum(A[offset:offset+m])/2));offset+=m
   vs=p[h['vertices']];c=p[h['centerVertex']];d=np.roll(vs,-1,axis=0)-vs;t=np.clip(np.sum((c-vs)*d,axis=1)/np.sum(d*d,axis=1),0,1);rad.append(float(np.min(np.linalg.norm(vs+t[:,None]*d-c,axis=1))))
  print('area',k,'energy',e,'gradient',np.linalg.norm(g),'hole clearance',min(rad),np.median(rad),max(rad),'hole area',min(aa),np.median(aa),max(aa),flush=True)
  return dict(minimumHoleClearance=min(rad),medianHoleClearance=float(np.median(rad)),maximumHoleClearance=max(rad),minimumHoleArea=min(aa),medianHoleArea=float(np.median(aa)),maximumHoleArea=max(aa),minimumTriangleArea=float(min(A)/2),span=float(np.ptp(p,axis=0).max()),energy=e)
 e,g=fun(x);history=[];t0=time.time()
 for k in range(iterations):
  if k%100==0:
   report(k,e,g)
   if os.environ.get('AREA_CHECKPOINT'):
    dd=dict(data);dd['positions']=unpack(x).tolist()
    for h in dd['holes']:h['center']=dd['positions'][h['centerVertex']]
    json.dump(dd,open(os.environ['AREA_CHECKPOINT'],'w'),separators=(',',':'))
  if k and k%50==0 and os.environ.get('AREA_REFRESH'):precondition=makeprecondition(unpack(x))
  q=g.copy();alpha=[]
  diagonal=None
  if os.environ.get('AREA_DIAGONAL'):
   Ap,ap,bp=area(unpack(x))
   stiffness=T*(np.sum(ap*ap+bp*bp,axis=1))/(Ap*Ap)
   diag=np.zeros(n)
   for corner in range(3):diag+=np.bincount(F[:,corner],weights=stiffness,minlength=n)
   diagonal=np.repeat(1/diag[active],2)
  for s,y,rho in reversed(history):
   aa=rho*np.dot(s,q);alpha.append(aa);q-=aa*y
  if diagonal is not None:
   q*=diagonal
   if history:
    s,y,rho=history[-1];q*=np.dot(s,y)/np.dot(y,diagonal*y)
  elif precondition:
   q=precondition(q)
   if history:
    s,y,rho=history[-1];q*=np.dot(s,y)/np.dot(y,precondition(y))
   else:q*=1/max(1,np.linalg.norm(g))
  elif history:
   s,y,rho=history[-1];q*=np.dot(s,y)/np.dot(y,y)
  else:q*=1/max(1,np.linalg.norm(g))
  for (s,y,rho),aa in zip(history,reversed(alpha)):q+=s*(aa-rho*np.dot(y,q))
  d=-q;dg=np.dot(d,g)
  if dg>=0:history=[];d=-g;dg=-np.dot(g,g)
  step=stepbound(x,d)
  for search in range(50):
   xe=x+step*d;ee,gg=fun(xe)
   if ee<=e+1e-4*step*dg:break
   step*=.5
  else:print('line search failed');break
  s=xe-x;y=gg-g;sy=np.dot(s,y)
  if sy>1e-20:
   history.append((s,y,1/sy));history=history[-25:]
  x,e,g=xe,ee,gg
  if np.linalg.norm(s)<1e-14:print('tiny step',k);break
 p=unpack(x);reportdata=report(k+1,e,g);reportdata.update(iterations=k+1,seconds=time.time()-t0,method='Positive area barrier plus circular-hole shape optimization',capTargetFraction=capfraction,shapeWeight=weight)
 data['positions']=p.tolist()
 for h in data['holes']:h['center']=data['positions'][h['centerVertex']]
 data['areaRedistribution']=reportdata
 return data

if __name__=='__main__':
 data=json.load(open(sys.argv[1]));result=optimize(data,int(sys.argv[3]) if len(sys.argv)>3 else 3000)
 json.dump(result,open(sys.argv[2],'w'),separators=(',',':'))
