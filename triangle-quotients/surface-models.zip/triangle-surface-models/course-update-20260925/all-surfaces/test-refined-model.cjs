/* Browser chart adapter checks, independent of the mesh builder. */
const fs=require('fs'),path=require('path'),assert=require('assert');
const root=path.resolve(__dirname,'../../github-homepage/triangle-quotients');
global.window=global;
require(path.join(root,'refined-model.js'));
const manifest=JSON.parse(fs.readFileSync(path.join(root,'surface-data/manifest.json')));
const norm=a=>Math.hypot(...a),sub=(a,b)=>a.map((x,i)=>x-b[i]);
(async()=>{
 for(const id of process.argv.slice(2).length?process.argv.slice(2):Object.keys(manifest)){
  for(const file of manifest[id].files)require(path.join(root,file));
  const data=JSON.parse(fs.readFileSync(path.join(__dirname,'../quotient-data',id+'.json'))),raw=await RefinedSurfaceModel.load(id),m=RefinedSurfaceModel.build(data,raw);
  let maxSampleError=0,maxEdgeError=0,maxWalkError=0;
  // Check every drawing triangle's center maps to its own 3D center.
  for(let p=0;p<raw.nf;p++){
   const w=[0,1,2].map(j=>(raw.bary[9*p+j]+raw.bary[9*p+3+j]+raw.bary[9*p+6+j])/3);
   const xyz=[0,1,2].map(j=>(raw.positions[3*raw.vertices[3*p]+j]+raw.positions[3*raw.vertices[3*p+1]+j]+raw.positions[3*raw.vertices[3*p+2]+j])/3);
   maxSampleError=Math.max(maxSampleError,norm(sub(m.sample(raw.chambers[p],w),xyz)));
  }
  // Both copies of every original edge must describe exactly the same polyline.
  for(let f=0;f<data.counts.triangles;f++)for(let side=0;side<3;side++){
   const other=data.neighbors[f][side];if(f>other)continue;
   const a=m.boundaries[f][side],b=m.boundaries[other][side];assert.equal(a.length,b.length,`${id}: different subdivision of edge ${f}/${side}`);
   for(let i=0;i<a.length;i++)maxEdgeError=Math.max(maxEdgeError,norm(sub(a[i].to,b[i].to)));
  }
  // Source-segment subdivision must remain on the piecewise-linear surface.
  const sampleFaces=[0,Math.floor(data.counts.triangles/3),data.counts.triangles-1];
  for(const f of sampleFaces)for(let side=0;side<3;side++){
   const w=[.5,.5,.5];w[side]=0;const points=m.path(f,[1/3,1/3,1/3],w);
   for(let i=1;i<points.length;i++){
    const middle=points[i].w.map((x,j)=>(x+points[i-1].w[j])/2),target=points[i].to.map((x,j)=>(x+points[i-1].to[j])/2);
    maxWalkError=Math.max(maxWalkError,norm(sub(m.sample(f,middle),target)));
   }
  }
  assert(maxEdgeError<1e-8,`${id}: edge mismatch ${maxEdgeError}`);
  assert(maxSampleError/m.radius<1e-7,`${id}: chart sample error ${maxSampleError}`);
  assert(maxWalkError/m.radius<1e-7,`${id}: walk leaves surface ${maxWalkError}`);
  console.log(id,JSON.stringify({patches:raw.nf,originalChambers:data.counts.triangles,maxSampleError,maxEdgeError,maxWalkError,genus:m.genus}));
 }
})().catch(e=>{console.error(e);process.exitCode=1;});
