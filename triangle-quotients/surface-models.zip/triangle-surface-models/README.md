# Triangle-group surfaces: numerical models and reproducible checks

This download contains the actual quotient chamber complexes and their embedded surface models used by the [interactive demonstration](https://gtevelev-max.github.io/triangle-quotients/).

The Klein quartic endpoint is the non-self-intersecting Schulte–Wills polyhedron, with its 56 faces divided into the **336 original quotient chambers**. Every face and side is matched to the supplied PSL(2,7) quotient. It has 164 vertices and 504 edges, so its Euler characteristic is −4 and its genus is 3. Exact rational tests inspect every pair of its 336 triangles.

The A4, S4, and A5 quotients are modeled on a sphere. The (2,3,6) quotient is modeled on a torus using the primitive translation lattice of the actual kernel. Curved surface patches may be sampled with extra drawing triangles; those rendering patches do not change the original chamber count or incidence data. No 3D embedding is asserted here for A6, the Fricke–Macbeath surface, or M11; their exact quotient and cut-open data are included for reference.

These models preserve the topology and chamber incidence, not the hyperbolic metric. The Klein model has tetrahedral symmetry; all 168 automorphisms need not be rigid motions in 3D. The assembly animation can pass through intermediate self-intersections; its final Klein endpoint is embedded.

## Run all verification checks

Install Python 3 and Node.js, then run from this extracted directory:

```sh
python3 verify.py
```

No npm or Python packages, network connection, or browser are required. The script rebuilds the Klein embedding and checks all 56,280 chamber pairs exactly, verifies spherical/torus identified sides and lattice area, and checks the cut-open disk and paired boundaries for all eight examples. Individual commands:

```sh
python3 surface-embedding/build_klein_embedding.py
node surface-embedding/test-sphere-torus.js
node quotient-data/test_cut_net.js
```

To regenerate the original group/quotient data, consult `quotient-data/README.md`; the generator is included. That full regeneration is separate from the quick model verification above.

## Files

- `surface-embedding/`: coordinate data, exact Klein builder, independent sphere/torus model, tests, detailed mathematical documentation and sources.
- `quotient-data/`: all eight exact quotient incidence tables, generator, cut-open net and its test.
- `viewer/`: the display geometry and surface renderer for inspection. This is source code, not a standalone webpage; use the linked online demonstration for the full UI.

The coordinate construction is credited to Egon Schulte and Jörg M. Wills (1985), with integer coordinate/incidence data provided by David I. McCooey. Full citations are in `surface-embedding/README.md` and `klein-embedding.json`.
