# Faithful spherical and torus chamber models

`sphere-torus-models.js` is independent of the app UI. It requires the existing `TriangleMath` module and exact quotient chamber data. It supports the four sphere/torus examples and returns `null` for unsupported examples.

```js
const model = QuotientSurfaceModels.build(data, TriangleMath);
const p = model.sample(faceId, [w0, w1, w2]); // barycentric weights
const normal = model.normal(faceId, [w0, w1, w2]);
const triangles = QuotientSurfaceModels.refinement(8); // 64 drawing patches/chamber
```

Every drawing patch retains its original chamber ID. Refinement is a way to draw curved triangular patches, **not a change to the stated triangulation**. Stroke only the three original sides (one weight zero), using sufficiently many samples. The barycentric coordinates also give the matching position in the cut-open layout, allowing an animation between the cut disk and the closed surface.

## Sphere

Develop all chambers by the supplied side reflections. Spherical examples here have trivial kernel, so all appearances of a quotient vertex agree exactly up to floating-point error. The module checks that agreement, shares the resulting vertex coordinates, and normalizes the barycentric interpolation. Edges are great-circle arcs; the patches form the actual spherical chamber triangulation.

## Torus

Develop the 12 chambers using the adjacency graph. Every alternative route to an adjacent chamber differs by a translation in the kernel. Collect these translations, choose an independent pair of minimum positive determinant, and check that every recorded translation is an integral combination of that pair. Also check that its area is exactly 12 times the original triangle area. These checks establish a primitive basis of the actual kernel lattice, rather than an arbitrary torus parameterization.

Map the resulting lattice coordinates `(u,v)` to the standard embedded torus:

`((R+r cos 2πv) cos 2πu, (R+r cos 2πv) sin 2πu, r sin 2πv)`.

This is a homeomorphism of the exact flat quotient to a topological torus, not an isometry. Every original chamber and side is retained, including distinct edges that have the same endpoint pair. The six quotient vertices, 18 original edges, and 12 chambers must continue to be reported as those counts.

The checks sample every identified side and compare its two copies in 3D. Maximum observed mismatch is below `2e-15`.

Run `node surface-embedding/test-sphere-torus.js` from the project root. No npm packages are required.
