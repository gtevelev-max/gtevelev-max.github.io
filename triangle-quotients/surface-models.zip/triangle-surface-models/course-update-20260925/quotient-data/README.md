# Exact triangle-quotient data

These files describe finite quotients of the **orientation-preserving** triangle group

\[
\Delta(p,q,r)=\langle x,y,z\mid x^p=y^q=z^r=xyz=1\rangle.
\]

Here `z=(xy)^-1`, and permutation products act on points rightmost first. Each dataset includes explicit permutations, every generated group element, right-multiplication tables, and the **actual chamber gluing** of the kernel surface. No generic mesh has been substituted for the quotient triangulation.

Run `python3 generate_quotients.py` to rebuild all JSON files. This uses only the Python standard library. The computation verifies generator orders, the order of the generated group, all side pairings, every vertex link, connectedness, orientability, and Euler characteristic. Current data total about 2.7 MB.

| ID | Group | Signature | Order | Surface | Genus | V | E | F |
|---|---|---|---:|---|---:|---:|---:|---:|
| a4 | A4 | (2,3,3) | 12 | Riemann sphere, tetrahedral symmetry | 0 | 14 | 36 | 24 |
| s4 | S4 | (2,3,4) | 24 | Riemann sphere, octahedral symmetry | 0 | 26 | 72 | 48 |
| a5 | A5 | (2,3,5) | 60 | Riemann sphere, icosahedral symmetry | 0 | 62 | 180 | 120 |
| torus | C6 | (2,3,6) | 6 | Hexagonal torus | 1 | 6 | 18 | 12 |
| klein | PSL(2,7) | (2,3,7) | 168 | Klein quartic | 3 | 164 | 504 | 336 |
| a6 | A6 | (2,4,5) | 360 | Wiman smooth sextic | 10 | 342 | 1080 | 720 |
| macbeath | PSL(2,8) | (2,3,7) | 504 | Fricke–Macbeath surface | 7 | 492 | 1512 | 1008 |
| m11 | M11 | (2,4,11) | 7,920 | M11 triangle-quotient surface | 631 | 6,660 | 23,760 | 15,840 |

`F` counts the small two-colored reflection chambers, not the paired fundamental domains of Δ. The tetrahedral/octahedral/icosahedral chamber decompositions are barycentric subdivisions of the corresponding regular maps. Likewise the Klein quotient has 56 larger triangular faces, 84 edges, and 24 vertices, each larger triangle subdivided into six chambers. The Fricke–Macbeath quotient has 168 larger triangular faces, 252 edges, and 72 vertices.

The small C6 example is a triangular cellulation (a Δ-complex): it has parallel edges. Barycentric subdivision yields a triangulation in the strict simplicial-complex sense. Preserve edge IDs when drawing or gluing it.

## Why the result is a surface

Let φ:Δ(p,q,r)→G be onto, with the images of x,y,z of **exact** orders p,q,r. A nonidentity finite-order element of the geometric triangle group is conjugate to a nonidentity power of one of these rotations, so it cannot lie in K=ker φ. Thus K is torsion-free and acts freely on the simply connected spherical, Euclidean, or hyperbolic geometry. Its quotient X is a closed oriented surface. For hyperbolic and Euclidean cases it inherits a complex structure from the oriented geometry, hence is a compact Riemann surface. In the spherical examples K is trivial and X is the Riemann sphere.

There are two chambers per G-label. The three types of vertices have stabilizer orders p,q,r. Thus

\[
F=2|G|,\quad E=3|G|,\quad V=|G|(1/p+1/q+1/r),
\]

and

\[
2-2g=|G|(1/p+1/q+1/r-1).
\]

The finite group G acts on X. Its quotient is the branched orbifold sphere X/G with branch orders p,q,r. **X is the quotient by the kernel K, not the quotient by G.** A quotient of Δ does not automatically extend to a quotient of the full reflection group; no such extension is assumed here.

## Chamber convention and schema

Write the reflection generators as s0,s1,s2, with vertex of type i opposite side i, and

\[
x=s_1s_2,\quad y=s_2s_0,\quad z=s_0s_1.
\]

For g∈G, chamber `2*g` is positive; chamber `2*g+1` is negative and has representative g s2. Vertices retain type order `[p,q,r]` for both signs. Their cyclic orientation is `[p,q,r]` on positive chambers and `[p,r,q]` on negative chambers.

The side-neighbor formulas are

- positive g: `[negative(g y^-1), negative(g x), negative(g)]`;
- negative g: `[positive(g y), positive(g x^-1), positive(g)]`.

These formulas do not require a reflection action on G.

Important fields:

- `permutations.x`, `.y`, `.z`: one-based image lists. `cycles` gives one-based cycles.
- `elements[g]`: the permutation indexed by g; identity is g=0.
- `right.x[g]`, `.y[g]`, `.z[g]`: right products. Capitals `X,Y,Z` are inverses; in particular `Z=xy`.
- `wordParents[g]=[h,"x" or "y"]`: a breadth-first word, obtained by appending the letter to the word for h. Entry0 is `[-1,""]`.
- `faceVertices[f]=[pVertexID,qVertexID,rVertexID]`.
- `neighbors[f][i]`: chamber across side i, opposite vertex i.
- `faceEdges[f][i]`: global edge ID opposite vertex i. Each edge belongs to exactly two chambers, with the same side index.
- `edgeVertices[e]`: the two global vertex IDs of edge e.
- `vertices[v]`: type, representative group ID, and incident group elements of its cyclic coset.
- `dualSpanningTree`: triples `[fromFace,side,toFace]` in breadth-first order.
- `cutBoundaryEdgeIds`: edges excluded from the dual spanning tree. Cutting these yields a disk made from all chambers, with two copies of every cut edge on the boundary. Reidentify equal IDs, matching equal vertex types, to recover X.
- `extraRelator.word`: where present, an additional word that closes in G. Uppercase letters are inverses. `extraRelator.description` is its readable formula. These are verified relations in the finite quotient; only the specific A6 relation is claimed here to give a complete additional presentation.

## Named-surface identification and primary sources

### Klein quartic

The matrices x=[[0,-1],[1,0]], y=[[0,-1],[1,1]] act on P1(F7), have projective orders 2,3, and xy has order7. They generate PSL(2,7). The associated surface is the Klein quartic, which can be written x³y+y³z+z³x=0. See [Macbeath, Hurwitz groups and surfaces](https://library.slmath.org/books/Book35/files/macbeath.pdf). The recorded permutations use points 0,1,…,6,∞, converted to labels1,…,8.

### Wiman smooth sextic

[ATLAS: A6](https://brauer.maths.qmul.ac.uk/Atlas/alt/A6/) supplies the exact generators used here, x=(1 2)(3 4), y=(1 2 3 5)(4 6), and gives the presentation x²=y⁴=(xy)⁵=(xy²)⁵=1. The [primary paper of Badr and Bars](https://link.springer.com/article/10.1007/s10231-025-01558-z) identifies the smooth Wiman sextic with automorphism group A6; [Rojas’s research examples](https://sites.google.com/uchile.cl/anirojas/en/algorithms) also study this A6 action in genus10.

To verify that this exact generating pair gives that surface, Riemann–Hurwitz forces signature (2,4,5) for the A6 action in genus10. The group has45 involutions; for x=(1 2)(3 4), exhaustive enumeration gives32 choices of y with orders |y|=4 and |xy|=5, and all32 pairs generate A6. Hence there are1,440 ordered generating pairs of this type. ATLAS records Out(A6)=C2×C2, so |Aut(A6)|=1,440. Its action on generating pairs is free and therefore transitive. All these epimorphisms have the same kernel up to target automorphism. The exact pair in this dataset therefore uniformizes the Wiman surface.

An equation is

27X⁶+9X(Y⁵+Z⁵)−135X⁴YZ−45X²Y²Z²+10Y³Z³=0.

Do not confuse this smooth genus10 curve with the nodal Wiman plane sextic whose normalization has genus6 and automorphism group S5.

### Fricke–Macbeath

The generated group is PSL(2,8); the matrix construction uses F8=F2[t]/(t³+t+1). Its (2,3,7) kernel has genus7. [Lee, Spectrum of the Laplacian on the Fricke-Macbeath surface](https://arxiv.org/abs/2311.02632) identifies this as the unique genus7 Hurwitz surface, with504 conformal automorphisms. See also [Laing and Singerman, Transitivity on Weierstrass points](https://www.acadsci.fi/mathematica/Vol37/vol37pp285-300.pdf).

### Smallest Mathieu group

[ATLAS: M11](https://brauer.maths.qmul.ac.uk/Atlas/spor/M11/) supplies its order7,920 and the standard permutations used in this dataset. Their orders are(2,4,11), which yields genus631. This is a concrete sporadic-group example. No minimum-genus assertion or conventional name is assigned to this particular surface. The genus26 modular curve with M11 automorphisms in characteristic3 is a different phenomenon and is not the complex Riemann surface constructed here.

## Cut-open polygon module

The browser/CommonJS module `github-homepage/triangle-quotients/cut-net.js` provides `QuotientNet.build(data)`. It glues only the recorded dual-tree edges, joins corresponding corner types with a disjoint-set structure, and walks the resulting single oriented boundary cycle. Cut vertices are placed at equally spaced points of a unit circle. The result is an exact **topological** drawing of the cut triangulation; the straight chords do not represent the original spherical or hyperbolic metric.

The return value contains `corners[face][type]`, sparse `positions[rootID]=[x,y]`, ordered `boundary` segments `{face,side,edge,start,end}`, `seams` pairs `{edge,first,second}`, and `treeEdges` as a Set. Additional counts describe the disk. Each seam reverses boundary orientation and matches equal vertex types.

The downloadable ZIP includes an adjacent copy of `cut-net.js`. After extracting, run `python3 generate_quotients.py` to reproduce the JSON files and `node test_cut_net.js` to check all eight datasets; no package installation is required. The test also works in the original workspace, where it finds the site module automatically. These checks independently verify positive oriented triangle areas, complete polygon area, reversed endpoints on every seam, and the disk counts. The module itself checks one boundary cycle, no crossing diagonals (using exact integer cyclic order), Euler characteristic1, and the complete seam pairing. The M11 cut net builds in approximately60ms on this machine.
