// Independent accelerated local PL intersection audit. Candidate pairs can
// be resolved with exact rational arithmetic by resolve-check-suspects.py.
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <vector>
using L=long double;
using P=std::array<L,3>;
P sub(P a,P b){for(int k=0;k<3;k++)a[k]-=b[k];return a;}
P mix(P a,P b,L t){for(int k=0;k<3;k++)a[k]+=t*(b[k]-a[k]);return a;}
L dot(P a,P b){return a[0]*b[0]+a[1]*b[1]+a[2]*b[2];}
P cross(P a,P b){return {a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]};}
L norm(P a){return std::sqrt(dot(a,a));}
struct Face {std::array<uint32_t,3> v;std::array<P,3> p;P n,lo,hi;};
struct Tube {uint32_t start,end;double radius;};
std::vector<P> cut(const std::array<P,3>&p,P n,P origin,L eps){
 L d[3];std::vector<P> r;
 for(int i=0;i<3;i++){d[i]=dot(n,sub(p[i],origin));if(std::abs(d[i])<=eps)r.push_back(p[i]);}
 for(int i=0;i<3;i++){int j=(i+1)%3;if(d[i]*d[j]<0)r.push_back(mix(p[i],p[j],d[i]/(d[i]-d[j])));}
 return r;
}
bool allowed(P p,const std::vector<P>&shared,L eps){
 if(shared.empty())return false;
 if(shared.size()==1)return norm(sub(p,shared[0]))<=eps;
 P a=shared[0],b=shared[1],d=sub(b,a);L t=dot(sub(p,a),d)/dot(d,d);
 return t>=-eps&&t<=1+eps&&norm(sub(p,mix(a,b,std::max(L(0),std::min(L(1),t)))))<=eps;
}
bool coplanar(const Face&a,const Face&b,const std::vector<P>&shared,L eps){
 int drop=0;for(int k=1;k<3;k++)if(std::abs(a.n[k])>std::abs(a.n[drop]))drop=k;
 int x=(drop+1)%3,y=(drop+2)%3;
 auto orient=[&](P p,P q,P r){return (q[x]-p[x])*(r[y]-p[y])-(q[y]-p[y])*(r[x]-p[x]);};
 L sign=orient(b.p[0],b.p[1],b.p[2])>0?1:-1;
 std::vector<P> poly(a.p.begin(),a.p.end());
 for(int i=0;i<3;i++){
  std::vector<P> out;P u=b.p[i],v=b.p[(i+1)%3];
  for(size_t j=0;j<poly.size();j++){
   P p=poly[(j+poly.size()-1)%poly.size()],q=poly[j];L d=sign*orient(u,v,p),e=sign*orient(u,v,q);
   if((d<0)!=(e<0))out.push_back(mix(p,q,d/(d-e)));
   if(e>=0)out.push_back(q);
  }poly.swap(out);
 }
 for(P p:poly)if(!allowed(p,shared,eps*10))return true;
 return false;
}
bool suspect(const Face&a,const Face&b,L eps){
 std::vector<P> shared;for(int i=0;i<3;i++)for(int j=0;j<3;j++)if(a.v[i]==b.v[j])shared.push_back(a.p[i]);
 P line=cross(a.n,b.n);
 if(norm(line)<1e-10L){if(std::abs(dot(a.n,sub(b.p[0],a.p[0])))>eps)return false;return coplanar(a,b,shared,eps);}
 auto ca=cut(a.p,b.n,b.p[0],eps),cb=cut(b.p,a.n,a.p[0],eps);
 if(ca.empty()||cb.empty())return false;
 int k=0;for(int j=1;j<3;j++)if(std::abs(line[j])>std::abs(line[k]))k=j;
 L amin=ca[0][k],amax=amin,bmin=cb[0][k],bmax=bmin;
 for(P p:ca){amin=std::min(amin,p[k]);amax=std::max(amax,p[k]);}for(P p:cb){bmin=std::min(bmin,p[k]);bmax=std::max(bmax,p[k]);}
 L lo=std::max(amin,bmin),hi=std::min(amax,bmax);if(lo>hi)return false;
 if(shared.empty())return hi-lo>eps;
 L smin=shared[0][k],smax=smin;for(P p:shared){smin=std::min(smin,p[k]);smax=std::max(smax,p[k]);}
 return lo<smin-eps*10||hi>smax+eps*10;
}
int main(int argc,char**argv){
 if(argc!=2)return 2;
 std::ifstream in(argv[1],std::ios::binary);uint32_t h[4];in.read((char*)h,sizeof(h));
 std::vector<P> vertices(h[0]);for(P&p:vertices){double d[3];in.read((char*)d,sizeof(d));for(int k=0;k<3;k++)p[k]=d[k];}
 std::vector<Face> faces(h[1]);for(Face&f:faces){in.read((char*)f.v.data(),12);for(int k=0;k<3;k++)f.p[k]=vertices[f.v[k]];f.n=cross(sub(f.p[1],f.p[0]),sub(f.p[2],f.p[0]));L len=norm(f.n);for(L&x:f.n)x/=len;for(int k=0;k<3;k++){f.lo[k]=std::min({f.p[0][k],f.p[1][k],f.p[2][k]});f.hi[k]=std::max({f.p[0][k],f.p[1][k],f.p[2][k]});}}
 std::vector<Tube> tubes(h[2]);for(Tube&t:tubes){in.read((char*)&t.start,4);in.read((char*)&t.end,4);in.read((char*)&t.radius,8);}
 if(!in){std::cerr<<"Truncated input\n";return 2;}
 uint64_t candidates=0;std::vector<std::array<uint32_t,3>> suspects;
 for(uint32_t ti=0;ti<tubes.size();ti++){
  const auto&t=tubes[ti];L eps=t.radius*1e-7L;std::vector<uint32_t> order;for(uint32_t p=t.start;p<t.end;p++)order.push_back(p);
  std::sort(order.begin(),order.end(),[&](uint32_t a,uint32_t b){return faces[a].lo[0]<faces[b].lo[0];});std::vector<uint32_t> active;
  for(uint32_t i:order){const Face&a=faces[i];active.erase(std::remove_if(active.begin(),active.end(),[&](uint32_t j){return faces[j].hi[0]<a.lo[0]-eps;}),active.end());
   for(uint32_t j:active){const Face&b=faces[j];if(a.hi[1]<b.lo[1]-eps||b.hi[1]<a.lo[1]-eps||a.hi[2]<b.lo[2]-eps||b.hi[2]<a.lo[2]-eps)continue;candidates++;if(suspect(a,b,eps))suspects.push_back({ti,i,j});}
   active.push_back(i);
  }
  if(ti%32==0)std::cerr<<"Checked tubes "<<ti+1<<"/"<<tubes.size()<<", candidates "<<candidates<<", suspects "<<suspects.size()<<"\n";
 }
 std::cout<<"{\"candidatePairs\":"<<candidates<<",\"tubes\":"<<tubes.size()<<",\"longDoubleBytes\":"<<sizeof(L)<<",\"suspects\":[";
 for(size_t i=0;i<suspects.size();i++){if(i)std::cout<<',';std::cout<<'['<<suspects[i][0]<<','<<suspects[i][1]<<','<<suspects[i][2]<<']';}std::cout<<"]}\n";
}
