'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path');
const M=require('../viewer/geometry.js');
const S=require('./sphere-torus-models.js');
for(const id of ['a4','s4','a5','torus']){
 const d=JSON.parse(fs.readFileSync(path.join(__dirname,'../quotient-data',id+'.json')));
 const model=S.build(d,M);assert.ok(model);
 assert.ok(model.validation.maxGluingError<1e-10);
 assert.equal(model.corners.length,d.counts.triangles);
 for(let f=0;f<d.counts.triangles;f++)for(const triangle of S.refinement(8))for(const w of triangle){
  const p=model.sample(f,w),n=model.normal(f,w);
  assert.ok(p.every(Number.isFinite));assert.ok(Math.abs(Math.hypot(...n)-1)<1e-10);
 }
 const canonicalVertices=new Map();
 for(let f=0;f<d.counts.triangles;f++)for(let t=0;t<3;t++){
  const id=d.faceVertices[f][t],v=model.corners[f][t];
  if(canonicalVertices.has(id))assert.ok(Math.hypot(...v.map((x,j)=>x-canonicalVertices.get(id)[j]))<1e-10);
  canonicalVertices.set(id,v);
 }
 assert.equal(canonicalVertices.size,d.counts.vertices);
 if(id==='torus')assert.ok(Math.abs(model.validation.latticeArea-model.validation.expectedArea)<1e-10);
 console.log(id,JSON.stringify(model.validation));
}
for(let n=1;n<=16;n++){
 const cells=S.refinement(n);assert.equal(cells.length,n*n);
 for(const triangle of cells)for(const w of triangle){assert.ok(Math.abs(w.reduce((a,b)=>a+b,0)-1)<1e-10);assert.ok(w.every(t=>t>=0&&t<=1));}
}
console.log('All sphere, torus, identified-side and refinement checks passed.');
