# Symmetric Fricke–Macbeath models

The appropriate maximum is **D7, of order 14, for orientation-preserving spatial symmetries**. This is substantially larger than the D2 polyhedron currently used in the demonstration.

## Primary evidence

Matthias Goerner's [Berkeley thesis](https://math.berkeley.edu/~matthias/research/matthias_goerner_thesis_print.pdf), §2.12.3, printed pp.147–149 (PDF pp.159–161), establishes a D7-equivariant embedding of the Macbeath regular map R7.1. Its quotient is a sphere with cone orders (2,2,2,2,7). The construction first takes a double cover, obtaining a torus with two order-seven points, and then a sevenfold cyclic cover. Figure 2.57 illustrates the resulting seven-petal surface. The necessary-condition table in §2.13, printed p.159, excludes larger rotational candidates C9 and D9. Its remaining candidates are C2, C3, C7, D2, D3, and D7; the explicit D7 construction therefore attains the maximum. This statement concerns rotations preserving the regular map, not every accidental mirror symmetry of an unmarked model.

The earlier [Séquin 2010 report](https://graphics.berkeley.edu/papers/Sequin-SER-2010-11/Sequin-SER-2010-11.pdf) says that he obtained a satisfactory R7.1 embedding in January 2010. No downloadable D7 chamber-labelled coordinate model was located in the inspected author pages.

For straight-faced realizations with the original 72 vertices, [Bokowski and Kevin H. 2025, §5.7](https://doi.org/10.3390/sym17040622) provides D3, D2 and S2 examples. This is not a proof that D3 is the maximum when curved faces are allowed. The public [D3 coordinate file](http://codeparade.net/embeddings/models/R7.1_D3.obj) is included indirectly in the reproducer's referenced source directory.

## Concrete geometric target

`macbeath-d7-target.json` and `.obj` are a newly computed D7-symmetric target following the cyclic-cover construction. Put w=(x+iy)^7. The smooth surface is

    (|w-2| - 2)^2 + (z/0.36)^2 = 0.6^2.

The underlying offset torus intersects the branch axis in exactly two points. Riemann–Hurwitz gives χ=7·0−2(7−1)=−12, hence genus 7. Rotating x+iy by a seventh root of unity and the half-turn (x,y,z)↦(x,−y,−z) give D7.

The mesh has 12,532 vertices and 25,088 rendering triangles. It is connected, closed and consistently oriented. Its upper half is an embedded graph over a planar disk with seven holes; the lower half is its reflection. All projected triangle signs are checked by exact rational arithmetic on the exported coordinates, and the eight boundary cycles are disjoint. The group generators preserve oriented faces, satisfy the D7 relations, and have the expected two and four fixed vertices. Coordinate symmetry error is below 2.3×10⁻¹⁵. See `macbeath-d7-target-certificate.json`.

**These rendering triangles are not the 1,008 original Macbeath chambers.** The chamber map has not been transported to this target. It must not replace the chamber-labelled live model under a claim that this transport has been done. The target's extra mirror symmetries likewise are not asserted to preserve the original chamber map.

`macbeath-d7-target-preview.png` shows axial, oblique and side views. Reproduce with:

    python3 build_d7_target.py

The optional `render_target.py` needs NumPy and Pillow.

## Immediately usable, fully chamber-labelled alternative

`macbeath-d3-original-chambers.json` contains the published D3 polyhedron mapped into the original quotient vertex/chamber IDs. All 14,028 unordered pairs of its 168 coarse triangles pass the exact rational intersection test. Positive barycentric subdivision gives the exact 1,008 chambers. Its labelled neighbor graph is isomorphic to the application's quotient graph. This file could be integrated immediately, with an accurate D3 label, while transport to the maximal D7 target is developed.

Reproduce from the project root:

    python3 course-update-20260927-symmetric/macbeath/build_published_d3.py

This uses the existing standard-library exact checker and the original published OBJ data under `course-update-20260925/`.
