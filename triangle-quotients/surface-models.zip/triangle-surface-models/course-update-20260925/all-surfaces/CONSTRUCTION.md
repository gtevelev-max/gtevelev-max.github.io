# A constructive embedding of the prescribed quotient surface

The input is the actual oriented chamber triangulation computed from the
finite group, not a replacement triangulation of a surface with the same
genus. Every output patch retains its source chamber and barycentric source
coordinates. Original chambers can therefore be selected, colored, traced,
and checked after subdivision.

## Cutting to a planar surface

For each of the `g` cuts, cap existing boundary components conceptually and
choose a primal spanning tree and a disjoint dual spanning tree. The `2h`
remaining edges at current genus `h` provide a homology basis. Label dual
edges by bit vectors recording their intersections with the corresponding
primal fundamental cycles. A nonzero sum around a dual cycle certifies that
the cycle is nonseparating. Breadth-first trees from three different roots
provide short candidates in the unrestricted interior dual graph.

Each chosen curve also receives an independent combinatorial certificate:
delete its crossed primal edges and explicitly check that the primal graph
remains connected. Every cut triangle piece meets an original vertex, so
this verifies that the complement of the curve remains connected. The
older, simpler implementation (retained as `shortest_available_cycle`)
restricts its dual cycle to edges missing a primal spanning tree; it has
the same guarantee but can produce unnecessarily long late cuts.

The dual cycle passes through triangle interiors and crosses edges at
their midpoints. It is disjoint from every existing boundary. On every
crossed edge, replace the two copies of the midpoint by points at 45% and
55% along the edge. The positive-width band between them is reserved for
the corresponding tube. A crossed triangle leaves a corner triangle and
a quadrilateral, the latter subdivided into two triangles. Its omitted
strip is divided at the original midpoint curve into two half strips.

Each cut lowers genus by one, creates two boundary components, and keeps
the complement connected. After `g` cuts there is a genus-zero surface
with `2g` boundary components. Their pairings, source chamber labels, and
source barycentric coordinates are recorded explicitly. The sum of the
areas of the remaining patches and the omitted half strips is checked
against the unit barycentric area separately for **every** original
chamber.

## A planar base with bounded holes

Cap every boundary loop by a new center and a triangle fan. The result is
a triangulated sphere. Use its known oriented combinatorial embedding and
the Chrobak–Payne integer-grid drawing algorithm, choosing one original
triangle as the outer face. Remove the artificial cap fans. All `2g`
holes are bounded and star-shaped about their cap centers, since every
cap-fan triangle has positive area. All remaining original patch triangles
have strictly positive integer area; this is verified without tolerances.

The integer-grid drawing core is adapted from NetworkX's BSD-licensed
implementation. Its copyright and license are retained in
`NETWORKX-LICENSE.txt`.

The selected outer original triangle is replaced by a three-triangle cone
below the plane. These three patches receive that triangle's chamber label
and its corresponding barycentric subdivision. This closes the outside
without interfering with any hole or with the rest of the planar base.

## Reattaching the original bands

Each paired set of boundary components is rejoined by a tube in the upper
half-space. Boundary vertices are matched by the stored midpoint origins,
in opposite cyclic order. Every tube strip uses the source coordinates of
its omitted collar. Its designated seam ring corresponds to the original dual
cut curve. Thus the tube does not insert extra chambers or collapse source
triangles: it fills exactly the two omitted half strips.

Distinct tube center paths are assigned distinct routing heights and avoid
the vertical stems of other tubes. The tube-radius bounds and disjointness
diagnostics are recorded by the routing construction. Lengths and angles
are deliberately distorted; the result represents the same topological
surface, chamber adjacency, and chamber partition.

Every triangular tube patch lies in the radius-`R` capsule of its centerline
segment: its vertices lie in the endpoint disks and the capsule is convex.
Distinct horizontal centerline paths have vertical separation greater than
`2R`. Each such path has measured horizontal distance greater than `2R`
from every other vertical stem, and distinct stems have separation greater
than `2R`. These bounds exclude all intersections between different tubes.
The generator also verifies the miter condition
`length > R (tan(turn_start/2) + tan(turn_end/2))` on every segment.
Local triangle-pair checks test each tube for unwanted self-intersections.

This is a subdivision of the prescribed triangulation. It is not a claim
that its original triangular chambers have straight edges or flat interiors
in Euclidean three-space.

## Reproduce the models

Use Python 3.12+ with `networkx==3.7` and Node.js. The input JSON files live in
the neighboring `quotient-data` directory. From this directory:

```sh
python3 -m pip install -r requirements.txt
python3 cut_to_planar.py --tree-cycles a6
python3 cut_to_planar.py m11
node tube-routing.js a6-planar.json a6-tubes.json
node tube-routing.js m11-planar.json m11-tubes.json
python3 verify_patch_embedding.py a6-tubes.json
python3 verify_patch_embedding.py m11-tubes.json
```

The A6 asset uses the simpler primal-tree cut algorithm; the M11 asset uses
the shorter homology-guided cut algorithm. Both algorithms remain in the
source. Generator output includes independent nonseparating-cut checks,
source-coordinate area sums, and strictly positive planar triangle areas.
The tube generator checks closed oriented edge incidence, Euler
characteristic, source chart continuity, and the original quotient's
neighbor table. The independent verifier checks each original chamber is
a disk and tests local triangle intersections using scale-dependent
floating-point contact tolerances. Suspect intersections of nearly coplanar
thin triangles are resolved with exact rational predicates on the stored
IEEE-double coordinates. Separate routing heights and measured
stem-clearance bounds keep distinct handles disjoint.
