"""Independent original chamber disks, charts, adjacency, and genus audit."""
import collections,json,pathlib,sys

def audit(path):
 d=json.loads(path.read_text());fs=d['patches'];nv=len(d['positions']);q=json.loads((path.parent.parent/'quotient-data'/f"{d['id']}.json").read_text())
 groups=collections.defaultdict(list);edges={};used=set();source_edges=0;maximum_error=0;minimum_area=1
 for i,p in enumerate(fs):
  groups[p['chamber']].append(i);vv=p['vertices'];used.update(vv)
  for k in range(3):
   a,b=vv[k],vv[(k+1)%3];key=min(a,b)*nv+max(a,b)
   if key not in edges:edges[key]=(i,k);continue
   prior=edges[key];assert prior is not None,('edge has >2 incident faces',a,b)
   j,l=prior;t=fs[j];assert t['vertices'][l]==b and t['vertices'][(l+1)%3]==a,('orientation',i,j)
   for u,v in [(p['bary'][k],t['bary'][(l+1)%3]),(p['bary'][(k+1)%3],t['bary'][l])]:assert max(abs(x-y) for x,y in zip(u,v))<1e-9,('source discontinuity',i,j)
   if p['chamber']!=t['chamber']:
    side=[s for s in range(3) if abs(p['bary'][k][s])<1e-12 and abs(p['bary'][(k+1)%3][s])<1e-12];assert len(side)==1 and q['neighbors'][p['chamber']][side[0]]==t['chamber'],('original adjacency',i,j);source_edges+=1
   edges[key]=None
 assert all(x is None for x in edges.values()) and len(used)==nv
 euler=nv-len(edges)+len(fs);assert euler==2-2*d['genus']
 for chamber,ids in groups.items():
  local=collections.defaultdict(list);vs=set();areas=[]
  for i in ids:
   p=fs[i];v=p['vertices'];vs.update(v)
   for k in range(3):local[tuple(sorted((v[k],v[(k+1)%3])))].append(i)
   a,b,c=p['bary'];area=(b[1]-a[1])*(c[2]-a[2])-(b[2]-a[2])*(c[1]-a[1]);areas.append(area)
  assert len(vs)-len(local)+len(ids)==1 and min(areas)*max(areas)>0
  minimum_area=min(minimum_area,min(map(abs,areas)));maximum_error=max(maximum_error,abs(sum(map(abs,areas))-1))
  adj=collections.defaultdict(list)
  for (a,b),ii in local.items():
   assert len(ii) in (1,2)
   if len(ii)==1:adj[a].append(b);adj[b].append(a)
  assert all(len(v)==2 for v in adj.values())
  reached={next(iter(adj))};todo=list(reached)
  for a in todo:
   for b in adj[a]:
    if b not in reached:reached.add(b);todo.append(b)
  assert reached==set(adj)
 assert len(groups)==d['originalTriangles'] and maximum_error<1e-9
 report={'originalChamberDisks':len(groups),'genus':d['genus'],'vertices':nv,'edges':len(edges),'renderingTriangles':len(fs),'euler':euler,'minimumSourceArea':minimum_area,'maximumSourceAreaError':maximum_error,'originalAdjacencyEdgesChecked':source_edges,'allSharedEdgesMatchSourceCharts':True}
 out=path.with_name(path.stem+'-topology-verification.json');out.write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2));return report
if __name__=='__main__':audit(pathlib.Path(sys.argv[1]))
