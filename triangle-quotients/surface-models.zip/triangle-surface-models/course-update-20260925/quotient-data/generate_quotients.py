#!/usr/bin/env python3
"""Exact finite triangle quotients and their oriented chamber complexes.
No third-party packages. Permutations use zero-based images internally;
compose(a,b)=a o b (rightmost factor acts first)."""
from pathlib import Path
from math import lcm
from fractions import Fraction
from itertools import permutations
from collections import Counter
import json

OUT=Path(__file__).resolve().parent

def compose(a,b): return tuple(a[i] for i in b)
def inverse(a):
    b=[0]*len(a)
    for i,j in enumerate(a): b[j]=i
    return tuple(b)
def perm(n,*cycles):
    a=list(range(n))
    for cy in cycles:
        for i,j in zip(cy,cy[1:]+cy[:1]): a[i-1]=j-1
    return tuple(a)
def cycles(a):
    seen=set(); out=[]
    for i in range(len(a)):
        if i in seen: continue
        cy=[];j=i
        while j not in seen: seen.add(j);cy.append(j+1);j=a[j]
        if len(cy)>1: out.append(cy)
    return out

def order(a):
    k=1
    for c in cycles(a): k=lcm(k,len(c))
    return k

def enumerate_group(x,y):
    elems=[tuple(range(len(x)))]; ids={elems[0]:0}; parents=[[-1,'']]
    for i,g in enumerate(elems):
        for name,h in [('x',x),('y',y)]:
            gh=compose(g,h)
            if gh not in ids:
                ids[gh]=len(elems); elems.append(gh);parents.append([i,name])
    return elems,ids,parents

def gf_mul(a,b):
    z=0
    while b:
        if b&1: z^=a
        a<<=1
        if a&8:a^=11
        b>>=1
    return z

def gf_inv(a):
    return next(b for b in range(1,8) if gf_mul(a,b)==1)

def mobius8(a,b,c,d):
    out=[]
    for z in range(9):
        if z==8: num,den=a,c
        else:num,den=gf_mul(a,z)^b,gf_mul(c,z)^d
        out.append(8 if den==0 else gf_mul(num,gf_inv(den)))
    return tuple(out)

def mobius7(a,b,c,d):
    out=[]
    for z in range(8):
        if z==7:num,den=a,c
        else:num,den=(a*z+b)%7,(c*z+d)%7
        out.append(7 if den==0 else num*pow(den,-1,7)%7)
    return tuple(out)

def find_a6():
    x=perm(6,[1,2],[3,4])
    for y in permutations(range(6)):
        if sorted(map(len,cycles(y)))==[2,4] and order(compose(x,y))==5:
            if len(enumerate_group(x,y)[0])==360:return x,y

def find_psl8():
    x=mobius8(0,1,1,0)
    for a in range(8):
      for b in range(8):
       for c in range(8):
        d=a^1
        if gf_mul(a,d)^gf_mul(b,c)!=1:continue
        y=mobius8(a,b,c,d)
        if order(y)==3 and order(compose(x,y))==7 and len(enumerate_group(x,y)[0])==504:return x,y,[a,b,c,d]

def build(key,name,pqr,x,y,expected,surface,sources,note=''):
    p,q,r=pqr
    xy=compose(x,y)
    assert [order(x),order(y),order(xy)]==pqr,(key,order(x),order(y),order(xy))
    elems,ids,parents=enumerate_group(x,y); n=len(elems)
    assert n==expected,(key,n)
    gens={'x':x,'y':y,'z':inverse(xy),'X':inverse(x),'Y':inverse(y),'Z':xy}
    right={name:[ids[compose(g,h)] for g in elems] for name,h in gens.items()}
    vtypes=[]; vcosets=[]; offset=0; vertices=[]
    for t,gname in enumerate(['x','y','Z']):
        vc=[-1]*n;expectedsize=pqr[t]
        for i in range(n):
            if vc[i]>=0:continue
            members=[];j=i
            while vc[j]<0:vc[j]=offset;members.append(j);j=right[gname][j]
            assert j==i and len(members)==expectedsize
            vertices.append({'type':t,'representative':i,'incidentGroupElements':members})
            vtypes.append(t);offset+=1
        vcosets.append(vc)
    faceVertices=[];neighbors=[];faceEdges=[]
    for g in range(n):
        # Each pair: +g and -g. Vertex array retains type order p,q,r;
        # positive cyclic orientation [p,q,r], negative [p,r,q].
        faceVertices.append([vcosets[0][g],vcosets[1][g],vcosets[2][g]])
        faceVertices.append([vcosets[0][g],vcosets[1][g],vcosets[2][right['y'][g]]])
        neighbors.append([2*right['Y'][g]+1,2*right['x'][g]+1,2*g+1])
        neighbors.append([2*right['y'][g],2*right['X'][g],2*g])
        faceEdges.append([3*g,3*g+1,3*g+2])
        faceEdges.append([3*right['y'][g],3*right['X'][g]+1,3*g+2])
    edgeVertices=[]
    for f in range(0,2*n,2):
        vs=faceVertices[f]
        edgeVertices.extend([[vs[1],vs[2]],[vs[2],vs[0]],[vs[0],vs[1]]])
    # Verify the gluing, each edge belongs to exactly two faces, vertex links
    # are one circle of length 2p, 2q, or 2r, and the entire surface is connected.
    incidence=Counter(e for row in faceEdges for e in row)
    assert len(incidence)==3*n and set(incidence.values())=={2}
    for f,ns in enumerate(neighbors):
        for side,h in enumerate(ns):
            assert neighbors[h][side]==f
            assert faceEdges[f][side]==faceEdges[h][side]
            assert sorted(faceVertices[f][k] for k in range(3) if k!=side)==sorted(faceVertices[h][k] for k in range(3) if k!=side)
    seen={0};todo=[0];dualTree=[]
    for f in todo:
        for side,h in enumerate(neighbors[f]):
            if h not in seen: seen.add(h);todo.append(h);dualTree.append([f,side,h])
    assert len(seen)==2*n
    incident=[[] for _ in vertices]
    for f,vs in enumerate(faceVertices):
        for v in vs:incident[v].append(f)
    for v,fs in enumerate(incident):
        t=vtypes[v];assert len(fs)==2*pqr[t]
        allowed=[s for s in range(3) if s!=t]
        seen={fs[0]};todo=[fs[0]]
        for f in todo:
            for s in allowed:
                h=neighbors[f][s]
                assert faceVertices[h][t]==v
                if h not in seen:seen.add(h);todo.append(h)
        assert len(seen)==len(fs)
    V=len(vertices);E=3*n;F=2*n;chi=V-E+F;genus=1-chi//2
    assert chi%2==0
    assert Fraction(2-2*genus,n)==Fraction(1,p)+Fraction(1,q)+Fraction(1,r)-1
    gluedEdges={faceEdges[f][side] for f,side,h in dualTree}
    boundaryEdges=[e for e in range(E) if e not in gluedEdges]
    data={'id':key,'group':name,'order':n,'signature':pqr,'geometry':'spherical' if genus==0 else 'euclidean' if genus==1 else 'hyperbolic','surface':surface,'genus':genus,'counts':{'vertices':V,'edges':E,'triangles':F,'euler':chi,'vertexTypes':[n//p,n//q,n//r]},'degree':len(x),'permutations':{'x':[i+1 for i in x],'y':[i+1 for i in y],'z':[i+1 for i in inverse(xy)]},'cycles':{'x':cycles(x),'y':cycles(y),'z':cycles(inverse(xy))},'convention':'Permutation products act rightmost first. z=(xy)^-1. Group IDs enumerate words by right multiplication; identity is 0. Chamber 2g is positive; 2g+1 negative. Vertices have type order (p,q,r), reverse winding for negative chambers. Side i is opposite vertex i.','right':right,'wordParents':parents,'elements':[[i+1 for i in e] for e in elems],'vertices':vertices,'faceVertices':faceVertices,'faceEdges':faceEdges,'edgeVertices':edgeVertices,'neighbors':neighbors,'dualSpanningTree':dualTree,'cutBoundaryEdgeIds':boundaryEdges,'sources':sources,'note':note,'verification':{'orders':pqr,'generatedOrder':n,'connected':True,'twoTrianglesPerEdge':True,'vertexLinks':'single circles of lengths 2p, 2q, 2r','orientable':True}}
    extra={'torus':'xyXY','klein':'xyXY'*4,'a6':'xyy'*5,'macbeath':'xyXY'*9,'m11':'xyy'*6}.get(key)
    if extra:
        g=0
        for letter in extra:g=right[letter][g]
        assert g==0
        data['extraRelator']={'word':extra,'description':{'torus':'[x,y]','klein':'[x,y]^4','a6':'(xy^2)^5','macbeath':'[x,y]^9','m11':'(xy^2)^6'}[key],'closesInQuotient':True}
    (OUT/(key+'.json')).write_text(json.dumps(data,separators=(',',':'))+'\n')
    print(key,pqr,n,'g='+str(genus),'V,E,F=',V,E,F,'x=',cycles(x),'y=',cycles(y),flush=True)
    return {k:data[k] for k in ['id','group','order','signature','geometry','surface','genus','counts','cycles','sources','note']}

if __name__=='__main__':
    rows=[]
    rows.append(build('a4','A4',[2,3,3],perm(4,[1,2],[3,4]),perm(4,[1,2,3]),12,'Riemann sphere — tetrahedral symmetry',[]))
    rows.append(build('s4','S4',[2,3,4],perm(4,[1,2]),perm(4,[2,3,4]),24,'Riemann sphere — octahedral symmetry',[]))
    rows.append(build('a5','A5',[2,3,5],perm(5,[1,2],[3,4]),perm(5,[2,3,5]),60,'Riemann sphere — icosahedral symmetry',[]))
    rows.append(build('torus','C6',[2,3,6],perm(6,[1,4],[2,5],[3,6]),perm(6,[1,3,5],[2,4,6]),6,'Hexagonal torus',[], 'The kernel is a rank-two translation lattice. The quotient group C6 acts on this torus; its quotient orbifold is the (2,3,6) sphere.'))
    rows.append(build('klein','PSL(2,7)',[2,3,7],mobius7(0,-1,1,0),mobius7(0,-1,1,1),168,'Klein quartic',[{'title':'Macbeath, Hurwitz groups and surfaces','url':'https://library.slmath.org/books/Book35/files/macbeath.pdf'}], 'The permutation action is on P1(F7), ordered 0,1,...,6,infinity. The curve is x^3 y + y^3 z + z^3 x = 0.'))
    ax,ay=find_a6()
    rows.append(build('a6','A6',[2,4,5],ax,ay,360,'Wiman sextic (genus 10)',[{'title':'ATLAS: A6 generators and presentation','url':'https://brauer.maths.qmul.ac.uk/Atlas/alt/A6/'},{'title':'Rojas: A6 action on genus 10, Wiman sextic','url':'https://sites.google.com/uchile.cl/anirojas/en/algorithms'},{'title':'Badr and Bars: The stratification by automorphism groups of smooth plane sextic curves','url':'https://link.springer.com/article/10.1007/s10231-025-01558-z'}], 'This is Wiman’s smooth genus-10 sextic, not the singular plane sextic of genus 6 with S5 automorphisms. The uniformizing signature follows from Riemann–Hurwitz for the A6 action.'))
    px,py,mat=find_psl8()
    rows.append(build('macbeath','PSL(2,8)',[2,3,7],px,py,504,'Fricke–Macbeath surface',[{'title':'Lee, Spectrum of the Laplacian on the Fricke-Macbeath surface','url':'https://arxiv.org/abs/2311.02632'},{'title':'Laing and Singerman, Transitivity on Weierstrass points','url':'https://www.acadsci.fi/mathematica/Vol37/vol37pp285-300.pdf'}], 'Unique genus-7 Hurwitz surface. Permutations act on P1(F8) with F8=F2[t]/(t^3+t+1); field elements are bit-coded 0,...,7 and infinity=8. y matrix entries: '+str(mat)))
    rows.append(build('m11','M11',[2,4,11],perm(11,[2,10],[4,11],[5,7],[8,9]),perm(11,[1,4,3,8],[2,5,6,9]),7920,'M11 triangle-quotient surface',[{'title':'ATLAS of Finite Group Representations: M11','url':'https://brauer.maths.qmul.ac.uk/Atlas/spor/M11/'}], 'Uses the verified ATLAS standard (2,4,11) generators. Genus 631; no conventional surface name or claim of minimum genus is made. This is a complex Riemann surface and should not be confused with X(11) in characteristic 3.'))
    (OUT/'catalog.json').write_text(json.dumps(rows,indent=2)+'\n')
    print('All exact permutation, gluing, connectivity, vertex-link and Euler checks passed.')
