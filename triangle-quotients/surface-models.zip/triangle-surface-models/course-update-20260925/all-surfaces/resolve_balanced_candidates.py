"""Resolve compiled local intersection candidates using exact IEEE rationals."""
import json,pathlib,sys
from verify_patch_embedding import exact_pair_check
p=pathlib.Path(sys.argv[1]);d=json.loads(p.read_text());checks=json.loads(pathlib.Path(sys.argv[2]).read_text());failures=[]
for tube,i,j in checks['suspects']:
 f,g=d['patches'][i],d['patches'][j];a=[tuple(d['positions'][v]) for v in f['vertices']];b=[tuple(d['positions'][v]) for v in g['vertices']];shared=[tuple(d['positions'][v]) for v in set(f['vertices'])&set(g['vertices'])];eps=d['tubes'][tube]['radius']*1e-7
 error=exact_pair_check(a,b,shared,eps)
 if error:failures.append({'tube':tube,'patches':[i,j],'error':error})
report=json.loads(p.with_name(p.stem+'-topology-verification.json').read_text());report.update({'localTrianglePairCandidates':checks['candidatePairs'],'exactPredicateResolutions':len(checks['suspects']),'intersectionFailures':failures,'compiledPredicatePrecisionBytes':checks['longDoubleBytes']});p.with_name(p.stem+'-independent-verification.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2));assert not failures
