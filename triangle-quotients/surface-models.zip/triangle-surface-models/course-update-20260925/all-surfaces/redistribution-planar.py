#!/usr/bin/env python3
"""Area conditioning by a Euclidean circle-packing redraw of the capped sphere.
Only geometric coordinates change. Original chamber IDs and barycentric charts
are copied byte-for-byte as Python objects. Requires NumPy and SciPy.
"""
import argparse,json,math,time,sys
from collections import deque
import numpy as np
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import spsolve


def packing(data,maxiter=150):
    n=len(data['positions']); outer=np.array(data['outerFacePatch']['vertices'])
    faces=[p['vertices'] for p in data['patches']]
    for h in data['holes']:
        v=h['vertices']; c=h['centerVertex']
        faces.extend([[v[(i+1)%len(v)],v[i],c] for i in range(len(v))])
    F=np.array(faces,dtype=np.int32)
    interior=np.ones(n,dtype=bool);interior[outer]=False; ids=np.where(interior)[0]
    index=np.full(n,-1,dtype=np.int32); index[ids]=np.arange(len(ids))
    I=np.concatenate([F[:,0],F[:,1],F[:,2]])
    J=np.concatenate([F[:,1],F[:,2],F[:,0]])
    L=np.concatenate([F[:,2],F[:,0],F[:,1]])
    use=interior[I]
    logs=np.full(n,-2.);logs[outer]=0
    def calc(x,jac=False):
        r=np.exp(x);ri,rj,rk=r[I],r[J],r[L]
        sh=np.sqrt(rj/(ri+rj)*rk/(ri+rk)); sh=np.clip(sh,1e-150,1-1e-15)
        angles=2*np.arcsin(sh); sums=np.bincount(I,weights=angles,minlength=n)
        K=(2*np.pi-sums)[ids]
        if not jac:return K
        th=sh/np.sqrt(1-sh*sh)
        dij=th*ri/(ri+rj);dik=th*ri/(ri+rk)
        diag=np.bincount(I,weights=dij+dik,minlength=n)
        row=[np.arange(len(ids))];col=[np.arange(len(ids))];val=[diag[ids]]
        for target,w in [(J,dij),(L,dik)]:
            keep=use&interior[target]
            row.append(index[I[keep]]);col.append(index[target[keep]]);val.append(-w[keep])
        H=coo_matrix((np.concatenate(val),(np.concatenate(row),np.concatenate(col))),shape=(len(ids),len(ids))).tocsr()
        return K,H
    for iteration in range(maxiter):
        k,H=calc(logs,True);err=np.max(np.abs(k));rms=np.linalg.norm(k)
        print('packing',iteration,'max',err,'rms',rms,'log range',np.min(logs),np.max(logs),flush=True)
        if err<2e-11:break
        delta=spsolve(H,-k)
        if not np.isfinite(delta).all():raise ValueError('nonfinite Newton step')
        step=min(1,4/max(4,np.max(np.abs(delta))))
        while step>1e-8:
            test=logs.copy();test[ids]+=step*delta
            if np.min(test)>-700 and np.linalg.norm(calc(test))<rms:logs=test;break
            step*=.5
        else:raise ValueError('Newton line search failed')
    else:raise ValueError('Packing did not converge')
    radii=np.exp(logs);p=np.full((n,2),np.nan)
    p[outer]=[[0,0],[1,np.sqrt(3)],[2,0]]
    # Breadth-first traversal of triangle adjacency, so each new triangle has
    # an oriented edge whose endpoints have been laid out already.
    around=[[] for _ in range(n)]
    for fi,f in enumerate(F):
        for v in f:around[v].append(fi)
    todo=deque();queued=set()
    for v in outer:
        for fi in around[v]:
            if fi not in queued:todo.append(fi);queued.add(fi)
    done=set()
    while todo:
        fi=todo.popleft();f=F[fi];known=np.isfinite(p[f,0]); count=known.sum()
        if count<2:continue
        if count==2:
            k=np.where(~known)[0][0];a,b,c=f[(k+1)%3],f[(k+2)%3],f[k]
            ab=p[b]-p[a];length=np.linalg.norm(ab)
            la=radii[a]+radii[c];lb=radii[b]+radii[c]
            x=(length*length+la*la-lb*lb)/(2*length)
            y=math.sqrt(max(0,la*la-x*x));u=ab/length
            p[c]=p[a]+x*u+y*np.array([-u[1],u[0]])
            for fj in around[c]:
                if fj not in done:todo.append(fj)
        done.add(fi)
    if not np.isfinite(p).all():raise ValueError('Some points were not reached')
    av=p[F[:,1]]-p[F[:,0]];bv=p[F[:,2]]-p[F[:,0]];areas=av[:,0]*bv[:,1]-av[:,1]*bv[:,0]
    print('orientation min',areas.min(),'bad',int((areas<=0).sum()),flush=True)
    if np.any(areas<=0):raise ValueError('Circle-packing layout folded')
    edges=np.vstack([F[:,[0,1]],F[:,[1,2]],F[:,[2,0]]]);errors=np.linalg.norm(p[edges[:,0]]-p[edges[:,1]],axis=1)-radii[edges[:,0]]-radii[edges[:,1]]
    print('max length error',abs(errors).max(),flush=True)
    data['positions']=p.tolist()
    for h in data['holes']:h['center']=data['positions'][h['centerVertex']]
    centers=p[[h['centerVertex'] for h in data['holes']]]
    gaps=np.linalg.norm(centers[:,None,:]-centers[None,:,:],axis=2);np.fill_diagonal(gaps,np.inf)
    minimum=float(gaps.min()); cr=radii[[h['centerVertex'] for h in data['holes']]]
    v=dict(method='Circle packing of capped triangulation with equal outer radii',angleError=float(err),minimumDoubledArea=float(areas.min()),maxTangentLengthError=float(abs(errors).max()),holeCenterMinimumDistance=minimum,holeCapRadiusMinimum=float(cr.min()),holeCapRadiusMedian=float(np.median(cr)),holeCapRadiusMaximum=float(cr.max()),span=float(np.ptp(p,axis=0).max()),iterations=iteration)
    data['redistribution']=v;print(json.dumps(v,indent=2),flush=True)
    return data

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('input');parser.add_argument('output');args=parser.parse_args()
    data=json.load(open(args.input));data=packing(data)
    with open(args.output,'w') as f:json.dump(data,f,separators=(',',':'))
