"""Pack exact source-labelled refinements without millions of JS objects.

The binary arrays keep double precision for positions and source barycentrics.
All display triangles retain their original quotient chamber number.
"""
import base64
import gzip
import json
import pathlib
import struct
import sys
from array import array

ROOT = pathlib.Path(__file__).resolve().parent
SITE = ROOT.parent.parent / 'github-homepage' / 'triangle-quotients'


def pack(path):
    data = json.loads(path.read_text())
    ident = data['id']
    positions = data['positions']
    patches = data['patches']
    meta = {k: data[k] for k in ['id', 'genus', 'originalTriangles', 'verification', 'construction'] if k in data}
    meta['tubes'] = [{k: t[k] for k in ['curve', 'radius', 'height', 'center', 'centerline', 'endpointCenters', 'sourceChambers', 'patchStart', 'patchEnd'] if k in t} for t in data.get('tubes', [])]
    info = json.dumps(meta, separators=(',', ':')).encode()
    raw = bytearray(b'M611SURF' + struct.pack('<IIII', len(positions), len(patches), len(info), 0))
    raw.extend(info)
    raw.extend(b'\0' * (-len(raw) % 8))
    streams = [
        array('d', (x for p in positions for x in p)),
        array('I', (v for p in patches for v in p['vertices'])),
        array('I', (p['chamber'] for p in patches)),
        array('d', (w for p in patches for v in p['bary'] for w in v)),
    ]
    for values in streams:
        if sys.byteorder != 'little':
            values.byteswap()
        raw.extend(values.tobytes())
    encoded = base64.b64encode(gzip.compress(raw, compresslevel=9, mtime=0)).decode()
    dest = SITE / 'surface-data'
    dest.mkdir(exist_ok=True)
    files = []
    for i, start in enumerate(range(0, len(encoded), 900_000)):
        name = f'{ident}-{i:02d}.js'
        prefix = 'window.REFINED_SURFACE_PACKED=window.REFINED_SURFACE_PACKED||{};'
        if i == 0:
            prefix += f'window.REFINED_SURFACE_PACKED["{ident}"]=[];'
        (dest / name).write_text(prefix + f'window.REFINED_SURFACE_PACKED["{ident}"][{i}]="{encoded[start:start+900_000]}";\n')
        files.append('surface-data/' + name)
    manifest_file = dest / 'manifest.json'
    manifest = json.loads(manifest_file.read_text()) if manifest_file.exists() else {}
    manifest[ident] = {'files': files, 'vertices': len(positions), 'patches': len(patches), 'binaryBytes': len(raw), 'base64Bytes': len(encoded)}
    manifest_file.write_text(json.dumps(manifest, indent=2) + '\n')
    print(ident, json.dumps(manifest[ident]))


if __name__ == '__main__':
    for name in sys.argv[1:]:
        pack(pathlib.Path(name))
