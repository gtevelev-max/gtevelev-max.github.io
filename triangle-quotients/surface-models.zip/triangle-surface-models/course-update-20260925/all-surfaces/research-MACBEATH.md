# Fricke–Macbeath: exact original-chamber embedding

`macbeath-embedding.json` is a verified embedded genus-7 polyhedral surface in the **original quotient vertex and chamber IDs**. It uses the integer-coordinate `R7.1_D2.obj` numerical data published by CodeParade, coauthor of Bokowski and Kevin H., *Polyhedral Embeddings of Triangular Regular Maps of Genus g, 2 ≤ g ≤ 14, and Neighborly Spatial Polyhedra*, Symmetry **17** (2025), 622, https://doi.org/10.3390/sym17040622 (CC BY 4.0). The paper's §5.7 depicts this model. The initial nonsymmetric realization was published by Bokowski and Cuntz (2018), https://doi.org/10.26493/2590-9770.1186.258.

Source downloads:

- http://codeparade.net/embeddings/models/R7.1_D2.obj (chosen)
- http://codeparade.net/embeddings/models/R7.1_D3.obj (also verified)
- http://codeparade.net/embeddings/models/R7.1_S2.obj (also verified)

The research HTML and viewer files establish the precise data URLs; none of the third-party rendering code is used in our application. `research-paper.pdf` is a research copy of the freely available CC BY publication from the authors' university repository and need not be distributed with the application.

## Reproduce

From this directory, with the neighboring `quotient-data/` and `surface-embedding/` directories present:

```
python3 research-build-macbeath.py
```

Only the standard Python library is used. The script uses the project's shared exact rational triangle-intersection checker in `../surface-embedding/build_klein_embedding.py`.

## Mathematical certificate

1. The source model has 72 vertices, 252 edges, and 168 triangular faces.
2. Every one of its 14,028 unordered pairs of triangles was tested with exact rational arithmetic. Any intersection equals precisely the shared combinatorial edge or vertex; nonincident faces are disjoint. There are no degenerate faces.
3. Subdivide each larger triangle by its three edge midpoints and centroid. These are positive barycentric subdivisions, so each larger face partitions into six nonoverlapping chambers. Exact embedding of the larger faces therefore proves embedding of all 1,008 small chambers.
4. Breadth-first propagation constructs a bijective **side-labelled** chamber graph isomorphism with the exact quotient `macbeath.json`. All original chamber neighbors and all vertex identifications are preserved. The correspondence is not inferred from genus or face count alone.
5. The resulting triangulation has V=492, E=1512, F=1008, hence χ=−12 and genus 7.

The Euclidean geometry is a topological realization, not an isometric realization of the intrinsic hyperbolic surface. The Riemann surface structure is provided by the original `(2,3,7)` triangles and gluing data, not the displayed Euclidean angles.

The JSON contains coordinates in original quotient vertex order, source faces, and explicit forward mappings of every vertex/chamber. The UI can preserve existing face picking, mirror neighbours, and word galleries unchanged.

## Data hashes

- `research-macbeath-D2.obj`: SHA-256 `c02fbe4541ed55a41bd9bc48dcf5e6f54d5c62df47deccf0bc2fb293e40d8932`
- `research-macbeath-D3.obj`: SHA-256 `2c9cb0182394600144b0b96414b597c0ee8a38ee4ce96f8ea7e317cf4ad70a3e`
- `research-macbeath-S2.obj`: SHA-256 `cfc421c18e6e02762f1bc92a02124bc813a1c72b7f08235e89e02c949536b443`
