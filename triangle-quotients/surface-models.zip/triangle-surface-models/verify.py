"""Check source package integrity and the included final model certificates."""
import hashlib
import json
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parent
hashes = json.loads((ROOT / 'SOURCE-SHA256.json').read_text())
for name, expected in hashes.items():
    relative = PurePosixPath(name)
    assert not relative.is_absolute() and '..' not in relative.parts
    actual = hashlib.sha256(ROOT.joinpath(*relative.parts).read_bytes()).hexdigest()
    assert actual == expected, f'Hash mismatch: {name}'
certificates = json.loads((ROOT / 'CONSTRUCTION-CERTIFICATES.json').read_text())
for name, chambers, genus in [('a6', 720, 10), ('m11', 15840, 631)]:
    cert = certificates[name]['verification']
    assert cert['originalChambers'] == chambers and cert['genus'] == genus
    assert cert['vertices'] - cert['edges'] + cert['refinedTriangles'] == 2 - 2 * genus
    for key in ['allEdgesTwoFaces', 'consistentOrientation', 'sourceChartsConserveArea',
                'sourceChartContinuity', 'originalAdjacencyVerified']:
        assert cert[key], (name, key)
    assert cert['minimumOtherStemClearance'] > cert['routeClearanceRequired']
    assert cert['horizontalLayerGap'] > 0
    audit = json.loads((ROOT / 'course-update-20260925' / 'all-surfaces' /
                        (name + '-tubes-independent-verification.json')).read_text())
    assert audit['originalChamberDisks'] == chambers and audit['genus'] == genus
    assert audit['minimumSourceArea'] > 0 and audit['maximumSourceAreaError'] < 1e-9
    assert audit['localTrianglePairCandidates'] > 0 and not audit['intersectionFailures']
    print(name, chambers, 'original chamber disks; genus', genus,
          '; local candidates', audit['localTrianglePairCandidates'], '; audit passed')
print('Verified', len(hashes), 'source file hashes and both construction certificates.')
