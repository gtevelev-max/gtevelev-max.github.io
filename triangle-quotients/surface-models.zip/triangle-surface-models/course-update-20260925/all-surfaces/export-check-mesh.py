"""Export a compact binary mesh for independent compiled intersection audit."""
import array,json,pathlib,struct,sys
p=pathlib.Path(sys.argv[1]);d=json.loads(p.read_text());out=p.with_suffix('.check.bin')
with out.open('wb') as f:
 f.write(struct.pack('<4I',len(d['positions']),len(d['patches']),len(d['tubes']),0))
 array.array('d',(x for p in d['positions'] for x in p)).tofile(f)
 array.array('I',(v for p in d['patches'] for v in p['vertices'])).tofile(f)
 for t in d['tubes']: f.write(struct.pack('<IId',t['patchStart'],t['patchEnd'],t['radius']))
print(out, out.stat().st_size)
