"""Download the public packed models and verify their archived hashes."""
import hashlib
import json
from pathlib import Path, PurePosixPath
from urllib.request import urlopen

ROOT = Path(__file__).resolve().parent
manifest = json.loads((ROOT / 'WEB-ASSET-HASHES.json').read_text())
site = ROOT / 'github-homepage' / 'triangle-quotients'
for name, expected in manifest['assets'].items():
    relative = PurePosixPath(name)
    assert relative.parts[0] == 'surface-data' and '..' not in relative.parts
    destination = site.joinpath(*relative.parts)
    if destination.exists():
        data = destination.read_bytes()
        if len(data) == expected['bytes'] and hashlib.sha256(data).hexdigest() == expected['sha256']:
            print('Verified existing', name)
            continue
    with urlopen(manifest['baseURL'] + name, timeout=90) as response:
        data = response.read()
    assert len(data) == expected['bytes'], f'Unexpected byte count: {name}'
    assert hashlib.sha256(data).hexdigest() == expected['sha256'], f'Hash mismatch: {name}'
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(data)
    print('Downloaded and verified', name)
