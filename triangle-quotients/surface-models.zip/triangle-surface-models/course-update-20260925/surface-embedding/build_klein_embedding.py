#!/usr/bin/env python3
"""Match the Schulte–Wills polyhedron's flags to the exact Klein quotient.

Only numerical data, not third-party rendering code, are extracted from the
public coordinate page. See README.md for provenance and geometric caveats.
"""
import itertools
import json
import re
from collections import defaultdict, deque
from fractions import Fraction as Q
from pathlib import Path

ROOT = Path(__file__).resolve().parent
QUOTIENT = ROOT.parent / 'quotient-data' / 'klein.json'


def sub(a, b): return tuple(x-y for x, y in zip(a, b))
def dot(a, b): return sum(x*y for x, y in zip(a, b))
def cross(a, b):
    return (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])


def plane_cut(poly, normal, origin):
    """Exact vertices of the intersection of a triangle and a plane."""
    ds = [dot(normal, sub(v, origin)) for v in poly]
    points = [v for v, d in zip(poly, ds) if not d]
    for i in range(3):
        j = (i+1) % 3
        if ds[i]*ds[j] < 0:
            t = Q(ds[i], ds[i]-ds[j])
            points.append(tuple(a+t*(b-a) for a, b in zip(poly[i], poly[j])))
    return list(dict.fromkeys(points))


def coplanar_overlap(a, b, normal):
    """Exact convex polygon clipping, retaining point and edge contacts."""
    drop = max(range(3), key=lambda k: abs(normal[k]))
    axes = [i for i in range(3) if i != drop]
    def orient(p, q, r):
        return (q[axes[0]]-p[axes[0]])*(r[axes[1]]-p[axes[1]])-(q[axes[1]]-p[axes[1]])*(r[axes[0]]-p[axes[0]])
    sign = 1 if orient(*b) > 0 else -1
    poly = a[:]
    for i in range(3):
        u, v = b[i], b[(i+1) % 3]
        result = []
        for j in range(len(poly)):
            p, q = poly[j-1], poly[j]
            d, e = sign*orient(u,v,p), sign*orient(u,v,q)
            if (d < 0) != (e < 0):
                t = Q(d,d-e)
                result.append(tuple(x+t*(y-x) for x,y in zip(p,q)))
            if e >= 0: result.append(q)
        poly = result
    return list(dict.fromkeys(poly))


def allowed_contact(p, shared):
    if not shared: return False
    if len(shared) == 1: return p == shared[0]
    u,v = shared
    return cross(sub(p,u),sub(v,u)) == (0,0,0) and dot(sub(p,u),sub(p,v)) <= 0


def verify_embedding(vertices, faces):
    """Every pair intersects exactly in its combinatorially shared simplex.

    Uses rational arithmetic throughout; unlike a visual check or floating
    epsilon test, this detects touching/overlapping faces as well as crossings.
    """
    polys = [[tuple(vertices[i]) for i in f] for f in faces]
    normals = [cross(sub(t[1],t[0]), sub(t[2],t[0])) for t in polys]
    assert all(n != (0,0,0) for n in normals), 'Degenerate triangle'
    checks = 0
    for i,j in itertools.combinations(range(len(faces)),2):
        a,b = polys[i],polys[j]
        if any(max(p[k] for p in a) < min(p[k] for p in b) or max(p[k] for p in b) < min(p[k] for p in a) for k in range(3)):
            checks += 1
            continue
        n,m = normals[i],normals[j]
        line = cross(n,m)
        shared = [tuple(vertices[v]) for v in set(faces[i]) & set(faces[j])]
        if line == (0,0,0):
            if dot(n,sub(b[0],a[0])):
                checks += 1
                continue
            points = coplanar_overlap(a,b,n)
            assert all(allowed_contact(p,shared) for p in points), ('Coplanar overlap',i,j,points)
        else:
            ca,cb = plane_cut(a,m,b[0]),plane_cut(b,n,a[0])
            if ca and cb:
                k = max(range(3),key=lambda k:abs(line[k]))
                lo = max(min(p[k] for p in ca),min(p[k] for p in cb))
                hi = min(max(p[k] for p in ca),max(p[k] for p in cb))
                if lo <= hi:
                    assert shared, ('Nonincident triangle intersection',i,j)
                    smin,smax = min(p[k] for p in shared),max(p[k] for p in shared)
                    assert smin <= lo <= hi <= smax, ('Excess intersection',i,j,lo,hi,shared)
        checks += 1
    return checks


def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--source',help='Optional downloaded McCooey HTML coordinate page; otherwise use the included numerical data.')
    args = parser.parse_args()
    if args.source:
        html = Path(args.source).read_text()
        rawv = re.search(r'class=Vertices value="([^"]+)"',html).group(1)
        rawf = re.search(r'class=Faces value="([^"]+)"',html).group(1)
        v = [[int(float(n)) for n in x.split()] for x in rawv.split(',')]
        f = [[int(n) for n in x.strip(' ,\n').split()] for x in rawf.split('#') if x.strip(' ,\n')]
    else:
        source = json.loads((ROOT/'klein-polyhedron.json').read_text())
        v,f = source['vertices'],source['faces']
    assert len(v) == 24 and len(f) == 56
    print('Coarse triangle-pair checks:', verify_embedding(v,f))
    edges = sorted({tuple(sorted((t[i],t[(i+1)%3]))) for t in f for i in range(3)})
    edge_id = {e:i for i,e in enumerate(edges)}
    flags = []
    # Local type order agrees with the quotient: edge midpoint, face center, vertex.
    positions = [tuple(Q(v[a][k]+v[b][k],2) for k in range(3)) for a,b in edges]
    positions += [tuple(Q(sum(v[a][k] for a in t),3) for k in range(3)) for t in f]
    positions += [tuple(p) for p in v]
    for j,t in enumerate(f):
        for i in range(3):
            a,b = t[i],t[(i+1)%3]
            e = edge_id[tuple(sorted((a,b)))]
            flags += [(e,84+j,140+a),(e,84+j,140+b)]
    incidence = defaultdict(list)
    for j,flag in enumerate(flags):
        for side in range(3):
            incidence[tuple(flag[k] for k in range(3) if k != side)].append((j,side))
    neighbors = [[None]*3 for _ in flags]
    assert len(incidence) == 504
    for occurrences in incidence.values():
        assert len(occurrences) == 2
        (i,s),(j,t) = occurrences
        assert s == t
        neighbors[i][s] = j
        neighbors[j][s] = i
    data = json.loads(QUOTIENT.read_text())
    face_map = {0:0}
    vertex_map = {}
    queue = deque([0])
    while queue:
        i = queue.popleft()
        j = face_map[i]
        for a,b in zip(data['faceVertices'][i],flags[j]):
            assert a not in vertex_map or vertex_map[a] == b
            vertex_map[a] = b
        for s in range(3):
            a,b = data['neighbors'][i][s],neighbors[j][s]
            if a in face_map: assert face_map[a] == b
            else: face_map[a] = b; queue.append(a)
    assert len(face_map) == len(set(face_map.values())) == 336
    assert len(vertex_map) == len(set(vertex_map.values())) == 164
    exact_positions = [positions[vertex_map[i]] for i in range(164)]
    checks = verify_embedding(exact_positions,data['faceVertices'])
    print('Chamber triangle-pair checks:',checks)
    reverse = {b:a for a,b in vertex_map.items()}
    coarse = [[reverse[140+i] for i in t] for t in f]
    coarse_for_chamber = [flags[face_map[i]][1]-84 for i in range(336)]
    volume = sum(dot(v[t[0]],cross(v[t[1]],v[t[2]])) for t in f)/6
    out = {
        'id':'klein',
        'title':'Klein quartic — Schulte–Wills polyhedral embedding',
        'description':'An embedded topological model of the Klein quartic. Its 56 triangles are barycentrically subdivided into the exact 336 quotient chambers; lengths and angles are not the hyperbolic metric.',
        'positions':[[float(x) for x in p] for p in exact_positions],
        'coarseFaces':coarse,
        'coarseFaceForChamber':coarse_for_chamber,
        'sourceVertices':v,
        'sourceFaces':f,
        'quotientVertexToSourceBarycentricVertex':[vertex_map[i] for i in range(164)],
        'quotientChamberToSourceFlag':[face_map[i] for i in range(336)],
        'sources':[
            {'title':'Schulte and Wills (1985), A polyhedral realization of Felix Klein’s map {3,7}₈ on a Riemann surface of genus 3','url':'https://doi.org/10.1112/jlms/s2-32.3.539'},
            {'title':'Scholl, Schürmann and Wills, Polyhedral models of Felix Klein’s quartic','url':'https://math.ucr.edu/home/baez/klein_quartic_scholl.pdf'},
            {'title':'David I. McCooey, integer coordinate data for the Schulte–Wills polyhedron','url':'https://dmccooey.com/polyhedra/KleinDual.html'}
        ],
        'verification':{
            'coarseVertexCount':24,'coarseEdgeCount':84,'coarseFaceCount':56,
            'vertexCount':164,'edgeCount':504,'chamberCount':336,'euler':-4,'genus':3,
            'sideLabeledChamberGraphIsomorphism':True,
            'exactRationalTrianglePairIntersectionChecks':checks,
            'extraneousTriangleIntersections':0,
            'coarseSignedVolume':volume,
            'allSharedEdgesAndVerticesCoincide':True
        }
    }
    (ROOT/'klein-embedding.json').write_text(json.dumps(out,separators=(',',':'))+'\n')
    print(json.dumps(out['verification'],indent=2))


if __name__ == '__main__': main()
