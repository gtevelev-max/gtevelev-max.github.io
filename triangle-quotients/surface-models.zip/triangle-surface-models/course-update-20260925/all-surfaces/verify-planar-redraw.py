#!/usr/bin/env python3
"""Independent checks that a redrawing preserves a capped planar disk."""
import hashlib,json,sys
import numpy as np

def verify(original_file,redrawn_file):
 a=json.load(open(original_file));b=json.load(open(redrawn_file));p=np.asarray(b['positions'],dtype=float)
 assert a['id']==b['id'] and a['genus']==b['genus']
 assert a['patches']==b['patches'] and a['outerFacePatch']==b['outerFacePatch']
 assert len(a['positions'])==len(p) and np.isfinite(p).all()
 assert len(a['holes'])==len(b['holes'])
 for ha,hb in zip(a['holes'],b['holes']):
  assert {k:v for k,v in ha.items() if k!='center'}=={k:v for k,v in hb.items() if k!='center'}
  assert list(p[hb['centerVertex']])==hb['center']
 f=[v['vertices'] for v in b['patches']]
 for h in b['holes']:
  vs=h['vertices'];f.extend([[h['centerVertex'],vs[(i+1)%len(vs)],v] for i,v in enumerate(vs)])
 f=np.asarray(f);av=p[f[:,1]]-p[f[:,0]];bv=p[f[:,2]]-p[f[:,0]];areas=av[:,0]*bv[:,1]-av[:,1]*bv[:,0]
 assert (areas>0).all() or (areas<0).all()
 o=p[b['outerFacePatch']['vertices']];out=(o[1,0]-o[0,0])*(o[2,1]-o[0,1])-(o[1,1]-o[0,1])*(o[2,0]-o[0,0])
 assert out*areas[0]<0
 residual=abs(float(sum(areas)+out));assert residual<1e-10*abs(out)
 # Every capped oriented edge is paired, except the outer triangle's boundary.
 edge={}
 for face in f:
  for i in range(3):
   u,v=map(int,[face[i],face[(i+1)%3]]);key=tuple(sorted([u,v]));edge.setdefault(key,[]).append((u,v))
 boundary=[]
 for e,inc in edge.items():
  assert len(inc) in (1,2)
  if len(inc)==1:boundary.append(e)
  else:assert inc[0]==inc[1][::-1]
 ov=b['outerFacePatch']['vertices'];assert set(boundary)=={tuple(sorted([ov[i],ov[(i+1)%3]])) for i in range(3)}
 assert len(p)-len(edge)+len(f)==1
 return dict(id=b['id'],genus=b['genus'],vertices=len(p),cappedTriangles=len(f),outerBoundaryEdges=3,diskEulerCharacteristic=1,sourceChamberChartsUnchanged=True,collarPairingsUnchanged=True,allSignedAreasSameStrictSign=True,minimumTriangleArea=float(min(abs(areas))/2),areaPartitionResidual=residual,originalSHA256=hashlib.sha256(open(original_file,'rb').read()).hexdigest(),redrawnSHA256=hashlib.sha256(open(redrawn_file,'rb').read()).hexdigest())

if __name__=='__main__':
 result=verify(sys.argv[1],sys.argv[2]);print(json.dumps(result,indent=2))
 if len(sys.argv)>3:json.dump(result,open(sys.argv[3],'w'),indent=2)
