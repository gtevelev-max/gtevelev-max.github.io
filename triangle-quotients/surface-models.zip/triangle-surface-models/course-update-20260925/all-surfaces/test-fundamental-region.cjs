/* Run: node course-update-20260925/all-surfaces/test-fundamental-region.cjs
 * Tests the actual covering region used as the source of the gluing animation.
 */
'use strict';
const fs = require('node:fs'), path = require('node:path'), assert = require('node:assert/strict');
const base = path.resolve(__dirname, '../../github-homepage/triangle-quotients');
const Math3 = require(path.join(base, 'geometry.js'));
const Net = require(path.join(base, 'cut-net.js'));
const Region = require(path.join(base, 'fundamental-region.js'));
const results = [];
for (const id of ['a4','s4','a5','torus','klein','a6','macbeath','m11']) {
  const data = JSON.parse(fs.readFileSync(path.join(__dirname, '../quotient-data', id + '.json')));
  const geometry = Math3.makeGeometry(...data.signature), original = Net.build(data);
  const regionNet = Region.layout(data, geometry, Math3, original), region = regionNet.region;
  if (geometry.k === 1) {
    assert.equal(regionNet, original);
    results.push({id, sphericalCutDiskPreserved: true, chambers: data.faceVertices.length});
    continue;
  }
  const F = data.faceVertices.length;
  // Independent exact check that all three neighbor permutations realize the
  // reflection presentation.  This makes the finite chamber labels a genuine
  // action of the triangle reflection group, not an arbitrary graph.
  for (let f = 0; f < F; f++) {
    for (let s = 0; s < 3; s++) assert.equal(data.neighbors[data.neighbors[f][s]][s], f);
    for (let type = 0; type < 3; type++) {
      let at = f;
      for (let k = 0; k < data.signature[type]; k++) {
        at = data.neighbors[at][(type + 1) % 3];
        at = data.neighbors[at][(type + 2) % 3];
      }
      assert.equal(at, f);
    }
  }
  assert.equal(region.faceCount, F);
  assert.equal(region.euler, 1);
  assert.equal(region.vertexCount - region.edgeCount + F, 1);
  assert.equal(region.seams.length * 2, region.boundaryCount);
  assert.equal(region.internalEdges.size * 2 + region.boundaryCount, F * 3);
  assert.equal(new Set(region.boundary.map(e => e.start)).size, region.boundaryCount);
  for (let i = 0; i < region.boundaryCount; i++) {
    assert.equal(region.boundary[i].end, region.boundary[(i + 1) % region.boundaryCount].start);
  }
  let triangleArea = 0, boundaryArea = 0, minProjectedEdgeLength = Infinity;
  for (let f = 0; f < F; f++) {
    const tri = regionNet.corners[f].map(v => regionNet.positions[v]);
    for (const p of tri) assert(p.every(Number.isFinite));
    for (let k = 0; k < 3; k++) minProjectedEdgeLength = Math.min(minProjectedEdgeLength,
      Math.hypot(tri[k][0]-tri[(k+1)%3][0],tri[k][1]-tri[(k+1)%3][1]));
    const [a,b,c] = tri;
    const area = ((b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0]))*(f&1 ? -.5 : .5);
    assert(area > 0); triangleArea += area;
  }
  for (const e of region.boundary) {
    const a = regionNet.positions[e.start], b = regionNet.positions[e.end];
    boundaryArea += (a[0]*b[1]-a[1]*b[0])/2;
    assert(!region.internalEdges.has(e.edge));
  }
  // An independent geometric consistency check: all inner edge contributions
  // cancel, leaving precisely the actual boundary of the covering region.
  assert(Math.abs(triangleArea-boundaryArea) < 1e-10);
  // Vertex contacts between disconnected sectors would make a geometrically
  // pinched boundary even if the abstract boundary were a cycle.  Check that
  // every actual region vertex has a distinct projected position.  The least
  // edge length remains >9e-7, safely above the 1e-13 duplicate tolerance.
  const coordinateBuckets = new Map();
  for (const v of new Set(region.corners.flat())) {
    const p = regionNet.positions[v], ix = Math.round(p[0]*1e12), iy = Math.round(p[1]*1e12);
    for (let dx=-1; dx<=1; dx++) for (let dy=-1; dy<=1; dy++) {
      for (const q of coordinateBuckets.get((ix+dx)+','+(iy+dy)) || [])
        assert(Math.hypot(p[0]-q[0],p[1]-q[1]) >= 1e-13);
    }
    const key = ix+','+iy;
    if (!coordinateBuckets.has(key)) coordinateBuckets.set(key,[]);
    coordinateBuckets.get(key).push(p);
  }
  assert(minProjectedEdgeLength > 1e-8);
  for (const seam of region.seams) {
    assert.equal(data.neighbors[seam.first.face][seam.first.side], seam.second.face);
    assert.equal(seam.first.edge, seam.second.edge);
    assert.equal(seam.first.side, seam.second.side);
  }
  results.push({id, chambers:F, ...Object.fromEntries(['vertexCount','edgeCount','boundaryCount','euler','projection'].map(k => [k,region[k]])),
    pairedBoundaryEdges:region.seams.length,
    sourceTriangleArea:triangleArea, sourceBoundaryArea:boundaryArea,
    distinctGeometricVertices:true, minProjectedEdgeLength,
    exactCoxeterRelations:true, ...region.verification});
}
fs.writeFileSync(path.join(__dirname, 'fundamental-region-verification.json'), JSON.stringify({
  claim:'For each nonspherical quotient the animation starts with an actual connected fundamental region of covering triangles, with one representative of every finite quotient chamber.',
  nonoverlapJustification:'The exact neighbor permutations obey the Coxeter reflection relations. Representative words reaching distinct quotient chambers cannot represent the same covering chamber. The faithful geometric reflection tessellation has disjoint chamber interiors. After joining all actual covering adjacencies, the resulting region has one simple boundary cycle and Euler characteristic 1.',
  projection:'Hyperbolic triangles use the Klein disk, where geodesic edges are straight. Euclidean triangles are translated and uniformly scaled. These display projections do not change the chamber labels or boundary identifications.',
  results
},null,2)+'\n');
console.log(JSON.stringify(results.map(({id,chambers,boundaryCount,euler,minProjectedTriangleArea,maxRadius,treeCornerError}) => ({id,chambers,boundaryCount,euler,minProjectedTriangleArea,maxRadius,treeCornerError})),null,2));
