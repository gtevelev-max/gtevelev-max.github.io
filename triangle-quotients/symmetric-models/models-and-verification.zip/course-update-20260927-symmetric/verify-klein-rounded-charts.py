"""Independent source-chart, chamber-neighbor, and exact symmetry audit."""
from pathlib import Path
from fractions import Fraction as Q
from collections import defaultdict
import hashlib,json

ROOT=Path(__file__).resolve().parent
quotient=json.loads((ROOT.parent/'course-update-20260925/quotient-data/klein.json').read_text())
lookup={tuple(sorted(vs)):i for i,vs in enumerate(quotient['faceVertices'])}
reports=[]
for level in [1,2]:
 path=ROOT/f'klein-rounded-level{level}.json';d=json.loads(path.read_text());patches=d['patches']
 positions=[[Q(x) for x in p] for p in d['exactPositions']]
 assert all([Q(x) for x in p]==positions[i] for i,p in enumerate(d['positions']))
 edges={};local=defaultdict(list);segments=0
 for pi,p in enumerate(patches):
  local[p['chamber']].append(p)
  for k in range(3):
   l=(k+1)%3;a,b=p['vertices'][k],p['vertices'][l];key=tuple(sorted((a,b)))
   if key not in edges:edges[key]=(pi,k);continue
   j,m=edges[key];r=patches[j];n=(m+1)%3
   assert r['vertices'][m]==b and r['vertices'][n]==a
   assert p['bary'][k]==r['bary'][n] and p['bary'][l]==r['bary'][m]
   if p['chamber']!=r['chamber']:
    side=next(s for s in range(3) if p['bary'][k][s]==p['bary'][l][s]==0)
    assert quotient['neighbors'][p['chamber']][side]==r['chamber'];segments+=1
 assert len(local)==336
 for chamber,ps in local.items():
  ve=set();ed=defaultdict(int);area=Q(0)
  for p in ps:
   ve.update(p['vertices']);a,b,c=[[Q(x) for x in w] for w in p['bary']]
   area+=abs((b[1]-a[1])*(c[2]-a[2])-(b[2]-a[2])*(c[1]-a[1]))
   for k in range(3):ed[tuple(sorted((p['vertices'][k],p['vertices'][(k+1)%3])))]+=1
  assert area==1 and len(ve)-len(ed)+len(ps)==1 and max(ed.values())==2
  boundary=defaultdict(set)
  for (a,b),count in ed.items():
   if count==1:boundary[a].add(b);boundary[b].add(a)
  assert all(len(ns)==2 for ns in boundary.values())
  seen={next(iter(boundary))};todo=list(seen)
  for a in todo:
   for b in boundary[a]:
    if b not in seen:seen.add(b);todo.append(b)
  assert seen==set(boundary)
 for g in d['symmetryGenerators']:
  m=g['vertexPermutation'];perm=g['permutation'];signs=g['signs']
  for i,j in enumerate(m):assert [signs[k]*positions[i][perm[k]] for k in range(3)]==positions[j]
  cm=[lookup[tuple(sorted(m[v] for v in face))] for face in quotient['faceVertices']]
  assert len(set(cm))==336
  for f in range(336):
   assert cm[f]%2==f%2
   for side in range(3):assert cm[quotient['neighbors'][f][side]]==quotient['neighbors'][cm[f]][side]
 reports.append({'file':path.name,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'level':level,'vertices':len(positions),'patches':len(patches),'originalChamberDisks':336,'sourceChartsContinuous':True,'sourceAreasExactlyOne':True,'originalNeighborSegmentsChecked':segments,'exactTetrahedralRotations':12,'rotationsPreserveOriginalSideLabels':True,'allCoordinatesExactlyRepresentableInFloat64':True})
(ROOT/'klein-rounded-chart-verification.json').write_text(json.dumps(reports,indent=2)+'\n')
print(json.dumps(reports,indent=2))
