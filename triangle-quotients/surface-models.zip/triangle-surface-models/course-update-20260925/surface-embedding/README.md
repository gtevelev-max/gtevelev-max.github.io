# The actual 336-chamber Klein surface in three dimensions

`klein-embedding.json` gives a non-self-intersecting piecewise-linear embedding
of the exact chamber complex in `../quotient-data/klein.json`. This is not a
generic three-holed mesh with an unrelated triangulation placed on it.

The construction begins with the Schulte–Wills polyhedral realization of the
regular map `{3,7}_8`: 24 vertices, 84 edges, and 56 triangular faces. Each face
is divided barycentrically into six triangles. The result has 164 vertices,
504 edges, and **336 triangles**. Its Euler characteristic is −4 and its genus
is 3. The ordered types in each small triangle are edge midpoint (p = 2), face
center (q = 3), and original vertex (r = 7).

Every small triangle is matched to its original quotient chamber by a
side-labelled graph isomorphism. The map is propagated from one chosen flag
using the three reflection adjacencies. Thus the existing chamber numbers,
group labels, edge identifications, and word walks remain valid.

The shape is a topological, not an isometric, model of the Klein quartic. Its
Euclidean angles and lengths do not reproduce the hyperbolic metric. Its
tetrahedral appearance can show four twisted passage mouths; four passages
joining two sheets have genus three, not four. Rotation helps reveal its
topology. A deformation used to assemble the model may pass through other
triangles; the final embedded surface does not.

## Integration

- `positions[vertexId]`: 3D coordinate, indexed exactly by the existing
  quotient vertex IDs. Coordinates are roughly within the cube [−6,6]^3.
- Use the original `klein.json.faceVertices` for all 336 triangles.
- `coarseFaces`: the 56 original triangles, also using quotient vertex IDs.
- `coarseFaceForChamber[chamberId]`: index of its original large triangle.
- For consistent outward normals, orient an **even** chamber as `(p,q,r)` and
  an **odd** chamber as `(p,r,q)`. The opposite global orientation is also
  consistent, but points inward.
- `quotientVertexToSourceBarycentricVertex` and
  `quotientChamberToSourceFlag` record the matching explicitly.
- `sources` contains citations suitable for the demonstration's source panel.

## Reproduce and verify

Run with standard Python 3; no external packages are required:

```sh
python3 build_klein_embedding.py
```

The builder uses the included numerical coordinates in `klein-polyhedron.json`.
An optional `--source path/to/KleinDual.html` extracts the same numerical data
from a downloaded copy of the coordinate page. No third-party renderer is used.

The verification checks all 1,540 pairs of large triangles and all 56,280 pairs
of small triangles with **exact rational arithmetic**. Every pair intersects
only in its combinatorially shared vertex or edge, if any; disjoint triangles
are disjoint. The test includes coplanar contacts and overlapping faces, not
just transverse crossings. No degenerate triangles occur. The side-labelled
chamber isomorphism is bijective on all 336 faces and all 164 vertices.

## Sources

1. E. Schulte and J. M. Wills, “A polyhedral realization of Felix Klein's map
   {3,7}_8 on a Riemann surface of genus 3,” *Journal of the London Mathematical
   Society* 32 (1985), 539–547,
   [doi:10.1112/jlms/s2-32.3.539](https://doi.org/10.1112/jlms/s2-32.3.539).
2. P. Scholl, A. Schürmann, and J. M. Wills,
   [*Polyhedral models of Felix Klein's quartic*](https://math.ucr.edu/home/baez/klein_quartic_scholl.pdf).
   The authors distinguish the embedded tetrahedral model used here from the
   self-intersecting octahedral realization.
3. David I. McCooey,
   [numerical coordinates and incidences for the Schulte–Wills polyhedron](https://dmccooey.com/polyhedra/KleinDual.html).
   Only the mathematical coordinate and incidence data are used, with credit.
