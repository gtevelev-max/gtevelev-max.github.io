'use strict';
const fs = require('fs');
const path = require('path');
const assert = require('assert/strict');
const localModule = path.join(__dirname, 'cut-net.js');
const {build} = require(fs.existsSync(localModule) ? localModule : path.join(__dirname, '../../github-homepage/triangle-quotients/cut-net.js'));
const names = ['a4','s4','a5','torus','klein','a6','macbeath','m11'];
for (const name of names) {
  const data = JSON.parse(fs.readFileSync(path.join(__dirname, name+'.json')));
  const start = performance.now();
  const net = build(data);
  assert.equal(net.boundary.length, data.faceVertices.length + 2);
  assert.equal(net.seams.length, data.order + 1);
  assert.equal(net.treeEdges.size, data.faceVertices.length - 1);
  assert.equal(net.euler, 1);
  let area = 0;
  for (let f = 0; f < net.corners.length; f++) {
    const indices = f % 2 ? [0,2,1] : [0,1,2];
    const [a,b,c] = indices.map(i => net.positions[net.corners[f][i]]);
    const twiceArea = (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0]);
    assert(twiceArea > 0, 'non-positive triangle area '+name+' '+f);
    area += twiceArea / 2;
  }
  const B = net.boundary.length;
  assert(Math.abs(area - B*Math.sin(2*Math.PI/B)/2) < 1e-10);
  // Re-gluing each seam reverses the induced boundary orientation and
  // restores matching quotient vertex IDs at both endpoints.
  const globalAtCutCorner = new Map();
  for (let f=0; f<data.faceVertices.length; f++) {
    for (let t=0; t<3; t++) {
      const root = net.corners[f][t], vertex = data.faceVertices[f][t];
      if (globalAtCutCorner.has(root)) assert.equal(globalAtCutCorner.get(root), vertex);
      globalAtCutCorner.set(root, vertex);
    }
  }
  for (const {first,second} of net.seams) {
    assert.equal(globalAtCutCorner.get(first.start),globalAtCutCorner.get(second.end));
    assert.equal(globalAtCutCorner.get(first.end),globalAtCutCorner.get(second.start));
  }
  console.log(name+': '+net.faceCount+' triangles, '+B+' boundary sides, '+net.seams.length+' seam pairs; positive nonoverlapping triangles, complete polygon area, reversed seam endpoints; '+(performance.now()-start).toFixed(1)+'ms');
}
console.log('All eight exact cut-net checks passed.');
