/* Construct a closed embedded surface from an exact planar cut surface.
 * Input: cut_to_planar.py output; output retains every original chamber's
 * piecewise-affine barycentric chart. No original triangle is relabelled.
 * Variable tube radii use local endpoint spacing. Visibility routes avoid other
 * vertical stems, and a DSATUR coloring lets disjoint horizontal routes share
 * height layers. Exact source charts are retained through each refinement.
 */
'use strict';
const fs = require('fs');
const EPS=1e-12, TAU=2*Math.PI;
function fail(c,s){if(!c)throw Error(s);}
const add=(a,b)=>a.map((v,i)=>v+b[i]);
const sub=(a,b)=>a.map((v,i)=>v-b[i]);
const mul=(a,s)=>a.map(v=>v*s);
const dot=(a,b)=>a.reduce((s,v,i)=>s+v*b[i],0);
const norm=a=>Math.sqrt(dot(a,a));
const unit=a=>mul(a,1/norm(a));
const cross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];
const mix=(a,b,t)=>a.map((x,i)=>x+(b[i]-x)*t);
const distance=(a,b)=>norm(sub(a,b));
function pointSegment(p,a,b){let q=0,num=0;for(let k=0;k<p.length;k++){const d=b[k]-a[k];q+=d*d;num+=(p[k]-a[k])*d;}const t=q?Math.max(0,Math.min(1,num/q)):0;let sum=0;for(let k=0;k<p.length;k++){const d=p[k]-a[k]-t*(b[k]-a[k]);sum+=d*d;}return Math.sqrt(sum);}
function wrap(t){while(t<=-Math.PI)t+=TAU;while(t>Math.PI)t-=TAU;return t;}
function unwrappedAngles(points,c,frame){let out=[];for(const p of points){const d=sub(p,c);let a=Math.atan2(dot(d,frame[1]),dot(d,frame[0]));if(out.length)a=out.at(-1)+wrap(a-out.at(-1));out.push(a);}return out;}
function transport(frame,t0,t1){const ax=cross(t0,t1),s=norm(ax),c=dot(t0,t1);if(s<1e-12)return frame;const u=mul(ax,1/s);function rot(v){return add(add(mul(v,c),mul(cross(u,v),s)),mul(u,dot(u,v)*(1-c)));}return frame.map(rot);}
function polylineFrames(path){const ds=path.slice(1).map((p,i)=>unit(sub(p,path[i]))),ts=path.map((p,i)=>i===0?ds[0]:i===path.length-1?ds.at(-1):unit(add(ds[i-1],ds[i])));const frames=[[[1,0,0],[0,1,0]]];for(let i=1;i<path.length;i++)frames.push(transport(frames.at(-1),ts[i-1],ts[i]));return frames;}
// Obstacles are separated by at least 20 rho. Replacing a straight segment
// locally by an arc of radius 4 rho stays inside pairwise-disjoint disks.
function routeXY(a,b,centers,skip,rho,trySimple=true){
  function clearSegment(p,q){for(let j=0;j<centers.length;j++)if(!skip.has(j)&&pointSegment(centers[j],p,q)<3*rho)return false;return true;}
  if(trySimple&&clearSegment(a,b))return [a.slice(),b.slice()];
  const axis=sub(b,a),length=norm(axis),perp=[-axis[1]/length,axis[0]/length],mid=mix(a,b,.5);
  // A generic two-segment route avoids accidentally collinear integer-grid
  // cap centers and usually replaces dozens of local obstacle detours.
  for(let attempt=0;trySimple&&attempt<80;attempt++){
    const fraction=((attempt*.6180339887498949+.1732050807568877)%1),offset=(.07+.36*fraction)*(attempt%2?-1:1),shift=.14*Math.sin(attempt*2.399963229728653);
    const w=add(add(mid,mul(perp,length*offset)),mul(axis,shift));
    const incoming=unit(sub(w,a)),outgoing=unit(sub(b,w));
    if(dot(incoming,outgoing)<0)continue;
    if(distance(a,w)<5*rho||distance(w,b)<5*rho)continue;
    if(clearSegment(a,w)&&clearSegment(w,b))return [a.slice(),w,b.slice()];
  }
  const d=sub(b,a),L=norm(d),u=mul(d,1/L),v=[-u[1],u[0]],hits=[];
  for(let j=0;j<centers.length;j++)if(!skip.has(j)){
    const rel=sub(centers[j],a),x=dot(rel,u),y=dot(rel,v);
    if(x>0&&x<L&&Math.abs(y)<3*rho){const half=Math.sqrt((8*rho)**2-y*y);hits.push({j,x,y,lo:x-half,hi:x+half});}
  }
  hits.sort((a,b)=>a.lo-b.lo);const path=[a.slice()];
  for(const h of hits){
    fail(h.lo>0&&h.hi<L,'Obstacle overlaps a tube endpoint');
    const c=centers[h.j],p0=add(a,mul(u,h.lo)),p1=add(a,mul(u,h.hi));
    const ang0=Math.atan2(p0[1]-c[1],p0[0]-c[0]),ang1=Math.atan2(p1[1]-c[1],p1[0]-c[0]);
    let delta=wrap(ang1-ang0); // minor circular detour, away from obstacle center
    const steps=Math.max(2,Math.ceil(Math.abs(delta)/(Math.PI/12)));
    path.push(p0);for(let k=1;k<=steps;k++){const angle=ang0+delta*k/steps;path.push([c[0]+8*rho*Math.cos(angle),c[1]+8*rho*Math.sin(angle)]);}
  }
  path.push(b.slice());return path;
}

function segmentDistance2(a,b,c,d){
  const u=sub(b,a),v=sub(d,c),det=u[0]*v[1]-u[1]*v[0],w=sub(c,a);
  if(Math.abs(det)>1e-20){const t=(w[0]*v[1]-w[1]*v[0])/det,z=(w[0]*u[1]-w[1]*u[0])/det;if(t>=0&&t<=1&&z>=0&&z<=1)return 0;}
  return Math.min(pointSegment(a,c,d),pointSegment(b,c,d),pointSegment(c,a,b),pointSegment(d,a,b));
}
function variableRoute(a,b,centers,skip,radius,obstacleRadii){
  function clear(p,q){for(let j=0;j<centers.length;j++)if(!skip.has(j)&&pointSegment(centers[j],p,q)<1.16*(radius+obstacleRadii[j]))return false;return true;}
  if(clear(a,b))return [a.slice(),b.slice()];
  const axis=sub(b,a),length=norm(axis),perp=[-axis[1]/length,axis[0]/length],mid=mix(a,b,.5);
  let best=null,bestLength=Infinity;
  for(let attempt=0;attempt<800;attempt++){
    const fraction=((attempt*.6180339887498949+.1732050807568877)%1),offset=(.03+.8*fraction)*(attempt%2?-1:1),shift=.44*Math.sin(attempt*2.399963229728653);
    const w=add(add(mid,mul(perp,length*offset)),mul(axis,shift));
    const incoming=unit(sub(w,a)),outgoing=unit(sub(b,w));
    if(dot(incoming,outgoing)<0)continue;
    if(distance(a,w)<5*radius||distance(w,b)<5*radius)continue;
    const len=distance(a,w)+distance(w,b);if(len>=bestLength)continue;
    if(clear(a,w)&&clear(w,b)){best=[a.slice(),w,b.slice()];bestLength=len;}
  }
  return best;
}

function visibilityRoute(a,b,centers,skip,radius,obstacleRadii){
  const rs=obstacleRadii.map(r=>1.12*(r+radius)),active=new Set();
  function blockers(p,q){const out=[];for(let j=0;j<centers.length;j++)if(!skip.has(j)&&pointSegment(centers[j],p,q)<rs[j])out.push(j);return out;}
  blockers(a,b).forEach(i=>active.add(i));
  for(let pass=0;pass<8;pass++){
    let points=[a.slice(),b.slice()];
    for(const j of active)for(let k=0;k<12;k++){const theta=TAU*k/12,rr=1.12*rs[j];points.push([centers[j][0]+rr*Math.cos(theta),centers[j][1]+rr*Math.sin(theta)]);}
    points=points.filter((p,i)=>i<2||!centers.some((c,j)=>!skip.has(j)&&distance(c,p)<rs[j]));
    const ds=points.map(()=>Infinity),parents=points.map(()=>-1),done=points.map(()=>false),nextObstacles=new Set();ds[0]=0;
    for(let step=0;step<points.length;step++){
      let u=-1,best=Infinity;for(let i=0;i<points.length;i++)if(!done[i]&&ds[i]<best){best=ds[i];u=i;}
      if(u<0)break;if(u===1){const path=[];for(let i=1;i>=0;i=parents[i])path.push(points[i]);path.reverse();return path;}
      done[u]=true;
      for(let v=1;v<points.length;v++)if(!done[v]){
        const length=distance(points[u],points[v]);if(ds[u]+length>=ds[v])continue;
        const block=blockers(points[u],points[v]);if(block.length){for(const j of block)nextObstacles.add(j);continue;}
        ds[v]=ds[u]+length;parents[v]=u;
      }
    }
    const old=active.size;for(const j of nextObstacles)active.add(j);if(active.size===old||active.size>150)break;
  }
  return null;
}

function prepareRoutingGraph(graph,centers,obstacleRadii){
  const adj=graph.vertices.map(()=>[]);
  for(const [a,b] of graph.edges){
    const lowest=[];for(let i=0;i<centers.length;i++){const cap=pointSegment(centers[i],graph.vertices[a],graph.vertices[b])/1.12-obstacleRadii[i];if(lowest.length<3||cap<lowest.at(-1)[0]){lowest.push([cap,i]);lowest.sort((a,b)=>a[0]-b[0]);if(lowest.length>3)lowest.pop();}}
    adj[a].push({v:b,lowest});adj[b].push({v:a,lowest});
  }
  return {...graph,adj};
}
function sparseRoute(graph,a,b,centers,pair,radius,obstacleRadii){
  const skip=new Set(pair),nn=graph.vertices.length,points=[...graph.vertices,a,b],adj=graph.adj.map(a=>a.slice());adj.push([],[]);
  function capacity(p,q){let cap=Infinity;for(let i=0;i<centers.length;i++)if(!skip.has(i))cap=Math.min(cap,pointSegment(centers[i],p,q)/1.12-obstacleRadii[i]);return cap;}
  for(let end=0;end<2;end++)for(const v of graph.endpointNodes[pair[end]]){
    const cap=capacity(points[nn+end],points[v]);if(cap>radius){adj[nn+end].push({v,cap});adj[v].push({v:nn+end,cap});}
  }
  const ds=points.map(()=>Infinity),parents=points.map(()=>-1),heap=[];ds[nn]=0;
  function push(p){heap.push(p);let i=heap.length-1;while(i){let j=(i-1)>>1;if(heap[j][0]<=p[0])break;heap[i]=heap[j];i=j;}heap[i]=p;}
  function pop(){const top=heap[0],p=heap.pop();if(heap.length){let i=0;while(2*i+1<heap.length){let j=2*i+1;if(j+1<heap.length&&heap[j+1][0]<heap[j][0])j++;if(heap[j][0]>=p[0])break;heap[i]=heap[j];i=j;}heap[i]=p;}return top;}
  push([0,nn]);let path=null;
  while(heap.length){const [du,u]=pop();if(du!==ds[u])continue;if(u===nn+1){path=[];for(let v=u;v>=0;v=parents[v])path.push(points[v]);path.reverse();break;}
    for(const e of adj[u]){let cap=e.cap;if(cap===undefined)cap=e.lowest.find(v=>!skip.has(v[1]))[0];if(cap<=radius)continue;const dd=du+distance(points[u],points[e.v]);if(dd<ds[e.v]){ds[e.v]=dd;parents[e.v]=u;push([dd,e.v]);}}
  }
  if(!path)return null;
  // Remove needless Voronoi turns by using the farthest directly visible node.
  function simplify(path){const out=[path[0]];for(let i=0;i<path.length-1;){let j=path.length-1;while(j>i+1&&capacity(path[i],path[j])<=radius)j--;out.push(path[j]);i=j;}return out;}
  let simple=simplify(path),reverse=simplify(path.slice().reverse()).reverse();if(reverse.length<simple.length)simple=reverse;
  const directions=simple.slice(1).map((p,i)=>unit(sub(p,simple[i]))),miters=simple.map((p,i)=>i===0||i===simple.length-1?1:Math.tan(Math.acos(Math.max(-1,Math.min(1,dot(directions[i-1],directions[i]))))/2));
  for(let i=1;i<simple.length;i++)if(distance(simple[i],simple[i-1])<=1.2*radius*(miters[i-1]+miters[i]))return null;
  return simple;
}
function arrangeRoutes(centers,pairs,span,routingGraph){
  const nearest=centers.map((c,i)=>Math.min(...centers.map((d,j)=>i===j?Infinity:distance(c,d))));
  const radii=pairs.map(pair=>.30*Math.min(...pair.map(i=>nearest[i])));
  let obstacleRadii=centers.map(()=>0);for(let i=0;i<pairs.length;i++)for(const h of pairs[i])obstacleRadii[h]=radii[i];
  const routes=[],routeAttempts=[];
  if(routingGraph)routingGraph=prepareRoutingGraph(routingGraph,centers,obstacleRadii);
  // Large radii are attempted first; every later reduction only increases
  // the clearance of routes that have already been accepted.
  const order=pairs.map((_,i)=>i).sort((a,b)=>radii[b]-radii[a]);
  for(const i of order){
    const pair=pairs[i];let route=null,attempt=0;
    for(;attempt<30;attempt++){
      route=routingGraph?sparseRoute(routingGraph,centers[pair[0]],centers[pair[1]],centers,pair,radii[i],obstacleRadii):variableRoute(centers[pair[0]],centers[pair[1]],centers,new Set(pair),radii[i],obstacleRadii);
      if(!route&&!routingGraph)route=visibilityRoute(centers[pair[0]],centers[pair[1]],centers,new Set(pair),radii[i],obstacleRadii);
      if(route)break;
      radii[i]*=.82;for(const h of pair)obstacleRadii[h]=radii[i];
    }
    fail(route,'Could not find variable-radius route for handle '+i);routes[i]=route;routeAttempts[i]=attempt;if(process.env.ROUTE_PROGRESS&&routes.filter(Boolean).length%50===0)process.stderr.write('Routed '+routes.filter(Boolean).length+'/'+pairs.length+' handles\n');
  }
  const conflicts=pairs.map(()=>new Set());
  let minimumStemMargin=Infinity;
  for(let i=0;i<pairs.length;i++)for(let j=0;j<routes[i].length-1;j++)for(let h=0;h<centers.length;h++)if(!pairs[i].includes(h))minimumStemMargin=Math.min(minimumStemMargin,pointSegment(centers[h],routes[i][j],routes[i][j+1])-radii[i]-obstacleRadii[h]);
  for(let i=0;i<pairs.length;i++)for(let j=0;j<i;j++){
    let dis=Infinity;for(let a=1;a<routes[i].length;a++)for(let b=1;b<routes[j].length;b++)dis=Math.min(dis,segmentDistance2(routes[i][a-1],routes[i][a],routes[j][b-1],routes[j][b]));
    if(dis<1.2*(radii[i]+radii[j])){conflicts[i].add(j);conflicts[j].add(i);}
  }
  // DSATUR coloring lets disjoint horizontal routes share one height.
  const colors=pairs.map(()=>-1),layerRadii=[];
  for(let count=0;count<pairs.length;count++){
    let pick=-1,best=-1;for(let i=0;i<pairs.length;i++)if(colors[i]<0){const sat=new Set([...conflicts[i]].map(j=>colors[j]).filter(x=>x>=0)).size,score=sat*1e7+conflicts[i].size*1000+radii[i];if(score>best){best=score;pick=i;}}
    const used=new Set([...conflicts[pick]].map(i=>colors[i]));let c=0;while(used.has(c))c++;colors[pick]=c;layerRadii[c]=Math.max(layerRadii[c]||0,radii[pick]);
  }
  const maxRadius=Math.max(...radii),levels=[];let z=4*maxRadius;
  for(let i=0;i<layerRadii.length;i++){if(i)z+=1.2*(layerRadii[i-1]+layerRadii[i]);levels.push(z);}
  let heights=colors.map(c=>levels[c]);
  if(pairs.length>50){
    // Pack the actual exclusion intervals, instead of charging every member
    // of a layer for its single widest route. Every conflicting pair still
    // has height separation greater than 1.2 times its summed radii.
    const packed=pairs.map(()=>null),order=pairs.map((_,i)=>i).sort((a,b)=>conflicts[b].size-conflicts[a].size||radii[b]-radii[a]);
    for(const i of order){
      const intervals=[...conflicts[i]].filter(j=>packed[j]!==null).map(j=>[packed[j]-1.2*(radii[i]+radii[j]),packed[j]+1.2*(radii[i]+radii[j])]).sort((a,b)=>a[0]-b[0]);
      let h=4*maxRadius;for(const [lo,hi] of intervals){if(h<lo)break;if(h<=hi)h=hi+maxRadius*1e-9;}packed[i]=h;
    }
    if(Math.max(...packed)<Math.max(...heights))heights=packed;
  }
  return {radii,routes,heights,colors,layerRadii,routeAttempts,minimumStemMargin,obstacleRadii};
}
function baryArea(bs){return Math.abs((bs[1][1]-bs[0][1])*(bs[2][2]-bs[0][2])-(bs[1][2]-bs[0][2])*(bs[2][1]-bs[0][1]));}
function build(data,quotient=null,routingGraph=null){
  fail(data.patches&&data.outerFacePatch,'Need positive-width collars and source barycentric patches');
  if(routingGraph&&routingGraph.holeCenters)fail(routingGraph.holeCenters.length===data.holes.length&&routingGraph.holeCenters.every((p,i)=>distance(p,data.holes[i].center)<1e-12),'Routing graph must be built from these hole centers');
  const positions=data.positions.map(p=>[p[0],p[1],0]);
  const patches=data.patches.map(p=>({chamber:p.chamber,vertices:p.vertices.slice(),bary:p.bary.map(b=>b.slice())}));
  const holes=data.holes,centers=holes.map(h=>h.center),pairs=[];
  let minClear=Infinity,minCenter=Infinity;const holeClearances=[];
  for(const h of holes){let c=Infinity;for(let i=0;i<h.vertices.length;i++)c=Math.min(c,pointSegment(h.center,data.positions[h.vertices[i]],data.positions[h.vertices[(i+1)%h.vertices.length]]));holeClearances.push(c);minClear=Math.min(minClear,c);}
  for(let i=0;i<centers.length;i++)for(let j=0;j<i;j++)minCenter=Math.min(minCenter,distance(centers[i],centers[j]));
  const originalRho=.04*minCenter;
  fail(originalRho>0&&isFinite(originalRho),'Degenerate hole radius');
  const bounds2=[[Infinity,Infinity],[-Infinity,-Infinity]];for(const p of data.positions)for(let j=0;j<2;j++){bounds2[0][j]=Math.min(bounds2[0][j],p[j]);bounds2[1][j]=Math.max(bounds2[1][j],p[j]);}
  const span=Math.max(bounds2[1][0]-bounds2[0][0],bounds2[1][1]-bounds2[0][1]);

  for(let curve=0;curve<data.genus;curve++){
    const ids=holes.map((h,i)=>h.curve===curve?i:-1).filter(i=>i>=0);fail(ids.length===2,'Missing cut pair');pairs.push(ids);
  }
  const arrangement=arrangeRoutes(centers,pairs,span,routingGraph);
  const footRadii=holeClearances.map((c,i)=>Math.min(.80*c,arrangement.obstacleRadii[i]));
  function tri(chamber,vertices,bary){patches.push({chamber,vertices,bary});}
  function quad(chamber,a,b,c,d,ba,bb,bc,bd){tri(chamber,[b,a,d],[bb,ba,bd]);tri(chamber,[b,d,c],[bb,bd,bc]);}
  const tubeInfo=[];let minimumOtherStemClearance=Infinity;
  for(let ci=0;ci<pairs.length;ci++){
    const [ai,bi]=pairs[ci],A=holes[ai],B=holes[bi],n=A.vertices.length;
    fail(n===B.vertices.length,'Mismatched paired loop lengths');
    const bIndex=new Map(B.origins.map((x,i)=>[x,i])),idx=A.origins.map(o=>bIndex.get(o));
    fail(idx.every(i=>i!==undefined),'Mismatched paired loop origins');
    const endVertices=idx.map(j=>B.vertices[j]);
    const edgeData=A.edges.map((e,i)=>{
      const j=idx[(i+1)%n];fail((j+1)%n===idx[i],'Pairing must reverse boundary orientation');
      const f=B.edges[j];fail(e.chamber===f.chamber,'Collar crosses a source chamber boundary');
      for(let k=0;k<2;k++)fail(distance(e.seamBary[k],f.seamBary[1-k])<1e-10,'Source seam barycentric coordinates disagree');
      return {chamber:e.chamber,baseA:e.baseBary,baseB:[f.baseBary[1],f.baseBary[0]],seam:e.seamBary};
    });
    const route=arrangement.routes[ci],rho=arrangement.radii[ci],height=arrangement.heights[ci];
    let pathClearance=Infinity;for(let j=0;j<route.length-1;j++)for(let oi=0;oi<centers.length;oi++)if(oi!==ai&&oi!==bi)pathClearance=Math.min(pathClearance,pointSegment(centers[oi],route[j],route[j+1]));
    fail(arrangement.minimumStemMargin>0,'Tube route intersects another vertical stem');minimumOtherStemClearance=Math.min(minimumOtherStemClearance,pathClearance);
    const patchStart=patches.length;
    let path=[[...A.center,2*rho],...route.map(p=>[...p,height]),[...B.center,2*rho]];
    let distances=[0];for(let i=1;i<path.length;i++)distances.push(distances.at(-1)+distance(path[i-1],path[i]));
    const total=distances.at(-1),half=total/2;
    const startPoints=A.vertices.map(v=>positions[v]),endPoints=endVertices.map(v=>positions[v]);
    let frames,thetaA,thetaB,maxTotalAngularTwist,maxRingAngularAdvance,maxBoundaryAngularGap,angularStepLimit;
    for(let iteration=0;iteration<4;iteration++){
      frames=polylineFrames(path);
      thetaA=unwrappedAngles(startPoints,[...A.center,0],frames[0]);thetaB=unwrappedAngles(endPoints,[...B.center,0],frames.at(-1));
      const shift=Math.round((thetaA[0]-thetaB[0])/TAU)*TAU;for(let i=0;i<n;i++)thetaB[i]+=shift;
      const winding=a=>a.at(-1)-a[0]+wrap(a[0]-a.at(-1));
      fail(Math.abs(winding(thetaA)-winding(thetaB))<1e-7,'Tube end orientations disagree');
      maxBoundaryAngularGap=Math.max(...[thetaA,thetaB].flatMap(angles=>angles.map((x,i)=>Math.abs(wrap(angles[(i+1)%n]-x)))));
      // The M11 layout needs finer sampling at its very wide sectors.
      // Smaller models retain their independently verified60-degree mesh;
      // unnecessary subdivision can shorten a segment past its miter bound.
      angularStepLimit=data.id==='m11'&&maxBoundaryAngularGap>5*Math.PI/6?Math.PI/12:Math.PI/3;
      maxTotalAngularTwist=Math.max(...thetaA.map((x,i)=>Math.abs(thetaB[i]-x)));
      maxRingAngularAdvance=0;for(let j=1;j<distances.length;j++)maxRingAngularAdvance=Math.max(maxRingAngularAdvance,maxTotalAngularTwist*(distances[j]-distances[j-1])/total);
      if(maxRingAngularAdvance<=angularStepLimit+1e-9)break;
      const pp=[path[0]],dd=[distances[0]];
      for(let j=1;j<path.length;j++){
        const count=Math.ceil(maxTotalAngularTwist*(distances[j]-distances[j-1])/total/angularStepLimit);
        for(let m=1;m<=count;m++){pp.push(mix(path[j-1],path[j],m/count));dd.push(distances[j-1]+(distances[j]-distances[j-1])*m/count);}
      }
      path=pp;distances=dd;
    }
    fail(maxRingAngularAdvance<=angularStepLimit+1e-9,'Angular twist refinement did not converge');
    const seamIndex=distances.reduce((best,d,i)=>i>0&&i<distances.length-1&&Math.abs(d-half)<Math.abs(distances[best]-half)?i:best,1),seamDistance=distances[seamIndex];
    const directions=path.slice(1).map((p,i)=>unit(sub(p,path[i]))),miters=path.map((p,i)=>i===0||i===path.length-1?0:Math.tan(Math.acos(Math.max(-1,Math.min(1,dot(directions[i-1],directions[i]))))/2));
    let minimumMiterGap=Infinity;for(let j=1;j<path.length;j++)minimumMiterGap=Math.min(minimumMiterGap,distances[j]-distances[j-1]-rho*(miters[j-1]+miters[j]));
    fail(minimumMiterGap>rho*1e-6,'Cross-section miter planes overlap along a short segment');
    const rings=[A.vertices.slice()],us=[0];
    function footRing(center,theta,frame,r){const ring=[];for(let i=0;i<n;i++){ring.push(positions.length);const p=add([...center,0],add(mul(frame[0],r*Math.cos(theta[i])),mul(frame[1],r*Math.sin(theta[i]))));p[2]=0;positions.push(p);}return ring;}
    rings.push(footRing(A.center,thetaA,frames[0],footRadii[ai]));us.push(.025);
    for(let j=0;j<path.length;j++){
      const t=distances[j]/total,ring=[];
      for(let i=0;i<n;i++){const angle=thetaA[i]+t*(thetaB[i]-thetaA[i]);const p=add(path[j],add(mul(frames[j][0],rho*Math.cos(angle)),mul(frames[j][1],rho*Math.sin(angle))));ring.push(positions.length);positions.push(p);}
      rings.push(ring);us.push(j<=seamIndex?.05+.45*distances[j]/seamDistance:.5+.45*(distances[j]-seamDistance)/(total-seamDistance));
    }
    rings.push(footRing(B.center,thetaB,frames.at(-1),footRadii[bi]));us.push(.975);
    rings.push(endVertices);us.push(1);
    function sourceBary(e,u,i){return u<=.5?mix(e.baseA[i],e.seam[i],2*u):mix(e.seam[i],e.baseB[i],2*u-1);}
    for(let j=0;j<rings.length-1;j++)for(let i=0;i<n;i++){
      const ni=(i+1)%n,e=edgeData[i];
      quad(e.chamber,rings[j][i],rings[j][ni],rings[j+1][ni],rings[j+1][i],sourceBary(e,us[j],0),sourceBary(e,us[j],1),sourceBary(e,us[j+1],1),sourceBary(e,us[j+1],0));
    }
    tubeInfo.push({curve:ci,radius:rho,height,heightLayer:arrangement.colors[ci],capsuleCenterline:[[...A.center,0],...path,[...B.center,0]],planarAnnulusPatchRanges:[[patchStart,patchStart+2*n],[patches.length-2*n,patches.length]],center:path[distances.reduce((best,d,i)=>Math.abs(d-half)<Math.abs(distances[best]-half)?i:best,0)],focusRadius:Math.max(distance([...A.center,0],[...B.center,0])*.6,height*.6),centerline:path,endpointCenters:[A.center,B.center],footRadii:[footRadii[ai],footRadii[bi]],ringCount:rings.length,segments:n,routeObstacles:(route.length-2),minimumOtherStemClearance:pathClearance,patchStart,patchEnd:patches.length,maxTotalAngularTwist,maxRingAngularAdvance,maxBoundaryAngularGap,angularStepLimit,minimumMiterGap,sourceChambers:edgeData.map(e=>e.chamber)});
  }
  // The original outer chamber closes the underside as a three-triangle cone.
  const out=data.outerFacePatch,center=[0,0,-span*.12],bary=[0,0,0];
  for(let i=0;i<3;i++)for(let j=0;j<2;j++)center[j]+=positions[out.vertices[i]][j]/3;
  for(const b of out.bary)for(let j=0;j<3;j++)bary[j]+=b[j]/3;
  const apex=positions.length;positions.push(center);
  for(let i=0;i<3;i++){const j=(i+1)%3;tri(out.chamber,[out.vertices[i],out.vertices[j],apex],[out.bary[i],out.bary[j],bary]);}
  // Remove cap-center vertices and any other unused points before topology QA.
  const used=[...new Set(patches.flatMap(p=>p.vertices))].sort((a,b)=>a-b),reindex=new Map(used.map((v,i)=>[v,i]));
  const compact=used.map(v=>positions[v]);for(const p of patches)p.vertices=p.vertices.map(v=>reindex.get(v));
  const edgeMap=new Map(),areas=new Float64Array(data.originalTriangles);
  let minGeometricArea=Infinity,minSourceArea=Infinity,sourceEdgeChecks=0;
  for(let pi=0;pi<patches.length;pi++){
    const p=patches[pi];
    const bs=baryArea(p.bary);fail(bs>0,'Degenerate source triangle');minSourceArea=Math.min(minSourceArea,bs);areas[p.chamber]+=bs;
    const [a,b,c]=p.vertices.map(v=>compact[v]);const ga=norm(cross(sub(b,a),sub(c,a)));fail(ga>0,'Degenerate geometric triangle');minGeometricArea=Math.min(minGeometricArea,ga);
    for(let i=0;i<3;i++){
      const a=p.vertices[i],b=p.vertices[(i+1)%3],key=Math.min(a,b)*compact.length+Math.max(a,b),prior=edgeMap.get(key);
      if(prior===undefined){edgeMap.set(key,pi*3+i+1);continue;}
      fail(prior>0,'More than two faces meet at an edge');
      const q=patches[Math.floor((prior-1)/3)],j=(prior-1)%3;
      fail(q.vertices[j]===b&&q.vertices[(j+1)%3]===a,'Orientation mismatch at edge');
      fail(distance(p.bary[i],q.bary[(j+1)%3])<1e-9&&distance(p.bary[(i+1)%3],q.bary[j])<1e-9,'Source chart discontinuity at shared edge');
      if(quotient&&p.chamber!==q.chamber){
        const side=p.bary[i].findIndex((x,k)=>x===0&&p.bary[(i+1)%3][k]===0);
        fail(side>=0&&quotient.neighbors[p.chamber][side]===q.chamber,'Refinement does not preserve original chamber adjacency');
        sourceEdgeChecks++;
      }
      edgeMap.set(key,0);
    }
  }
  for(const value of edgeMap.values())fail(value===0,'Boundary edge in closed surface');
  let maxAreaError=0;for(const x of areas)maxAreaError=Math.max(maxAreaError,Math.abs(x-1));fail(maxAreaError<1e-9,'Source chamber area not conserved: '+maxAreaError);
  const euler=compact.length-edgeMap.size+patches.length;fail(euler===2-2*data.genus,'Wrong Euler characteristic');
  return {id:data.id,planarSource:{circlePacking:data.redistribution||null,areaRedistribution:data.areaRedistribution||null},genus:data.genus,originalTriangles:data.originalTriangles,positions:compact,patches,tubes:tubeInfo,construction:'Planar cut surface with positive-width source collars, disjoint raised tubes, and original outer chamber folded underneath.',verification:{vertices:compact.length,edges:edgeMap.size,refinedTriangles:patches.length,euler,genus:(2-euler)/2,originalChambers:areas.length,sourceAreaMaxError:maxAreaError,minimumSourceTriangleArea:minSourceArea,minimumGeometricDoubleArea:minGeometricArea,stemRadius:Math.min(...arrangement.radii),maximumStemRadius:Math.max(...arrangement.radii),heightLayers:arrangement.layerRadii.length,maximumHorizontalHeight:Math.max(...arrangement.heights),minimumHorizontalHeight:Math.min(...arrangement.heights),routingRadiusReductions:arrangement.routeAttempts,minimumStemMargin:arrangement.minimumStemMargin,minimumFootRadius:Math.min(...footRadii),minHoleClearance:minClear,minStemDistance:minCenter,minimumOtherStemClearance,variableRadii:true,disjointProjectedRoutesShareHeight:true,allEdgesTwoFaces:true,consistentOrientation:true,sourceChartsConserveArea:true,sourceChartContinuity:true,originalAdjacencyVerified:!!quotient,sourceChamberEdgeSegmentsChecked:sourceEdgeChecks}};
}
module.exports={build,routeXY,arrangeRoutes,variableRoute};
function writeJSONStream(path,data){
  const fd=fs.openSync(path,'w');fs.writeSync(fd,'{');let first=true;
  for(const [key,value] of Object.entries(data)){
    if(!first)fs.writeSync(fd,',');first=false;fs.writeSync(fd,JSON.stringify(key)+':');
    if(Array.isArray(value)&&value.length>10000){fs.writeSync(fd,'[');for(let j=0;j<value.length;j+=1000){if(j)fs.writeSync(fd,',');fs.writeSync(fd,value.slice(j,j+1000).map(x=>JSON.stringify(x)).join(','));}fs.writeSync(fd,']');}
    else fs.writeSync(fd,JSON.stringify(value));
  }
  fs.writeSync(fd,'}');fs.closeSync(fd);
}
if(require.main===module){
  const file=process.argv[2];fail(file,'Usage: node tube-routing-balanced.js input-planar.json [output.json] [routing-graph.json]');
  const data=JSON.parse(fs.readFileSync(file,'utf8')),qfile=require('path').join(__dirname,'../quotient-data',data.id+'.json'),quotient=fs.existsSync(qfile)?JSON.parse(fs.readFileSync(qfile,'utf8')):null,out=build(data,quotient,process.argv[4]?JSON.parse(fs.readFileSync(process.argv[4],'utf8')):null);
  process.stdout.write(JSON.stringify({...out.verification,routingRadiusReductions:Math.max(...out.verification.routingRadiusReductions),maxRingCount:Math.max(...out.tubes.map(t=>t.ringCount)),meanRingCount:out.tubes.reduce((s,t)=>s+t.ringCount,0)/out.tubes.length},null,2)+'\n');
  if(process.argv[3])writeJSONStream(process.argv[3],out);
}
