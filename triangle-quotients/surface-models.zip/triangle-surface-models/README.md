# Triangle quotient surfaces: source and verification

This archive contains the mathematical data, construction code, and verification
reports for all eight closed surface models in the Triangle Quotients presentation.
It contains no course handouts, homework, solutions, or downloaded paper PDFs.

| Quotient | Signature | Original chambers | Genus |
| --- | --- | ---: | ---: |
| A4 | (2,3,3) | 24 | 0 |
| S4 | (2,3,4) | 48 | 0 |
| A5 | (2,3,5) | 120 | 0 |
| C6 | (2,3,6) | 12 | 1 |
| PSL(2,7), Klein quartic | (2,3,7) | 336 | 3 |
| A6, smooth Wiman sextic | (2,4,5) | 720 | 10 |
| PSL(2,8), Fricke–Macbeath surface | (2,3,7) | 1,008 | 7 |
| M11 | (2,4,11) | 15,840 | 631 |

Run `python3 verify.py` in this extracted directory to check every included file's
SHA-256 hash and the consistency of the reported model certificates. This quick
check checks the archived reports; it does not rerun the geometric constructions.

`course-update-20260925/quotient-data/` contains the original group enumeration,
chamber identifications, and Euler characteristic certificates. Its generator and
test script can be rerun with standard Python 3 and Node.js:

```sh
python3 course-update-20260925/quotient-data/generate_quotients.py
node course-update-20260925/quotient-data/test_cut_net.js
node course-update-20260925/all-surfaces/test-fundamental-region.cjs
node course-update-20260925/surface-embedding/test-sphere-torus.js
```

The fundamental-region test verifies the developed Euclidean and hyperbolic
regions used at the start of gluing: every original chamber occurs once,
actual covering adjacencies are joined, the boundary is a single simple cycle,
Euler characteristic is one, all projected triangles have positive area, and
their areas sum to the boundary area. The reflection permutations satisfy the
exact Coxeter relations. Hyperbolic regions use the Klein disc; the spherical
cases retain a topological cut disk. The earlier `cut-net.js` tree-cut disk is
also included as a combinatorial certificate and as the spherical layout.

The Klein and Macbeath source models have exact rational intersection certificates
and explicit side-labelled chamber correspondences. See their separate READMEs
for primary sources, attribution, numerical-data hashes, and commands. Their
builders require only standard Python; the Macbeath builder also uses the included
Klein intersection checker.

The A6 and M11 builders subdivide the prescribed chambers, preserving a source
barycentric chart for every rendering triangle. See `CONSTRUCTION.md` and
`TUBE-GEOMETRY.md` under `course-update-20260925/all-surfaces/`. Reproduction requires
Python 3.12 or later, NetworkX 3.7, and Node.js. Install the pinned dependency using
the supplied `requirements.txt`; its BSD license is included. Regenerating the
M11 model and running its full Python intersection check can take substantial
time and memory.

The published A6 result has 720 original chamber disks and 15,748 drawing patches;
its independent audit tested 321,856 local triangle-pair candidates without an
unwanted intersection. The M11 result has 15,840 original chamber disks and
681,878 drawing patches; its independent audit tested 35,594,186 candidates,
resolved 19,944 ill-conditioned candidates with rational predicates, and found
no unwanted intersection. Every shared edge has two oppositely oriented faces,
and every transition between original chambers matches the quotient neighbor
table. Positive planar areas, tube separation bounds, and the below-plane outer
cap complete the geometric checks. The local intersection test uses scale-based
contact tolerances; the code specifies these tolerances explicitly.

`GENERATED-MODEL-HASHES.json` records the exact generated model JSON files.
The large generated A6/M11 JSON files are omitted from this compact source archive.
The final browser assets can be copied from the complete offline application or
downloaded, with size and SHA-256 checks, by running:

```sh
python3 fetch_web_assets.py
node course-update-20260925/all-surfaces/test-refined-model.cjs a6 m11
```

The download helper writes only into the extracted archive's
`github-homepage/triangle-quotients/surface-data/` directory. The second command
checks every drawing triangle's source-chart sample, both copies of every
original edge, and sampled chamber-walk segments using the actual browser model
adapter. It requires a Node.js version with `DecompressionStream` support.

The displayed Euclidean geometry represents the glued topological surface.
Its lengths and angles do not reproduce the intrinsic triangle metric. The
Riemann surface structure comes from the original spherical, Euclidean, or
hyperbolic triangles and their gluing data.
