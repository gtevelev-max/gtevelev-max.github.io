# Wiman's smooth genus-10 sextic: a symmetric target

This research artifact is **not a replacement for the app's exact 720-chamber
mesh**. The target below has the correct topology and the correct restricted
D5 action. Transport of the original chambers through an explicit equivariant
homeomorphism remains to be implemented. There are no counterfeit chamber
labels on the target.

## Primary references checked

* Badr and Bars, *The stratification by automorphism groups of smooth
  plane sextic curves*, Introduction:
  https://link.springer.com/article/10.1007/s10231-025-01558-z
  gives the smooth Wiman sextic and its A6 automorphism group. This is the
  genus-10 curve, not the singular Wiman–Edge sextic with normalization of
  genus 6 and group S5.
* Marston Conder's own census:
  https://www.math.auckland.ac.nz/~conder/RegularOrientableMaps101.txt
  gives the regular map R10.6. Its type is {4,5}; it has 72 vertices, 180 edges,
  and 90 quadrilateral faces. Barycentric subdivision has 720 chambers.
* Matthias Görner's thesis, Chapter 2:
  https://math.berkeley.edu/~matthias/research/matthias_goerner_thesis_print.pdf
  develops equivariant-embedding obstructions via the quotient orbifold.
  The printed tables in §2.13 stop at genus 7; they do not establish a
  genus-10 Wiman model.
* Carlo Séquin, *My Search for Symmetrical Embeddings of Regular Maps*:
  https://people.eecs.berkeley.edu/~sequin/PAPERS/2010_Bridges_RegMaps.pdf
  treats examples of genera 2–5, not an explicit Wiman R10.6 mesh.

No published, downloadable 3D coordinates for an embedded Wiman R10.6 model
were found in this bounded search. The construction and calculations below
are new derivations for this task, not claims quoted from those papers.

## Why all 360 rotations cannot be ordinary spatial rotations

For the A6 action of signature (2,4,5), nonidentity fixed-point counts are:

| Element order | Fixed points |
| --- | --- |
| 2 | 6 |
| 3 | 0 |
| 4 | 2 |
| 5 | 2 |

An order-four spatial rotation and its square have the same fixed axis.
Consequently this action cannot embed equivariantly with any element of
order four realized as a spatial rotation. In particular, octahedral S4
symmetry is excluded.

For an A5 subgroup, the quotient has signature (0;2,2,2,5). The singular
graph of the icosahedral spatial quotient has order-2, order-3, and order-5
edges joining the origin to infinity. An embedded separating surface must
meet these three edges with equal parity. The signature requires parities
(1,0,1), so icosahedral rotational symmetry is excluded.

For an A4 subgroup, the quotient has signature (1;2,2,2). The corresponding
tetrahedral graph has edge types (2,3,3), with required parities (1,0,0).
This excludes tetrahedral rotational symmetry as well.

The finite subgroups of SO(3) are cyclic, dihedral, tetrahedral, octahedral,
or icosahedral. A6 has element orders only 1,2,3,4,5. After the exclusions
above, a rotational subgroup of an embedded Wiman model has order at most
10, and D5 is the remaining largest possibility. These statements concern
the orientation-preserving intrinsic action, not a claim about all possible
orientation-reversing isometries of an undecorated target.

## Explicit D5 action on the actual sextic

The published homogeneous equation is

    27X^6 + 9X(Y^5+Z^5) - 135X^4YZ - 45X^2Y^2Z^2 + 10Y^3Z^3 = 0.

Put X=1 and u=YZ. Then Y^5+Z^5=P(u), where

    P(u)=(-27+135u+45u^2-10u^3)/9.

The automorphisms

    r(Y,Z)=(ζY,ζ^-1 Z),    s(Y,Z)=(Z,Y),    ζ=exp(2πi/5)

generate D5. With v=Y^5-Z^5 the cyclic quotient is

    v^2=P(u)^2-4u^5,

a genus-two curve. Recover Y from Y^5=(P+v)/2 and Z=u/Y. The full D5
quotient is the u-sphere, with six order-two branch points and one order-five
branch point. The two fixed points of r are [0:1:0] and [0:0:1].

Generator convention matters: this algebraic r acts in local coordinates at
the fixed points by ζ^-2 and ζ^2, respectively. Its local angles are therefore
±144°, not ±72°. Use r² (or r³ for the opposite orientation) to match the
prototype's 72° geometric generator. The app's triangle generator z has
local angle 72° and must be matched to that choice during chamber transport.

## A finite certificate matching the target's D5 action

Write s_a=r^a s, a in Z/5. The six involution branch monodromies followed
by the order-five monodromy r have product one precisely when

    a1-a2+a3-a4+a5-a6 = -1 mod 5.

There are 5^5=3125 such tuples. Each generates D5, since its product is
a nontrivial rotation and it contains an involution. An adjacent Hurwitz
move sends (a,b) to (b,2b-a), preserving the product.

The reproducible breadth-first enumeration in build_symmetric_target.py
starts at (0,0,0,0,0,1) and reaches all 3125 tuples. Thus there is a single
Hurwitz orbit for this branch data. After choosing the generator's local
rotation consistently, any such D5 cover is equivariantly homeomorphic to
the restriction of the actual Wiman action. This is a certificate about
actions; it is not yet coordinates for each original chamber.

## Concrete target and numerical verification

Take a planar radius-3 disk with circular holes at

    (r cos(2πj/5), r sin(2πj/5)),   j=0,...,4,

using (center radius, hole radius) pairs (1.0,0.34) and (2.18,0.43).
Double this punctured disk. The top and bottom sheets are rounded towards
their shared boundary with maximum half-thickness 0.30. Rotations by 72°
about z and 180° about x preserve the resulting closed surface.

Each horizontal half-turn axis intersects two holes on one ray, so its
intersection with the surface consists of six points. The z-axis meets it
in two points. The quotient has signature (0;2,2,2,2,2,2,5), which matches
the Wiman action by the certificate above. This realizes the maximum
possible order 10 for orientation-preserving visible symmetries of the
Wiman action in R3, once the intrinsic surface is identified with this
target.

Files:

* symmetric-target.json: positions, triangles, explicit D5 permutations;
* symmetric-target-verification.json: counts and checks;
* build_symmetric_target.py: complete reproducible construction;
* symmetric-target-preview.png: unlabelled target preview.

The mesh has 42,342 vertices, 127,080 edges, and 84,720 drawing triangles,
giving Euler characteristic -18 and genus 10. Every edge has two oppositely
oriented incident triangles; every vertex link is a single circle. Both
D5 generator permutations preserve the entire triangle set, with coordinate
errors below 2.4e-15. Their fixed-vertex counts are checked directly.

The embedding construction is a pair of single-valued piecewise-linear
height graphs over a nonoverlapping planar domain, with positive height in
the interior and common height zero only on the boundary. Thus its two
sheets cannot intersect away from their intended shared boundary. The
planar mesh uses star-shaped annular sectors with positive triangle areas.

The original 720-chamber triangulation has **not** yet been transported.
It must not be replaced by the 84,720 display triangles or by a guessed
colouring if this target is integrated into the triangle-quotient tool.
