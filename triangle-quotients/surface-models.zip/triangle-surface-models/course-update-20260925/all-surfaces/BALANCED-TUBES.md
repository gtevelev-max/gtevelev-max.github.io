# Balanced tube geometry

`tube-routing-balanced.js` preserves the same original chamber labels and positive-width collar charts as `tube-routing.js`. It improves the geometry after the planar area redistribution step:

- Each handle radius is 30% of the smaller nearest-neighbor distance at its two attachment centers. Thus any two stem radii sum to at most 60% of their center separation.
- The foot circle uses at most 80% of the minimum clearance to its star-shaped hole boundary. All foot vertices have exactly zero height. This widens the attachments without leaving their planar holes.
- Horizontal routes avoid every unrelated stem by more than the sum of their radii. Small examples use a visibility graph around obstacle circles; M11 uses a sparse Voronoi graph with explicitly checked edge capacities. Sixteen guard sites at 0.8 times the hole-center span keep exterior routes close to the surface. The graph is an optimization aid; the final geometric clearance checks do not depend on correctness of the Voronoi construction.
- A conflict graph records pairs of horizontal routes whose projected distance is less than 1.2 times their summed radii. DSATUR coloring allows disjoint routes to share a height. Large examples additionally pack the actual forbidden height intervals to avoid charging every route for the largest radius in a layer.
- Source barycentric subdivisions and the original outer chamber folded beneath the plane follow the existing tube builder. Longitudinal twist advances by at most 60° per strip, tightened to 15° for M11 strips whose boundary angular sector exceeds 150°. The three smaller models retain their independently verified 60° meshes; extra subdivisions can violate the minimum gap between oblique miter planes. The independent triangle-pair audit checks the resulting piecewise-linear strips. Every original chamber remains a disk, every original adjacency is checked, and total barycentric area is 1 per chamber.

For global nonintersection checks, each tube records `capsuleCenterline`, including vertical segments down to height 0. Every nonplanar patch is contained in one of the radius-R capsules along this line. Its two planar annuli are separately recorded as `planarAnnulusPatchRanges`; they lie in the original disjoint holes and are excluded from the capsule bound. Different tubes are separated when all cross-handle centerline segment distances exceed the summed radii. Self-intersections are checked by the independent triangle-pair checker.

Example commands (Node and Python with NumPy/SciPy):

```
node tube-routing-balanced.js a6-planar-area2.json a6-balanced-tubes.json
python verify_patch_embedding.py a6-balanced-tubes.json
python make-routing-graph.py m11-planar-newton.json m11-balanced-routes.json
node tube-routing-balanced.js m11-planar-newton.json m11-balanced-tubes.json m11-balanced-routes.json
python verify_patch_embedding.py m11-balanced-tubes.json
```

The original quotient metric is not preserved: these are topological embeddings with the exact quotient chamber combinatorics. Original chambers may have multiple rendering triangles; those subdivisions do not change the chamber count.

For the large M11 mesh, the equivalent independent local audit uses a compiled candidate scan and exact rational resolution:

```
python verify_balanced_topology.py m11-balanced-tubes.json
python export-check-mesh.py m11-balanced-tubes.json
c++ -O3 -std=c++17 check-tubes.cpp -o check-tubes
./check-tubes m11-balanced-tubes.check.bin > m11-balanced-compiled-candidates.json
python resolve_balanced_candidates.py m11-balanced-tubes.json m11-balanced-compiled-candidates.json
```

Global capsule separation and planar embedding checks must also pass; local triangle-pair checks alone do not certify different handles.
