"""Construct a disjoint cut system and an exact planar drawing.

Each cut is a simple dual cycle disjoint from a spanning tree of the
primal graph.  Its complement is consequently connected.  Mid-edge
subdivision lets every later cut avoid every earlier boundary.

Install requirements.txt in a Python 3.12+ virtual environment, then run
python3 cut_to_planar.py a6. NetworkX is used only for its Chrobak--Payne
integer planar drawing. See CONSTRUCTION.md for the model-specific commands.

integer_drawing_with_outer is adapted from NetworkX 3.7's
networkx.algorithms.planar_drawing.combinatorial_embedding_to_pos:
https://github.com/networkx/networkx/blob/networkx-3.7/networkx/algorithms/planar_drawing.py
Copyright (C) 2004-2026 NetworkX Developers. Distributed under the
three-clause BSD license retained in NETWORKX-LICENSE.txt.
"""
import collections
import json
import pathlib
import sys
import time

ROOT = pathlib.Path(__file__).resolve().parent


class DSU:
    def __init__(self, n):
        self.p = list(range(n))
        self.rank = [0] * n

    def find(self, a):
        p = self.p
        while p[a] != a:
            p[a] = p[p[a]]
            a = p[a]
        return a

    def join(self, a, b):
        a, b = self.find(a), self.find(b)
        if a == b:
            return False
        if self.rank[a] < self.rank[b]:
            a, b = b, a
        self.p[b] = a
        if self.rank[a] == self.rank[b]:
            self.rank[a] += 1
        return True


def key(a, b):
    return (a, b) if a < b else (b, a)


def incidence(faces):
    edges = collections.defaultdict(list)
    for fi, (a, b, c, label) in enumerate(faces):
        for u, v in ((a, b), (b, c), (c, a)):
            edges[key(u, v)].append((fi, u, v))
    return edges


def shortest_available_cycle(faces, edges, nv):
    """A dual cycle missing a primal spanning tree is nonseparating."""
    uf = DSU(nv)
    tree = set()
    # Each boundary cycle contributes all but one of its edges.  This
    # ensures the residual interior dual graph retains its genus cycles.
    for e, inc in edges.items():
        if len(inc) == 1 and uf.join(*e):
            tree.add(e)
    for e in edges:
        if uf.join(*e):
            tree.add(e)
    dual = [[] for _ in faces]
    for e, inc in edges.items():
        if len(inc) == 2 and e not in tree:
            a, b = inc[0][0], inc[1][0]
            dual[a].append((b, e))
            dual[b].append((a, e))
    parent = [-1] * len(faces)
    pedge = [None] * len(faces)
    depth = [0] * len(faces)
    best = None
    for start in range(len(faces)):
        if parent[start] != -1:
            continue
        parent[start] = start
        queue = collections.deque([start])
        while queue:
            a = queue.popleft()
            for b, e in dual[a]:
                if parent[b] == -1:
                    parent[b], pedge[b], depth[b] = a, e, depth[a] + 1
                    queue.append(b)
                elif parent[a] != b and a < b:
                    x, y = a, b
                    path = [e]
                    while x != y:
                        if depth[x] >= depth[y]:
                            path.append(pedge[x])
                            x = parent[x]
                        else:
                            path.append(pedge[y])
                            y = parent[y]
                        if best is not None and len(path) >= len(best):
                            break
                    if x == y and (best is None or len(path) < len(best)):
                        best = path
    if best is None:
        raise ValueError("No nonseparating dual cycle remains")
    assert len(best) == len(set(best))
    return set(best)


def homology_short_cycle(faces, edges, nv):
    """Short cycles in the unrestricted dual, certified by intersections.

    Complete each boundary by a disk conceptually. A primal tree T and a
    disjoint dual tree D leave 2g edges. Their primal fundamental cycles
    are a homology basis. Bit vectors on crossed edges record intersections
    with this basis, so a nonzero cycle vector certifies nonseparation.
    """
    uf = DSU(nv)
    tree = set()
    for e, inc in edges.items():
        if len(inc) == 1 and uf.join(*e):
            tree.add(e)
    for e in edges:
        if uf.join(*e):
            tree.add(e)
    dual_uf = DSU(len(faces))
    residual = []
    for e, inc in edges.items():
        if len(inc) == 2 and e not in tree:
            if not dual_uf.join(inc[0][0], inc[1][0]):
                residual.append(e)
    assert residual
    assert len({dual_uf.find(i) for i in range(len(faces))}) == 1
    accum = [0] * nv
    annotations = {}
    for i,e in enumerate(residual):
        bit = 1 << i
        annotations[e] = bit
        accum[e[0]] ^= bit
        accum[e[1]] ^= bit
    primal = [[] for _ in range(nv)]
    for e in tree:
        a,b = e
        primal[a].append((b,e))
        primal[b].append((a,e))
    parent = [-1] * nv
    parent[0] = 0
    pedge = [None] * nv
    order = [0]
    for a in order:
        for b,e in primal[a]:
            if parent[b] == -1:
                parent[b],pedge[b] = a,e
                order.append(b)
    assert len(order) == nv
    for a in reversed(order[1:]):
        annotations[pedge[a]] = accum[a]
        accum[parent[a]] ^= accum[a]
    dual = [[] for _ in faces]
    for e,inc in edges.items():
        if len(inc) == 2:
            a,b = inc[0][0],inc[1][0]
            mask = annotations.get(e,0)
            dual[a].append((b,e,mask))
            dual[b].append((a,e,mask))
    best = None
    # A few spread-out roots avoid forcing short local cycles to run back
    # toward one remote basepoint as the planar boundary grows.
    for start in [0,len(faces)//3,2*len(faces)//3]:
        parent = [-1]*len(faces)
        pedge = [None]*len(faces)
        depth = [0]*len(faces)
        masks = [0]*len(faces)
        parent[start] = start
        queue = collections.deque([start])
        while queue:
            a = queue.popleft()
            for b,e,mask in dual[a]:
                if parent[b] == -1:
                    parent[b],pedge[b],depth[b],masks[b] = a,e,depth[a]+1,masks[a]^mask
                    queue.append(b)
                elif a < b and masks[a]^mask^masks[b]:
                    x,y = a,b
                    path = [e]
                    while x != y:
                        if depth[x] >= depth[y]:
                            path.append(pedge[x]); x=parent[x]
                        else:
                            path.append(pedge[y]); y=parent[y]
                        if best is not None and len(path)>=len(best):
                            break
                    if x==y and (best is None or len(path)<len(best)):
                        best=path
    assert best is not None
    crossed=set(best)
    # Independent combinatorial certificate: cutting these dual arcs
    # leaves the original primal one-skeleton connected.
    check=DSU(nv)
    for e in edges:
        if e not in crossed:
            check.join(*e)
    assert len({check.find(v) for v in range(nv)}) == 1
    return crossed


def cut_cycle(faces, crossed, edges, origins, boundary_tags, curve, bary, seam_bary):
    mids = {}
    for e in sorted(crossed):
        origin = len(origins)
        for endpoint in e:
            mids[e, endpoint] = len(origins)
            origins.append(origin)
    touched = collections.defaultdict(set)
    for e in crossed:
        for fi, _, _ in edges[e]:
            touched[fi].add(e)
    assert all(len(es) == 2 for es in touched.values())
    output = []
    for fi, f in enumerate(faces):
        if fi not in touched:
            output.append(f)
            continue
        a, b, c, label = f
        for _ in range(3):
            if key(a, b) in crossed and key(b, c) in crossed:
                break
            a, b, c = b, c, a
        e, h = key(a, b), key(b, c)
        ua, ub = mids[e, a], mids[e, b]
        vb, vc = mids[h, b], mids[h, c]
        # Remove a genuine, positive-width collar.  The tube's two
        # halves will fill these omitted source strips exactly.
        for u, v, mu, mv in ((a, b, ua, ub), (b, c, vb, vc)):
            bu, bv = bary[label, u], bary[label, v]
            bary[label, mu] = [0.55*x+0.45*y for x,y in zip(bu,bv)]
            bary[label, mv] = [0.45*x+0.55*y for x,y in zip(bu,bv)]
            mid = [(x+y)/2 for x,y in zip(bu,bv)]
            seam_bary[label, mu] = mid
            seam_bary[label, mv] = mid
        output.extend([[ub, b, vb, label], [a, ua, vc, label], [a, vc, c, label]])
        boundary_tags[key(ub, vb)] = [curve, label]
        boundary_tags[key(ua, vc)] = [curve, label]
    return output


def boundary_loops(faces, boundary_tags, origins, bary, seam_bary):
    edges = incidence(faces)
    nxt = {}
    for e, inc in edges.items():
        if len(inc) == 1:
            fi, u, v = inc[0]
            assert u not in nxt
            nxt[u] = v
    unseen = set(nxt)
    loops = []
    while unseen:
        start = min(unseen)
        u = start
        loop = []
        while not loop or u != start:
            unseen.remove(u)
            loop.append(u)
            u = nxt[u]
        tags = [boundary_tags[key(loop[i], loop[(i + 1) % len(loop)])] for i in range(len(loop))]
        assert len(set(t[0] for t in tags)) == 1
        curve = tags[0][0]
        edge_patches = []
        for i, (tag_curve, label) in enumerate(tags):
            u, v = loop[i], loop[(i+1)%len(loop)]
            edge_patches.append(dict(chamber=label, baseBary=[bary[label,u],bary[label,v]], seamBary=[seam_bary[label,u],seam_bary[label,v]]))
        loops.append(dict(curve=curve, vertices=loop, origins=[origins[v] for v in loop], labels=[t[1] for t in tags], edges=edge_patches))
    for curve in set(h['curve'] for h in loops):
        pair = [h for h in loops if h['curve'] == curve]
        assert len(pair) == 2 and set(pair[0]['origins']) == set(pair[1]['origins'])
        for side, h in enumerate(pair):
            h['side'] = side
        a,b = pair
        partner_edges = {(b['origins'][i],b['origins'][(i+1)%len(b['origins'])]): b['labels'][i] for i in range(len(b['origins']))}
        for i,label in enumerate(a['labels']):
            assert partner_edges[a['origins'][(i+1)%len(a['origins'])],a['origins'][i]] == label
    return loops


def planar_drawing(faces, origins, holes):
    import networkx as nx
    nv = len(origins)
    all_faces = list(faces)
    for hole in holes:
        center = nv
        nv += 1
        hole['centerVertex'] = center
        vs = hole['vertices']
        # Boundary order is the existing oriented face order, so caps
        # reverse their boundary edges.
        all_faces.extend([[vs[(i + 1) % len(vs)], vs[i], center, -1] for i in range(len(vs))])
    edges = incidence(all_faces)
    assert all(len(inc) == 2 for inc in edges.values())
    assert nv - len(edges) + len(all_faces) == 2
    # At a vertex v, every oriented face (v,a,b) says successor(a)=b.
    rotation = [{} for _ in range(nv)]
    for a, b, c, _ in all_faces:
        for v, p, q in ((a, b, c), (b, c, a), (c, a, b)):
            assert p not in rotation[v]
            rotation[v][p] = q
    embedding = nx.PlanarEmbedding()
    cyclic = {}
    for v, succ in enumerate(rotation):
        start = min(succ)
        seq = [start]
        while succ[seq[-1]] != start:
            seq.append(succ[seq[-1]])
        assert len(seq) == len(succ)
        cyclic[v] = seq
    embedding.set_data(cyclic)
    embedding.check_structure()
    # The library picks an arbitrary outer triangle when fully triangulated.
    # Supply our required original triangle explicitly to its canonical order.
    outer = faces[0][:3]
    pos = integer_drawing_with_outer(embedding, outer)
    # The chosen outer face is rendered as a bottom cone rather than
    # filling the planar region occupied by all the other faces.
    positions = [list(pos[v]) for v in range(nv)]
    for hole in holes:
        hole['center'] = positions[hole['centerVertex']]
        center = hole['center']
        vs = hole['vertices']
        fans = []
        for i in range(len(vs)):
            p,q = positions[vs[i]],positions[vs[(i+1)%len(vs)]]
            fans.append((p[0]-center[0])*(q[1]-center[1])-(p[1]-center[1])*(q[0]-center[0]))
        assert all(a>0 for a in fans) or all(a<0 for a in fans)
    return positions, faces[0]


def integer_drawing_with_outer(embedding, outer):
    """NetworkX's integer shift algorithm, choosing the outer face.

    Public combinatorial_embedding_to_pos does not accept an outer-face
    parameter; this is its small constructive core with that choice explicit.
    """
    from networkx.algorithms.planar_drawing import get_canonical_ordering, set_position
    # canonical ordering expects the actual clockwise face traversal.
    face = embedding.traverse_face(outer[0], outer[1])
    if set(face) != set(outer):
        face = embedding.traverse_face(outer[1], outer[0])
    assert len(face) == 3 and set(face) == set(outer)
    node_list = get_canonical_ordering(embedding, face)
    left_t_child = {}
    right_t_child = {}
    delta_x = {}
    y_coordinate = {}
    v1, v2, v3 = [node_list[i][0] for i in range(3)]
    delta_x[v1], y_coordinate[v1] = 0, 0
    right_t_child[v1], left_t_child[v1] = v3, None
    delta_x[v2], y_coordinate[v2] = 1, 0
    right_t_child[v2], left_t_child[v2] = None, None
    delta_x[v3], y_coordinate[v3] = 1, 1
    right_t_child[v3], left_t_child[v3] = v2, None
    for k in range(3, len(node_list)):
        vk, contour = node_list[k]
        wp, wp1, wq = contour[0], contour[1], contour[-1]
        wq1 = contour[-2]
        delta_x[wp1] += 1
        delta_x[wq] += 1
        span = sum(delta_x[x] for x in contour[1:])
        delta_x[vk] = (-y_coordinate[wp] + span + y_coordinate[wq]) // 2
        y_coordinate[vk] = (y_coordinate[wp] + span + y_coordinate[wq]) // 2
        delta_x[wq] = span - delta_x[vk]
        if len(contour) > 2:
            delta_x[wp1] -= delta_x[vk]
        right_t_child[wp] = vk
        right_t_child[vk] = wq
        if len(contour) > 2:
            left_t_child[vk] = wp1
            right_t_child[wq1] = None
        else:
            left_t_child[vk] = None
    pos = {v1: (0, y_coordinate[v1])}
    remaining_nodes = [v1]
    while remaining_nodes:
        parent = remaining_nodes.pop()
        set_position(parent, left_t_child, remaining_nodes, delta_x, y_coordinate, pos)
        set_position(parent, right_t_child, remaining_nodes, delta_x, y_coordinate, pos)
    return pos


def build(name, method='homology'):
    started = time.time()
    data = json.loads((ROOT.parent / 'quotient-data' / (name + '.json')).read_text())
    faces = []
    bary = {}
    for i, vs in enumerate(data['faceVertices']):
        a, b, c = vs
        if i % 2:
            b, c = c, b
        faces.append([a, b, c, i])
        for j,v in enumerate(vs):
            bary[i,v] = [int(k==j) for k in range(3)]
    origins = list(range(data['counts']['vertices']))
    boundary_tags = {}
    seam_bary = {}
    lengths = []
    for curve in range(data['genus']):
        edges = incidence(faces)
        crossed = (shortest_available_cycle if method=='tree' else homology_short_cycle)(faces, edges, len(origins))
        lengths.append(len(crossed))
        faces = cut_cycle(faces, crossed, edges, origins, boundary_tags, curve, bary, seam_bary)
        if curve % 25 == 0 or curve + 1 == data['genus']:
            print(name, 'cut', curve + 1, '/', data['genus'], 'length', len(crossed), 'faces', len(faces), 'seconds', round(time.time() - started, 2), flush=True)
    holes = boundary_loops(faces, boundary_tags, origins, bary, seam_bary)
    assert len(holes) == 2 * data['genus']
    edges = incidence(faces)
    assert len(origins) - len(edges) + len(faces) == 2 - 2 * data['genus']
    positions, outer = planar_drawing(faces, origins, holes)
    patches = [dict(chamber=f[3], vertices=f[:3], bary=[bary[f[3],v] for v in f[:3]]) for f in faces]
    source_area = [0.0] * len(data['faceVertices'])
    def area(bs):
        p,q,r = bs
        return abs((q[1]-p[1])*(r[2]-p[2])-(q[2]-p[2])*(r[1]-p[1]))
    for patch in patches:
        source_area[patch['chamber']] += area(patch['bary'])
    for h in holes:
        for ep in h['edges']:
            a,b = ep['baseBary']
            c,d = ep['seamBary']
            source_area[ep['chamber']] += area([a,b,d]) + area([a,d,c])
    assert max(abs(a-1) for a in source_area) < 1e-10
    # Every remaining planar triangle has one common orientation; the
    # outer face has the opposite area sign. All tests are exact integers.
    areas = []
    for a, b, c, _ in faces[1:]:
        p, q, r = positions[a], positions[b], positions[c]
        areas.append((q[0]-p[0])*(r[1]-p[1])-(q[1]-p[1])*(r[0]-p[0]))
    assert all(a > 0 for a in areas) or all(a < 0 for a in areas)
    output = dict(id=name, genus=data['genus'], originalTriangles=len(data['faceVertices']), cutAlgorithm=method, positions=positions, faces=faces[1:], outerFace=outer, patches=patches[1:], outerFacePatch=patches[0], holes=holes, cutLengths=lengths,
                  verification=dict(planarEuler=2-2*data['genus'], boundaryComponents=len(holes), minimumPlanarDoubledArea=min(map(abs, areas)), maximumSourceAreaError=max(abs(a-1) for a in source_area), seconds=time.time()-started))
    target = ROOT / (name + '-planar.json')
    target.write_text(json.dumps(output, separators=(',', ':')))
    print('Wrote', target, target.stat().st_size, 'bytes', flush=True)


if __name__ == '__main__':
    names=[s for s in sys.argv[1:] if s!='--tree-cycles'] or ['a6', 'macbeath', 'm11']
    for name in names:
        build(name,'tree' if '--tree-cycles' in sys.argv else 'homology')
