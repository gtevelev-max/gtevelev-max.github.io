"""Finite, source-labelled, tetrahedrally equivariant smoothing experiment.

This writes research artifacts only. It does not change the deployed app.
The finite mesh, not an unexamined subdivision limit, is intersection-checked.
"""
from pathlib import Path
from fractions import Fraction as Q
from collections import defaultdict
import importlib.util, itertools, json, math, sys, time

HERE=Path(__file__).resolve().parent
OLD=HERE.parent/'course-update-20260925/surface-embedding'
spec=importlib.util.spec_from_file_location('exact_klein',OLD/'build_klein_embedding.py')
exact=importlib.util.module_from_spec(spec);spec.loader.exec_module(exact)
data=json.loads((HERE.parent/'course-update-20260925/quotient-data/klein.json').read_text())
source=json.loads((OLD/'klein-embedding.json').read_text())
v=[tuple(Q(x).limit_denominator(3) for x in p) for p in source['positions']]
patches=[]
for f,face in enumerate(data['faceVertices']):
 order=[0,1,2] if f%2==0 else [0,2,1]
 patches.append({'chamber':f,'vertices':[face[k] for k in order],
                 'bary':[tuple(Q(int(j==k)) for j in range(3)) for k in order]})

transforms=[];pointmap={p:i for i,p in enumerate(v)}
for perm in itertools.permutations(range(3)):
 for signs in itertools.product((-1,1),repeat=3):
  transformed=[tuple(signs[k]*p[perm[k]] for k in range(3)) for p in v]
  if all(p in pointmap for p in transformed):
   mapping=[pointmap[p] for p in transformed]
   triangles={tuple(sorted(p['vertices'])) for p in patches}
   if {tuple(sorted(mapping[i] for i in p['vertices'])) for p in patches}==triangles:
    transforms.append((perm,signs,mapping))
assert len(transforms)==12

levels=int(sys.argv[1]) if len(sys.argv)>1 else 1
strength=Q(sys.argv[2]) if len(sys.argv)>2 else Q(1,4)
for level in range(levels):
 edges=defaultdict(list);neighbors=[set() for p in v]
 for p in patches:
  a,b,c=p['vertices']
  for i,j,k in [(a,b,c),(b,c,a),(c,a,b)]:
   edges[tuple(sorted((i,j)))].append(k);neighbors[i].add(j);neighbors[j].add(i)
 assert all(len(o)==2 for o in edges.values())
 new=[]
 for i,p in enumerate(v):
  nn=len(neighbors[i]);beta=Q((5/8-(3/8+math.cos(2*math.pi/nn)/4)**2)/nn).limit_denominator(2**24)
  new.append(tuple((1-strength*nn*beta)*p[k]+strength*beta*sum(v[j][k] for j in neighbors[i]) for k in range(3)))
 edge_ids={}
 for (a,b),opposite in sorted(edges.items()):
  c,d=opposite;edge_ids[(a,b)]=len(new)
  new.append(tuple((Q(1,2)-strength/8)*(v[a][k]+v[b][k])+strength*Q(1,8)*(v[c][k]+v[d][k]) for k in range(3)))
 refined=[]
 for p in patches:
  a,b,c=p['vertices'];wa,wb,wc=p['bary']
  ab=edge_ids[tuple(sorted((a,b)))];bc=edge_ids[tuple(sorted((b,c)))];ca=edge_ids[tuple(sorted((c,a)))]
  wab=tuple((x+y)/2 for x,y in zip(wa,wb));wbc=tuple((x+y)/2 for x,y in zip(wb,wc));wca=tuple((x+y)/2 for x,y in zip(wc,wa))
  for ids,bs in [([a,ab,ca],[wa,wab,wca]),([ab,b,bc],[wab,wb,wbc]),([ca,bc,c],[wca,wbc,wc]),([ab,bc,ca],[wab,wbc,wca])]:
   refined.append({'chamber':p['chamber'],'vertices':ids,'bary':bs})
 updated=[]
 for perm,signs,mapping in transforms:
  mm=mapping+[edge_ids[tuple(sorted((mapping[a],mapping[b])))] for a,b in sorted(edges)]
  for i,j in enumerate(mm):assert tuple(signs[k]*new[i][perm[k]] for k in range(3))==new[j]
  updated.append((perm,signs,mm))
 v=new;patches=refined;transforms=updated
 print('Prepared level',level+1,'vertices',len(v),'triangles',len(patches),flush=True)

# Dyadic quantization makes the exact certified positions identical to the
# Float64 numbers consumed by a viewer. Signed permutations commute with it.
grid=2**32
v=[tuple(Q(round(x*grid),grid) for x in p) for p in v]
for perm,signs,mapping in transforms:
 for i,j in enumerate(mapping):assert tuple(signs[k]*v[i][perm[k]] for k in range(3))==v[j]
start=time.time();checks=exact.verify_embedding(v,[p['vertices'] for p in patches]);seconds=time.time()-start
degrees=defaultdict(int);incidence={};neighbor_segments=0
for pi,p in enumerate(patches):
 for i in range(3):
  j=(i+1)%3;edge=tuple(sorted((p['vertices'][i],p['vertices'][j])));degrees[edge]+=1
  if edge not in incidence:incidence[edge]=(pi,i);continue
  ri,k=incidence[edge];r=patches[ri];l=(k+1)%3
  assert p['vertices'][i]==r['vertices'][l] and p['vertices'][j]==r['vertices'][k]
  assert p['bary'][i]==r['bary'][l] and p['bary'][j]==r['bary'][k]
  if p['chamber']!=r['chamber']:
   side=next(s for s in range(3) if p['bary'][i][s]==p['bary'][j][s]==0)
   assert data['neighbors'][p['chamber']][side]==r['chamber'];neighbor_segments+=1
assert all(n==2 for n in degrees.values())
assert len(v)-len(degrees)+len(patches)==-4
for f in range(336):
 ps=[p for p in patches if p['chamber']==f]
 area=sum(abs((p['bary'][1][1]-p['bary'][0][1])*(p['bary'][2][2]-p['bary'][0][2])-(p['bary'][1][2]-p['bary'][0][2])*(p['bary'][2][1]-p['bary'][0][1])) for p in ps)
 assert area==1
verification={'genus':3,'originalChambers':336,'vertices':len(v),'edges':len(degrees),'drawingTriangles':len(patches),'euler':-4,'visibleRotationGroup':'A4','visibleRotationGroupOrder':12,'exactEquivariance':True,'exactRationalTrianglePairChecks':checks,'extraneousIntersections':0,'sourceChartAreasExact':True,'sourceChartsContinuous':True,'originalNeighborSegmentsChecked':neighbor_segments,'coordinateGridDenominator':grid,'certifiedCoordinatesExactlyRepresentableInFloat64':True,'intersectionCheckSeconds':seconds}
out={'id':'klein','genus':3,'originalTriangles':336,'construction':'Finite rational damped Loop-style smoothing of source-labelled Schulte–Wills chamber mesh','subdivisionLevels':levels,'smoothingStrength':str(strength),'positions':[[float(x) for x in p] for p in v],'exactPositions':[[str(x) for x in p] for p in v],'patches':[dict(p,bary=[[float(x) for x in w] for w in p['bary']]) for p in patches],'symmetryGenerators':[{'permutation':perm,'signs':signs,'vertexPermutation':mapping} for perm,signs,mapping in transforms],'verification':verification}
(HERE/f'klein-rounded-level{levels}.json').write_text(json.dumps(out,separators=(',',':'))+'\n')
print(json.dumps(verification,indent=2))
