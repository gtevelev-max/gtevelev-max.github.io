# Triangle quotient surfaces: source and verification

This archive contains the mathematical data, construction code, and verification
reports for all eight closed surface models in the Triangle Quotients presentation.
It contains no course handouts, homework, solutions, or downloaded paper PDFs.

| Quotient | Signature | Original chambers | Genus |
| --- | --- | ---: | ---: |
| A4 | (2,3,3) | 24 | 0 |
| S4 | (2,3,4) | 48 | 0 |
| A5 | (2,3,5) | 120 | 0 |
| C6 | (2,3,6) | 12 | 1 |
| PSL(2,7), Klein quartic | (2,3,7) | 336 | 3 |
| A6, smooth Wiman sextic | (2,4,5) | 720 | 10 |
| PSL(2,8), Fricke–Macbeath surface | (2,3,7) | 1,008 | 7 |
| M11 | (2,4,11) | 15,840 | 631 |

Run `python3 verify.py` in this extracted directory to check every included file's
SHA-256 hash and the consistency of the reported model certificates. This quick
check checks the archived reports; it does not rerun the geometric constructions.

`course-update-20260925/quotient-data/` contains the original group enumeration,
chamber identifications, and Euler characteristic certificates. Its generator and
test script can be rerun with standard Python 3 and Node.js:

```sh
python3 course-update-20260925/quotient-data/generate_quotients.py
node course-update-20260925/quotient-data/test_cut_net.js
node course-update-20260925/all-surfaces/test-fundamental-region.cjs
node course-update-20260925/surface-embedding/test-sphere-torus.js
```

The fundamental-region test verifies the developed Euclidean and hyperbolic
regions used at the start of gluing: every original chamber occurs once,
actual covering adjacencies are joined, the boundary is a single simple cycle,
Euler characteristic is one, all projected triangles have positive area, and
their areas sum to the boundary area. The reflection permutations satisfy the
exact Coxeter relations. Hyperbolic regions use the Klein disc; the spherical
cases retain a topological cut disk. The earlier `cut-net.js` tree-cut disk is
also included as a combinatorial certificate and as the spherical layout.

The Klein and Macbeath source models have exact rational intersection certificates
and explicit side-labelled chamber correspondences. See their separate READMEs
for primary sources, attribution, numerical-data hashes, and commands. Their
builders require only standard Python; the Macbeath builder also uses the included
Klein intersection checker.

The current Klein, A6, Macbeath, and M11 displays use area-redistributed handle embeddings. The earlier named polyhedra remain as reference models. The broad-handle construction preserves a barycentric source chart for every rendering triangle; it changes display geometry while retaining every original chamber and its exact neighbors.

`AREA-REDISTRIBUTION.md` describes the positive-area optimization. `BALANCED-TUBES.md` describes variable radii, routing, and compact height placement. `CONSTRUCTION.md` and `TUBE-GEOMETRY.md` document the underlying cut and collar construction and the earlier unbalanced models.

The independent `*-balanced-tubes-independent-verification.json` reports check all source-chamber disks and local triangle intersections. The `*-balanced-tubes-area-audit.json` reports check planar orientation, unchanged source charts, containment of every nonplanar rendering triangle in a tube capsule, and separation of every pair of different handles. They also record area and screen-size measurements. These geometric checks supplement the exact quotient neighbor table and Euler characteristic; topology alone does not establish an embedding.

The exact optimized planar coordinates are in `balanced-planar-layouts.json.gz`. They can be restored onto a regenerated cut surface without rerunning floating-point optimization. A SHA-256 signature verifies that its chamber charts and hole pairings are identical. For example, from `course-update-20260925/all-surfaces/`:

```sh
python cut_to_planar.py klein
python balanced_layout.py klein-planar.json klein-planar-area.json
node tube-routing-balanced.js klein-planar-area.json klein-balanced-tubes.json
python verify_patch_embedding.py klein-balanced-tubes.json
python audit-balanced-geometry.py klein-balanced-tubes.json --planar klein-planar-area.json klein-planar.json
```

Use `--tree-cycles` when generating the A6 cut. For M11, pass the included `m11-balanced-routes.json` as the third builder argument. The graph is only a route-search aid; independent capsule distance checks certify the actual geometry. Regenerating and checking the genus-631 model takes substantial memory and time. The pinned Python dependencies are in `requirements.txt`; Node.js needs `DecompressionStream` support for the browser-adapter test.

`GENERATED-MODEL-HASHES.json` records the exact generated model JSON files.
The large generated balanced model JSON files are omitted from this compact source archive.
The final browser assets can be copied from the complete offline application or
downloaded, with size and SHA-256 checks, by running:

```sh
python3 fetch_web_assets.py
node course-update-20260925/all-surfaces/test-refined-model.cjs klein a6 macbeath m11
```

The download helper writes only into the extracted archive's
`github-homepage/triangle-quotients/surface-data/` directory. The second command
checks every drawing triangle's source-chart sample, both copies of every
original edge, and sampled chamber-walk segments using the actual browser model
adapter. It requires a Node.js version with `DecompressionStream` support.

The displayed Euclidean geometry represents the glued topological surface.
Its lengths and angles do not reproduce the intrinsic triangle metric. The
Riemann surface structure comes from the original spherical, Euclidean, or
hyperbolic triangles and their gluing data.
