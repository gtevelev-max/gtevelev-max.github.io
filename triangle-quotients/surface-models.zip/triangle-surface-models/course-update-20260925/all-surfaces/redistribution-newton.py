#!/usr/bin/env python3
"""Projected-Newton positive-area redistribution, preserving all charts."""
import json,sys,os,time
import numpy as np
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import spsolve

def optimize(data,iterations=100,shape=.003,capfraction=.8):
 n=len(data['positions']);outer=np.array(data['outerFacePatch']['vertices']);active=np.ones(n,bool);active[outer]=False
 faces=[p['vertices'] for p in data['patches']];nb=len(faces);T=[(1-capfraction)/nb]*nb;theta=[np.pi/3]*nb
 for h in data['holes']:
  vs=h['vertices'];m=len(vs);c=h['centerVertex'];faces.extend([[c,vs[(i+1)%m],vs[i]] for i in range(m)]);T.extend([capfraction/(len(data['holes'])*m)]*m);theta.extend([2*np.pi/m]*m)
 F=np.array(faces,np.int32);T=np.array(T);cost=np.cos(theta);sint=np.sin(theta)
 p=np.array(data['positions'],float);p-=p[outer[0]];p/=np.ptp(p,axis=0).max()
 if np.linalg.det(np.stack([p[F[0,1]]-p[F[0,0]],p[F[0,2]]-p[F[0,0]]]))<0:p[:,1]*=-1
 nF=len(F);x=p[active].ravel();fixed=p.copy();idx=np.full(n,-1);idx[active]=np.arange(sum(active));vid=np.repeat(idx[F]*2,2,axis=1)+np.tile([0,1],3);free=np.repeat(active,2)
 rows=np.repeat(vid,6,axis=1).ravel();cols=np.tile(vid,(1,6)).ravel();keep=(rows>=0)&(cols>=0)
 # Edge coordinates u=(p1-p0,p2-p0).
 B=np.array([[-1,0,1,0,0,0],[0,-1,0,1,0,0],[-1,0,0,0,1,0],[0,-1,0,0,0,1.]])
 HA=np.array([[0,0,0,1],[0,0,-1,0],[0,-1,0,0],[1,0,0,0.]])
 HN=np.broadcast_to(np.eye(4),(nF,4,4)).copy();HN[:,0,2]=HN[:,2,0]=-cost;HN[:,1,3]=HN[:,3,1]=-cost;HN*=2/sint[:,None,None]
 def unpack(x):
  p=fixed.copy();p[active]=x.reshape(-1,2);return p
 def area(p):
  a=p[F[:,1]]-p[F[:,0]];b=p[F[:,2]]-p[F[:,0]];return a[:,0]*b[:,1]-a[:,1]*b[:,0],a,b
 def fun(x,hessian=False):
  p=unpack(x);A,a,b=area(p)
  if min(A)<=0:return np.inf,None,None
  N=np.sum(a*a+b*b-2*cost[:,None]*a*b,axis=1)/sint
  en=np.sum(T*(-np.log(A)+shape*N/A))
  gA=np.c_[b[:,1],-b[:,0],-a[:,1],a[:,0]];gN=2*np.c_[a-cost[:,None]*b,b-cost[:,None]*a]/sint[:,None]
  ca=-T*(1/A+shape*N/A**2);cn=T*shape/A
  gu=ca[:,None]*gA+cn[:,None]*gN;gf=gu@B;grad=np.zeros(n*2)
  ids=(np.repeat(F*2,2,axis=1)+np.tile([0,1],3)).ravel();grad+=np.bincount(ids,weights=gf.ravel(),minlength=n*2)
  if not hessian:return en,grad[free],None
  H=(T/A**2+2*shape*T*N/A**3)[:,None,None]*gA[:,:,None]*gA[:,None,:]
  H-= (shape*T/A**2)[:,None,None]*(gA[:,:,None]*gN[:,None,:]+gN[:,:,None]*gA[:,None,:])
  H+=ca[:,None,None]*HA+cn[:,None,None]*HN
  vals,vec=np.linalg.eigh(H); vals=np.maximum(vals,1e-6*T[:,None]/A[:,None]);H=(vec*vals[:,None,:])@np.swapaxes(vec,1,2)
  Hg=np.einsum('ij,fjk,kl->fil',B.T,H,B,optimize=True)
  S=coo_matrix((Hg.ravel()[keep],(rows[keep],cols[keep])),shape=(len(x),len(x))).tocsc()
  return en,grad[free],S
 def stepbound(x,d):
  p=unpack(x);dp=np.zeros((n,2));dp[active]=d.reshape(-1,2);A,a,b=area(p);D,da,db=area(dp);C=a[:,0]*db[:,1]+da[:,0]*b[:,1]-a[:,1]*db[:,0]-da[:,1]*b[:,0]
  disc=C*C-4*D*A;v=disc>0;q=-.5*(C[v]+np.copysign(np.sqrt(disc[v]),C[v]));roots=np.r_[np.divide(q,D[v],out=np.full(len(q),np.inf),where=D[v]!=0),np.divide(A[v],q,out=np.full(len(q),np.inf),where=q!=0)];roots=roots[roots>0]
  return min(1.,.8*min(roots,default=np.inf))
 def report(k,e,g):
  p=unpack(x);A,_,_=area(p);offset=nb;aa=[];rad=[]
  for h in data['holes']:
   m=len(h['vertices']);aa.append(float(sum(A[offset:offset+m])/2));offset+=m;vs=p[h['vertices']];c=p[h['centerVertex']];d=np.roll(vs,-1,axis=0)-vs;t=np.clip(np.sum((c-vs)*d,axis=1)/np.sum(d*d,axis=1),0,1);rad.append(float(np.min(np.linalg.norm(vs+t[:,None]*d-c,axis=1))))
  print('newton',k,'energy',e,'gradient',np.linalg.norm(g),'holeclearance',min(rad),np.median(rad),max(rad),'holearea',min(aa),np.median(aa),max(aa),flush=True)
  return dict(minimumHoleClearance=min(rad),medianHoleClearance=float(np.median(rad)),maximumHoleClearance=max(rad),minimumHoleArea=min(aa),medianHoleArea=float(np.median(aa)),maximumHoleArea=max(aa),minimumTriangleArea=float(min(A)/2),span=float(np.ptp(p,axis=0).max()),energy=e)
 for k in range(iterations):
  e,g,H=fun(x,True);r=report(k,e,g)
  if os.environ.get('AREA_CHECKPOINT'):
   dd=dict(data);dd['positions']=unpack(x).tolist();dd['areaRedistribution']=r
   for h in dd['holes']:h['center']=dd['positions'][h['centerVertex']]
   json.dump(dd,open(os.environ['AREA_CHECKPOINT'],'w'),separators=(',',':'))
  d=spsolve(H,-g);dg=np.dot(d,g);assert dg<0;step=stepbound(x,d)
  for search in range(40):
   xe=x+step*d;ee,gg,_=fun(xe)
   if ee<=e+1e-4*step*dg:break
   step*=.5
  else:raise ValueError('line search failed')
  x=xe
  if np.linalg.norm(step*d)<1e-11:break
 data['positions']=unpack(x).tolist()
 for h in data['holes']:h['center']=data['positions'][h['centerVertex']]
 data['areaRedistribution']=report(k+1,ee,gg);return data
if __name__=='__main__':
 data=json.load(open(sys.argv[1]));out=optimize(data,int(sys.argv[3]) if len(sys.argv)>3 else 100,float(os.environ.get('AREA_SHAPE_WEIGHT',.003)));json.dump(out,open(sys.argv[2],'w'),separators=(',',':'))
