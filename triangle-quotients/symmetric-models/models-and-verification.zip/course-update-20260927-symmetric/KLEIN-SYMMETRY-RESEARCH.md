# Klein quartic: maximal visible rotational symmetry

## Recommendation

Use the existing Schulte–Wills embedded Klein map as the mathematical starting point. Its visible proper rotation group is the tetrahedral group A4 of order 12. Replace the current planar-base-and-tubes display with this compact tetrahedral shape. Optional rounding should deform its existing chamber charts equivariantly and undergo a new intersection check; it must not replace the quotient triangulation with an unrelated genus-three mesh.

The three handles are distributed around the tetrahedral shape rather than standing above a planar base. The familiar smooth “tetrus” is topologically the boundary of a thickened tetrahedral graph: six graph edges minus four graph vertices plus one gives genus three. This description explains the shape, but the actual chamber correspondence still comes from the existing verified Schulte–Wills data.

## What “maximal” means here

Matthias Goerner's thesis, §2.12.3, printed p.147 (PDF page159), explicitly identifies the tetrahedral rotation group as maximal both by inclusion and by order among subgroups of the orientation-preserving Klein-map automorphism group that can be realized by an embedding in ordinary Euclidean three-space. Its table in §2.13, printed pp.154–155, distinguishes possible mappings, immersions, and embeddings. The octahedral rotation group of order 24 admits an immersion but not an embedding. This is a proven obstruction, not merely a claim about the best available coordinates. The relevant notion is visible **proper rotations preserving the marked regular map**; this note does not claim a separate maximality result for arbitrary orientation-reversing Euclidean symmetries. [Goerner, thesis](https://math.berkeley.edu/~matthias/research/matthias_goerner_thesis_print.pdf#page=159)

The intrinsic orientation-preserving automorphism group remains PSL(2,7), order 168. Consequently, a maximally symmetric embedded model displays 12 of those automorphisms as ordinary rotations; the remaining symmetries are available through the quotient permutations and chamber walks, rather than rigid motions of the model.

Scholl, Schürmann, and Wills describe the embedded tetrahedral realization and contrast it with the self-intersecting octahedral realization. Their paper also relates these models to Ferguson's smooth “Eightfold Way.” [Polyhedral models of Felix Klein's quartic](https://math.ucr.edu/home/baez/klein_quartic_scholl.pdf)

## Existing coordinates and exact triangulation

The numerical source is already local:

- `../course-update-20260925/surface-embedding/klein-polyhedron.json`: 24 integral vertices, 84 edges, 56 triangular faces.
- `../course-update-20260925/surface-embedding/klein-embedding.json`: 164 vertices indexed by the actual quotient vertex IDs; 336 chambers after barycentric subdivision.
- `../course-update-20260925/surface-embedding/build_klein_embedding.py`: exact rational triangle-intersection checker and side-labelled chamber-graph correspondence.

The existing checker tests all 56,280 pairs of the 336 chamber triangles, including coplanar overlaps and excess contacts at shared vertices or edges. The original source of the integer coordinate/incidence data is [David McCooey's Schulte–Wills model](https://dmccooey.com/polyhedra/KleinDual.html); the original construction is [Schulte and Wills (1985)](https://doi.org/10.1112/jlms/s2-32.3.539).

An independent enumeration in this task finds twelve signed coordinate permutations preserving the vertex set and every face, all with determinant +1. Explicitly these are cyclic permutations of the coordinates composed with an even number of sign changes. Convenient generators are `(x,y,z) → (y,z,x)` and `(x,y,z) → (x,−y,−z)`. The chamber vertex types remain unchanged under this action.

## Rounded prototype and its limits

`prototype-klein-rounded.py` refines each original chamber into four patches per level and carries its exact barycentric source chart throughout. It applies a damped version of Loop's triangular subdivision: old vertices move a fraction of the usual weighted averaging step, and edge midpoints move the same fraction toward Loop's 3/8–3/8–1/8–1/8 stencil. The nonrational cosine-derived vertex weights are replaced by explicitly reproducible rational weights. The linear operations commute with all twelve tetrahedral rotations; the program checks that equality exactly on every output vertex.

The full-strength first step fails: an exact test finds an excess intersection between drawing triangles 29 and 51. Thus it is unsafe to assume that a standard smoothing scheme preserves this embedding. The damped first step with strength 1/4 passes all 902,496 exact rational triangle-pair checks, has 668 vertices and 1,344 drawing triangles, and retains all 336 original chambers. It is a finite, modestly rounded model, not a claim about a smooth subdivision limit.

Séquin's primary paper shows smooth tetrahedral Klein models, but explains that choosing a heptagonal control mesh can produce wrinkled subdivision surfaces. Its alternative quadrilateral control mesh needs a separate map of the Klein tiling. This supports using a smooth model only when its actual chamber correspondence is retained. [Séquin, Patterns on the Genus-3 Klein Quartic, §9](https://graphics.berkeley.edu/papers/Sequin-POT-2006-07/Sequin-POT-2006-07.pdf)

The underlying subdivision reference is [Charles Loop, Smooth Subdivision Surfaces Based on Triangles (1987)](https://www.microsoft.com/en-us/research/publication/smooth-subdivision-surfaces-based-on-triangles/). No claim of intersection preservation follows from the subdivision rule itself.

Reproduce the conservative first prototype:

```sh
python3 course-update-20260927-symmetric/prototype-klein-rounded.py 1 1/4
```

Both levels have now passed, using dyadic coordinates on a grid of spacing 2^-32. Those rational positions are exactly representable in Float64, so the intersection certificate applies to the actual numerical vertices in the JSON rather than a nearby idealization.

| Model | Vertices | Drawing triangles | Exact triangle-pair checks | Extra intersections |
| --- | ---: | ---: | ---: | ---: |
| `klein-rounded-level1.json` | 668 | 1,344 | 902,496 | 0 |
| `klein-rounded-level2.json` | 2,684 | 5,376 | 14,448,000 | 0 |

Use level 2 for the comparison viewer; level 1 remains a smaller fallback. Both outputs include numerical and exact rational positions, every source-labelled patch, all twelve symmetry permutations, and verification counts. The two-level intersection audit took about 79 seconds.

The separate `verify-klein-rounded-charts.py` audit checks all 336 source chambers as disks, exact source-chart area and continuity, the 1,008/2,016 subdivided original-neighbor segments, and all twelve geometric actions commuting with the original side-labelled chamber adjacencies. Results and model SHA-256 hashes are in `klein-rounded-chart-verification.json`.

```sh
python3 course-update-20260927-symmetric/prototype-klein-rounded.py 2 1/4
python3 course-update-20260927-symmetric/verify-klein-rounded-charts.py
```

`klein-rounded-preview.png` is an orthographic scientific preview with uniform matte shading and only original chamber boundaries. The extra drawing-subdivision edges are omitted. `render-klein-preview.py` reproduces it using NumPy and Pillow.

## Integration requirements

The existing coarse model can immediately use the ordinary `QuotientSurfaceView` path and `KLEIN_EMBEDDING` once the generic Klein tube asset stops overriding it. For a rounded mesh, keep `patches[].chamber`, `patches[].bary`, and shared vertex IDs, and reuse the source-chart morph and gallery machinery.

The current refined-model adapter assumes every asset ends with a three-facet underside and has a list of tube ranges. That assumption does not apply to this model: rounded Klein needs neutral component classification, no underside cap, and no attachment controls. Do not label its last three subdivision patches as a cap. The appropriate classroom controls would show the 336 chambers, optionally the 56 coarse triangles or 24 dual heptagons, and demonstrate the order-three and order-two tetrahedral rotations.

Before deployment, check the precise finite coordinates used by the browser, original-neighbor/source-chart continuity, Euler characteristic −4, all 336 chamber disks, the twelve geometric symmetry actions, and triangle intersections. Retain the original verified polyhedron as a fallback if stronger smoothing fails.
