#!/usr/bin/env python3
"""Independent display-area metrics and disjoint tube capsule certificates."""
import json, pathlib, sys, hashlib
import numpy as np

def point_segments(p,a,b):
    d=b-a
    t=np.clip(np.sum((p-a)*d,axis=-1)/np.sum(d*d,axis=-1),0,1)
    return np.linalg.norm(p-a-t[...,None]*d,axis=-1)

def segment_distances(a,b,c,d):
    # The unconstrained stationary point and the four boundary minima cover
    # the compact parameter square, including parallel/degenerate cases.
    u=b-a;v=d-c;w=a-c
    aa=np.sum(u*u,axis=-1);bb=np.sum(u*v,axis=-1);cc=np.sum(v*v,axis=-1)
    dd=np.sum(u*w,axis=-1);ee=np.sum(v*w,axis=-1);det=aa*cc-bb*bb
    s=np.divide(bb*ee-cc*dd,det,out=np.zeros_like(det),where=det>1e-25)
    t=np.divide(aa*ee-bb*dd,det,out=np.zeros_like(det),where=det>1e-25)
    interior=np.linalg.norm(w+s[...,None]*u-t[...,None]*v,axis=-1)
    interior=np.where((det>1e-25)&(s>=0)&(s<=1)&(t>=0)&(t<=1),interior,np.inf)
    return np.minimum.reduce([interior,point_segments(a,c,d),point_segments(b,c,d),point_segments(c,a,b),point_segments(d,a,b)])

def metrics(data):
    p=np.array(data['positions']);f=np.array([t['vertices'] for t in data['patches']]);ts=data['tubes']
    ar=np.linalg.norm(np.cross(p[f[:,1]]-p[f[:,0]],p[f[:,2]]-p[f[:,0]]),axis=1)/2
    span=np.ptp(p,axis=0);origin=(p.min(axis=0)+p.max(axis=0))/2
    radius=np.linalg.norm(p-origin,axis=1).max();radii=np.array([t['radius'] for t in ts])
    tube_area=sum(ar[t['patchStart']:t['patchEnd']].sum() for t in ts)
    ca=np.bincount([t['chamber'] for t in data['patches']],weights=ar)
    p32=((p-origin)/radius).astype(np.float32)
    collapsed=np.count_nonzero(np.linalg.norm(np.cross(p32[f[:,1]]-p32[f[:,0]],p32[f[:,2]]-p32[f[:,0]]),axis=1)==0)
    return {'vertices':len(p),'drawingTriangles':len(f),'originalChambers':data['originalTriangles'],'genus':data['genus'],
        'boundsSpan':span.tolist(),'boundingRadius':float(radius),'totalSurfaceArea':float(ar.sum()),
        'handleAreaFraction':float(tube_area/ar.sum()),'tubeRadiusQuantiles':np.quantile(radii,[0,.1,.5,.9,1]).tolist(),
        'tubeWidthPixelsIn500PixelDiameter':np.quantile(500*radii/radius,[0,.1,.5,.9,1]).tolist(),
        'chamberAreaQuantiles':np.quantile(ca,[0,.1,.5,.9,1]).tolist(),'collapsedFloat32Triangles':int(collapsed)}

def verify_planar(path,original):
    """Positive face orientations + simple outer boundary certify a plane map.

    The disk is obtained by restoring the fan caps. Its combinatorics are
    unchanged from the validated planar cut. Degree one on the outer triangle
    and positive degree on every face exclude overlapping interiors.
    """
    data=json.loads(pathlib.Path(path).read_text());old=json.loads(pathlib.Path(original).read_text())
    assert data['patches']==old['patches'] and data['outerFacePatch']==old['outerFacePatch']
    assert len(data['holes'])==len(old['holes'])==2*data['genus']
    for h,k in zip(data['holes'],old['holes']):
        assert {a:b for a,b in h.items() if a!='center'}=={a:b for a,b in k.items() if a!='center'}
        assert h['center']==data['positions'][h['centerVertex']]
    p=np.array(data['positions']);assert np.isfinite(p).all()
    faces=[f['vertices'] for f in data['patches']]
    for h in data['holes']:
        v=h['vertices'];faces.extend([[h['centerVertex'],v[(i+1)%len(v)],v[i]] for i in range(len(v))])
    f=np.array(faces);a=p[f[:,1]]-p[f[:,0]];b=p[f[:,2]]-p[f[:,0]]
    twice=a[:,0]*b[:,1]-a[:,1]*b[:,0]
    assert np.min(twice)>0 or np.max(twice)<0,'Planar face flip'
    edges={};vertices=set()
    for row in faces:
        vertices.update(row)
        for i,u in enumerate(row):
            v=row[(i+1)%3];key=tuple(sorted([u,v]));edges.setdefault(key,[]).append((u,v))
    boundary=[]
    for e,uses in edges.items():
        assert len(uses)<=2
        if len(uses)==2:assert uses[0]==uses[1][::-1]
        else:boundary.append(e)
    outer=data['outerFacePatch']['vertices'];expected={tuple(sorted([outer[i],outer[(i+1)%3]])) for i in range(3)}
    assert set(boundary)==expected and len(vertices)-len(edges)+len(faces)==1
    return {'sourcePatchesExactlyPreserved':True,'holeIdentificationsExactlyPreserved':True,'cappedDrawingDiskEuler':1,'outerBoundaryEdges':3,'positiveOrientedTriangles':len(faces),'minimumPlanarTriangleArea':float(np.min(np.abs(twice))/2),'allCoordinatesFinite':True}

def verify_capsules(data):
    p=np.array(data['positions']);fs=np.array([f['vertices'] for f in data['patches']]);ts=data['tubes']
    segments=[];ids=[];rs=[];max_excess=0
    for i,t in enumerate(ts):
        line=np.array(t['capsuleCenterline']);rad=t['radius'];a=line[:-1];b=line[1:]
        annuli=t['planarAnnulusPatchRanges'];mask=np.ones(t['patchEnd']-t['patchStart'],bool)
        for start,end in annuli:
            assert np.all(p[fs[start:end],2]==0),'Nonplanar annulus'
            mask[start-t['patchStart']:end-t['patchStart']]=False
        # Each nonplanar drawing triangle is contained in one convex capsule.
        tris=p[fs[t['patchStart']:t['patchEnd']][mask]]
        for lo in range(0,len(tris),10000):
            distances=point_segments(tris[lo:lo+10000,:,None,:],a,b)
            excess=distances.max(axis=1).min(axis=1)-rad
            max_excess=max(max_excess,float(excess.max(initial=0)))
            assert np.all(excess<rad*1e-8),(i,'Triangle leaves its certified capsule',float(excess.max()))
        segments.extend(zip(a,b));ids.extend([i]*len(a));rs.extend([rad]*len(a))
    segments=np.array(segments);ids=np.array(ids);rs=np.array(rs)
    min_margin=np.inf;min_ratio=np.inf;count=0;witness=None;exact_distances=0
    # AABB separation is a conservative capsule-separation certificate. It
    # avoids evaluating expensive segment distances for millions of remote
    # pairs. Inflate boxes slightly before using their positive gaps.
    boxlo=segments.min(axis=1)-rs[:,None]-1e-12
    boxhi=segments.max(axis=1)+rs[:,None]+1e-12
    for lo in range(0,len(segments),128):
        hi=min(lo+128,len(segments));a=segments[lo:hi,0,None,:];b=segments[lo:hi,1,None,:]
        valid=(ids[lo:hi,None]!=ids[None,:])&(np.arange(lo,hi)[:,None]>np.arange(len(segments))[None,:])
        sums=rs[lo:hi,None]+rs[None,:];count+=int(valid.sum())
        if len(segments)>2048:
            gap=np.maximum(boxlo[lo:hi,None,:]-boxhi[None,:,:],boxlo[None,:,:]-boxhi[lo:hi,None,:]).max(axis=-1)
            margin=np.where(valid,gap,np.inf)
            row,col=np.where(valid&(gap<=0))
            distances=segment_distances(segments[lo+row,0],segments[lo+row,1],segments[col,0],segments[col,1])
            margin[row,col]=distances-sums[row,col];exact_distances+=len(row)
            ratio=1+margin/sums
        else:
            distances=segment_distances(a,b,segments[None,:,0,:],segments[None,:,1,:])
            margin=np.where(valid,distances-sums,np.inf);ratio=np.where(valid,distances/sums,np.inf);exact_distances+=int(valid.sum())
        if margin.min()<min_margin:
            row,col=np.unravel_index(margin.argmin(),margin.shape);min_margin=float(margin[row,col]);witness=[int(ids[lo+row]),int(ids[col])]
        min_ratio=min(min_ratio,float(ratio.min()))
    assert min_margin>0,('Different tubes intersect their bounding capsules',witness,min_margin)
    return {'crossHandleSegmentPairs':count,'segmentDistanceEvaluations':exact_distances,'minimumCapsuleGap':min_margin,'gapIsConservativeLowerBound':len(segments)>2048,'minimumDistanceOverRadiiSum':min_ratio,'closestHandles':witness,'maximumCapsuleContainmentRoundoff':max_excess,'nonplanarTrianglesContainedInCapsules':True,'differentHandleCapsulesDisjoint':True}

if __name__=='__main__':
    path=pathlib.Path(sys.argv[1]);data=json.loads(path.read_text());out={'modelSHA256':hashlib.sha256(path.read_bytes()).hexdigest(),'metrics':metrics(data)}
    if '--metrics-only' not in sys.argv:out['capsuleVerification']=verify_capsules(data)
    if '--baseline' in sys.argv:
        other=pathlib.Path(sys.argv[sys.argv.index('--baseline')+1]);out['baseline']=metrics(json.loads(other.read_text()))
    if '--planar' in sys.argv:
        i=sys.argv.index('--planar');out['planarVerification']=verify_planar(sys.argv[i+1],sys.argv[i+2])
    dest=path.with_name(path.stem+'-area-audit.json');dest.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
