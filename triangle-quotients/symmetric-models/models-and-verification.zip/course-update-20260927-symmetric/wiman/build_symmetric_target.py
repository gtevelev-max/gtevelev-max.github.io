"""A D5-equivariant genus-ten target, not a replacement chamber embedding.

The surface is the rounded double of a disk with two aligned pentagons of
circular holes. The source Wiman chamber triangulation is NOT transported.
"""
from pathlib import Path
from collections import defaultdict, deque
import math, json

HERE = Path(__file__).resolve().parent
TAU = 2 * math.pi
HALF_SECTOR = math.pi / 5
ARC_STEPS, SIDE_STEPS, RADIAL_STEPS = 24, 12, 14
OUTER_RADIUS, HALF_THICKNESS, ROUNDING_WIDTH = 3., .30, .32
HOLES = [(r*math.cos(k*TAU/5), r*math.sin(k*TAU/5), a)
         for r,a in [(1.0,.34),(2.18,.43)] for k in range(5)]
points, point_ids, faces = [], {}, []

def vertex(p):
    key = tuple(round(float(x), 10) for x in p)
    if key not in point_ids:
        point_ids[key] = len(points)
        points.append(tuple(float(x) for x in p))
    return point_ids[key]

def triangle(a,b,c):
    p,q,r = (points[x] for x in (a,b,c))
    area = (q[0]-p[0])*(r[1]-p[1])-(q[1]-p[1])*(r[0]-p[0])
    assert area > 1e-12, area
    faces.append((a,b,c))

def quad(ps):
    ids = [vertex(p) for p in ps]
    mid = vertex(tuple(sum(p[k] for p in ps)/4 for k in range(2)))
    for a,b in zip(ids,ids[1:]+ids[:1]):
        triangle(a,b,mid)

def polar(r,t):
    return (r*math.cos(t),r*math.sin(t))

def rotate(p,theta):
    c,s=math.cos(theta),math.sin(theta)
    return (c*p[0]-s*p[1],s*p[0]+c*p[1])

def holed_band(lo,hi,center,hole_radius,theta):
    # Counterclockwise, shared arc and radial samples match adjacent patches.
    boundary = [polar(hi,-HALF_SECTOR+2*HALF_SECTOR*j/ARC_STEPS)
                for j in range(ARC_STEPS)]
    boundary += [polar(hi+(lo-hi)*j/SIDE_STEPS,HALF_SECTOR)
                 for j in range(SIDE_STEPS)]
    boundary += [polar(lo,HALF_SECTOR-2*HALF_SECTOR*j/ARC_STEPS)
                 for j in range(ARC_STEPS)]
    boundary += [polar(lo+(hi-lo)*j/SIDE_STEPS,-HALF_SECTOR)
                 for j in range(SIDE_STEPS)]
    rings=[]
    for k in range(RADIAL_STEPS+1):
        u=k/RADIAL_STEPS
        ring=[]
        for x,y in boundary:
            dx,dy=x-center,y
            length=math.hypot(dx,dy)
            radius=hole_radius+(length-hole_radius)*u
            ring.append(rotate((center+radius*dx/length,radius*dy/length),theta))
        rings.append(ring)
    for a,b in zip(rings,rings[1:]):
        for j in range(len(a)):
            n=(j+1)%len(a)
            quad([a[j],b[j],b[n],a[n]])

for k in range(5):
    theta=k*TAU/5
    holed_band(.4,1.6,1.,.34,theta)
    holed_band(1.6,3.,2.18,.43,theta)

# The unpunctured central disk shares its perimeter with all five inner bands.
center=vertex((0.,0.))
rings=[[polar(.4*k/5,-HALF_SECTOR+j*TAU/(5*ARC_STEPS))
        for j in range(5*ARC_STEPS)] for k in range(1,6)]
for j in range(len(rings[0])):
    triangle(center,vertex(rings[0][j]),vertex(rings[0][(j+1)%len(rings[0])]))
for a,b in zip(rings,rings[1:]):
    for j in range(len(a)):
        n=(j+1)%len(a)
        quad([a[j],b[j],b[n],a[n]])

planar_edges=defaultdict(list)
for f,tri in enumerate(faces):
    for i in range(3):
        planar_edges[tuple(sorted((tri[i],tri[(i+1)%3])))].append(f)
assert all(len(v) in (1,2) for v in planar_edges.values())
boundary_vertices={v for edge,fs in planar_edges.items() if len(fs)==1 for v in edge}
assert len(points)-len(planar_edges)+len(faces)==-9

positions=[]
top,bottom={},{}
for i,(x,y) in enumerate(points):
    distances=[OUTER_RADIUS-math.hypot(x,y),
               *(math.hypot(x-cx,y-cy)-a for cx,cy,a in HOLES)]
    d=min(distances)
    assert d > -1e-9, d
    # Product avoids a crease along the nearest-boundary Voronoi diagram.
    profile=1.
    for distance in distances:
        t=max(0,min(1,distance/ROUNDING_WIDTH))
        profile*=t*(2-t)
    z=HALF_THICKNESS*math.sqrt(profile)
    if i in boundary_vertices:
        assert d<1e-8
        z=0.
    top[i]=len(positions);positions.append([x,y,z])
    if i in boundary_vertices:
        bottom[i]=top[i]
    else:
        bottom[i]=len(positions);positions.append([x,y,-z])
triangles=[[top[a],top[b],top[c]] for a,b,c in faces]
triangles += [[bottom[c],bottom[b],bottom[a]] for a,b,c in faces]

edges=defaultdict(list)
links=defaultdict(list)
for f,tri in enumerate(triangles):
    for i in range(3):
        a,b,c=tri[i],tri[(i+1)%3],tri[(i+2)%3]
        edges[tuple(sorted((a,b)))].append((f,a,b))
        links[a].append((b,c))
assert all(len(v)==2 and v[0][1:]==v[1][1:][::-1] for v in edges.values())
for v,link in links.items():
    adjacency=defaultdict(set)
    for a,b in link:adjacency[a].add(b);adjacency[b].add(a)
    assert all(len(n)==2 for n in adjacency.values())
    seen={next(iter(adjacency))};queue=list(seen)
    for a in queue:
        for b in adjacency[a]:
            if b not in seen:seen.add(b);queue.append(b)
    assert len(seen)==len(adjacency)
euler=len(positions)-len(edges)+len(triangles)
assert euler==-18

# Geometric D5 generators and exact combinatorial face preservation.
index={tuple(round(x,9) for x in p):i for i,p in enumerate(positions)}
triangle_set={tuple(sorted(t)) for t in triangles}
generators=[]
for name,transform in [('r',lambda p:(*rotate(p[:2],TAU/5),p[2])),
                        ('s',lambda p:(p[0],-p[1],-p[2]))]:
    transformed=[transform(p) for p in positions]
    mapping=[index[tuple(round(x,9) for x in p)] for p in transformed]
    assert {tuple(sorted(mapping[i] for i in t)) for t in triangles}==triangle_set
    error=max(abs(p[k]-positions[mapping[i]][k])
              for i,p in enumerate(transformed) for k in range(3))
    assert error<1e-10
    generators.append({'name':name,'vertexPermutation':mapping,'maxCoordinateError':error})
R,S=(g['vertexPermutation'] for g in generators)
assert sum(i==j for i,j in enumerate(R))==2
assert sum(i==j for i,j in enumerate(S))==6
def comp(a,b):return tuple(a[x] for x in b)
identity=tuple(range(len(positions)))
rp=identity;rotations=[]
for _ in range(5):rotations.append(rp);rp=comp(R,rp)
assert rp==identity and comp(S,S)==identity
group=set(rotations+[comp(t,S) for t in rotations]);assert len(group)==10
assert comp(S,comp(R,S))==rotations[-1]

# Finite braid-orbit certificate for the D5 restriction of Wiman's action.
seed=(0,0,0,0,0,1)
seen={seed};queue=deque([seed])
while queue:
    a=queue.popleft()
    for j in range(5):
        b=a[:j]+(a[j+1],(2*a[j+1]-a[j])%5)+a[j+2:]
        if b not in seen:seen.add(b);queue.append(b)
assert len(seen)==5**5
assert all(sum((-1)**j*x for j,x in enumerate(a))%5==4 for a in seen)

verification={
    'vertices':len(positions),'edges':len(edges),'triangles':len(triangles),
    'euler':euler,'genus':10,'closedTwoManifold':True,'oriented':True,
    'vertexLinksAreSingleCircles':True,'rotationGroup':'D5','rotationGroupOrder':10,
    'geometricGeneratorErrors':[g['maxCoordinateError'] for g in generators],
    'halfTurnFixedPoints':sum(i==j for i,j in enumerate(S)),
    'orderFiveFixedPoints':sum(i==j for i,j in enumerate(R)),
    'quotientSignature':[0,2,2,2,2,2,2,5],
    'hurwitzOrbitSize':len(seen),'hurwitzStateSpaceSize':5**5,
    'embeddingArgument':'Two single-valued height graphs over a nonoverlapping punctured planar disk, joined only at their common boundary.',
    'originalChambersTransported':False,'originalChamberCount':720,
}
out={'id':'wiman-symmetric-target','name':'D5 symmetric Wiman target',
     'construction':'Rounded double of a disk with two aligned pentagons of holes',
     'status':'Research target only: no transport of the original 720 chambers',
     'positions':positions,'triangles':triangles,'symmetryGenerators':generators,
     'holes':HOLES,'verification':verification}
(HERE/'symmetric-target.json').write_text(json.dumps(out,separators=(',',':'))+'\n')
(HERE/'symmetric-target-verification.json').write_text(json.dumps(verification,indent=2)+'\n')
print(json.dumps(verification,indent=2))
