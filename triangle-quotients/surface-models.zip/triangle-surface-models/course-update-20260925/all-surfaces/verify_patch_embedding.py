"""Independent topology/source-chart and local 3D intersection checks."""
import collections
import itertools
import json
import math
import pathlib
import sys
from fractions import Fraction

def sub(a,b): return tuple(x-y for x,y in zip(a,b))
def dot(a,b): return sum(x*y for x,y in zip(a,b))
def cross(a,b): return (a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0])
def norm(a): return math.sqrt(dot(a,a))
def mix(a,b,t): return tuple(x+t*(y-x) for x,y in zip(a,b))

def plane_cut(poly,n,origin,eps):
    ds=[dot(n,sub(v,origin)) for v in poly]
    points=[v for v,d in zip(poly,ds) if abs(d)<=eps]
    for i in range(3):
        j=(i+1)%3
        if ds[i]*ds[j]<0:
            points.append(mix(poly[i],poly[j],ds[i]/(ds[i]-ds[j])))
    return points

def coplanar_overlap(a,b,n,eps):
    drop=max(range(3),key=lambda k:abs(n[k]));axes=[i for i in range(3) if i!=drop]
    def orient(p,q,r):return (q[axes[0]]-p[axes[0]])*(r[axes[1]]-p[axes[1]])-(q[axes[1]]-p[axes[1]])*(r[axes[0]]-p[axes[0]])
    sign=1 if orient(*b)>0 else -1;poly=a[:]
    for i in range(3):
        u,v=b[i],b[(i+1)%3];out=[]
        for j in range(len(poly)):
            p,q=poly[j-1],poly[j];d,e=sign*orient(u,v,p),sign*orient(u,v,q)
            if (d<0)!=(e<0):out.append(mix(p,q,d/(d-e)))
            if e>=0:out.append(q)
        poly=out
    return poly

def allowed(p,shared,eps):
    if not shared:return False
    if len(shared)==1:return norm(sub(p,shared[0]))<=eps
    u,v=shared;d=sub(v,u);t=dot(sub(p,u),d)/dot(d,d)
    return -eps<=t<=1+eps and norm(sub(p,mix(u,v,max(0,min(1,t)))))<=eps

def check_pair(a,b,n,m,shared,eps):
    line=cross(n,m)
    if norm(line)<1e-10:
        if abs(dot(n,sub(b[0],a[0])))>eps:return None
        pts=coplanar_overlap(a,b,n,eps)
        if not all(allowed(p,shared,eps*10) for p in pts):return ('coplanar',pts,shared)
    else:
        # Membership in the cutting plane requires a much tighter
        # tolerance than the final contact allowance: thin neighboring
        # sectors can have entire edges within the contact tolerance.
        ca,cb=plane_cut(a,m,b[0],eps*1e-5),plane_cut(b,n,a[0],eps*1e-5)
        if ca and cb:
            k=max(range(3),key=lambda k:abs(line[k]))
            lo=max(min(p[k] for p in ca),min(p[k] for p in cb));hi=min(max(p[k] for p in ca),max(p[k] for p in cb))
            if lo<=hi:
                if not shared and hi-lo>eps:return ('nonincident',lo,hi)
                if not shared:return None
                smin,smax=min(p[k] for p in shared),max(p[k] for p in shared)
                if lo<smin-eps*10 or hi>smax+eps*10:return ('excess',lo,hi,smin,smax)
    return None


def exact_pair_check(a,b,shared,eps):
    """Resolve ill-conditioned near-coplanar float candidates exactly.

    The input IEEE doubles are converted without rounding to rational
    numbers. Plane cuts and interval tests then have exact predicates;
    only the final permitted contact distance uses the model's tolerance.
    """
    a=[tuple(Fraction(x) for x in p) for p in a]
    b=[tuple(Fraction(x) for x in p) for p in b]
    n=cross(sub(a[1],a[0]),sub(a[2],a[0]));m=cross(sub(b[1],b[0]),sub(b[2],b[0]));line=cross(n,m)
    if line==(0,0,0):
        if dot(n,sub(b[0],a[0])):return None
        pts=coplanar_overlap(a,b,n,0)
        if not all(allowed(tuple(float(x) for x in p),shared,eps*10) for p in pts):return ('exact-coplanar',[[float(x) for x in p] for p in pts])
    else:
        ca,cb=plane_cut(a,m,b[0],0),plane_cut(b,n,a[0],0)
        if ca and cb:
            k=max(range(3),key=lambda k:abs(line[k]))
            lo=max(min(p[k] for p in ca),min(p[k] for p in cb));hi=min(max(p[k] for p in ca),max(p[k] for p in cb))
            if lo<=hi:
                if not shared:
                    if float(hi-lo)>eps:return ('exact-nonincident',float(lo),float(hi))
                else:
                    smin,smax=min(p[k] for p in shared),max(p[k] for p in shared)
                    if float(lo)<smin-eps*10 or float(hi)>smax+eps*10:return ('exact-excess',float(lo),float(hi),smin,smax)
    return None

def verify(path):
    d=json.loads(pathlib.Path(path).read_text());fs=d['patches'];vs=d['positions'];groups=collections.defaultdict(list)
    for i,f in enumerate(fs):groups[f['chamber']].append(i)
    global_edges=collections.defaultdict(list)
    for i,f in enumerate(fs):
        vv=f['vertices']
        for j in range(3):global_edges[tuple(sorted((vv[j],vv[(j+1)%3])))].append((i,vv[j],vv[(j+1)%3]))
    assert all(len(x)==2 and x[0][1:]==x[1][1:][::-1] for x in global_edges.values())
    assert len(vs)-len(global_edges)+len(fs)==2-2*d['genus']
    min_area=1;max_area_error=0
    for chamber,ids in groups.items():
        edges=collections.defaultdict(list);vertices=set();areas=[]
        for i in ids:
            f=fs[i];v=f['vertices'];vertices.update(v)
            for j in range(3):edges[tuple(sorted((v[j],v[(j+1)%3])))].append(i)
            a,b,c=f['bary'];areas.append((b[1]-a[1])*(c[2]-a[2])-(b[2]-a[2])*(c[1]-a[1]))
        assert len(vertices)-len(edges)+len(ids)==1,(chamber,'not disk Euler')
        assert min(areas)*max(areas)>0,(chamber,'source orientation')
        min_area=min(min_area,min(map(abs,areas)));max_area_error=max(max_area_error,abs(sum(map(abs,areas))-1))
        boundary=[e for e,ii in edges.items() if len(ii)==1];bgraph=collections.defaultdict(list)
        for a,b in boundary:bgraph[a].append(b);bgraph[b].append(a)
        assert all(len(x)==2 for x in bgraph.values())
        reached={boundary[0][0]};todo=list(reached)
        for a in todo:
            for b in bgraph[a]:
                if b not in reached:reached.add(b);todo.append(b)
        assert reached==set(bgraph),(chamber,'multiple boundary loops')
    assert len(groups)==d['originalTriangles'] and max_area_error<1e-9
    print('Topology and source charts:',len(groups),'disks, genus',d['genus'],'minimum source area',min_area,'maximum area error',max_area_error,flush=True)
    polys=[[tuple(vs[v]) for v in f['vertices']] for f in fs]
    normals=[];bounds=[]
    for t in polys:
        n=cross(sub(t[1],t[0]),sub(t[2],t[0]));n=tuple(x/norm(n) for x in n);normals.append(n)
        bounds.append([(min(p[k] for p in t),max(p[k] for p in t)) for k in range(3)])
    checked=0;failures=[];exact_resolutions=0
    for tube in d['tubes']:
        ids=range(tube['patchStart'],tube['patchEnd']);eps=tube['radius']*1e-7
        # Sweep-and-prune by x, then tight y/z bounds. Long stems remain
        # narrow in x/y, keeping the candidate set substantially smaller.
        ordered=sorted(ids,key=lambda i:bounds[i][0][0]);active=[]
        for i in ordered:
            active=[j for j in active if bounds[j][0][1]>=bounds[i][0][0]-eps]
            for j in active:
                if any(bounds[i][k][1]<bounds[j][k][0]-eps or bounds[j][k][1]<bounds[i][k][0]-eps for k in (1,2)):continue
                shared=[tuple(vs[v]) for v in set(fs[i]['vertices'])&set(fs[j]['vertices'])]
                error=check_pair(polys[i],polys[j],normals[i],normals[j],shared,eps)
                checked+=1
                if error:
                    exact_resolutions+=1
                    error=exact_pair_check(polys[i],polys[j],shared,eps)
                if error:
                    failures.append(dict(tube=tube['curve'],patches=[i,j],error=error))
                    if len(failures)>=20:break
            active.append(i)
            if len(failures)>=20:break
        if failures:break
    report=dict(originalChamberDisks=len(groups),genus=d['genus'],minimumSourceArea=min_area,maximumSourceAreaError=max_area_error,localTrianglePairCandidates=checked,exactPredicateResolutions=exact_resolutions,intersectionFailures=failures)
    out=pathlib.Path(path).with_name(pathlib.Path(path).stem+'-independent-verification.json');out.write_text(json.dumps(report,indent=2))
    print(json.dumps(report,indent=2),flush=True)
    assert not failures

if __name__=='__main__':verify(sys.argv[1])
