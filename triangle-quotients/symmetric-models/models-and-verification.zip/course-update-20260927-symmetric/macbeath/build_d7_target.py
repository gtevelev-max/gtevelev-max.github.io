#!/usr/bin/env python3
"""A D7-symmetric embedded genus-seven target, from Goerner's cyclic-cover construction.

This is a geometric target model, NOT a transport of the Macbeath chamber map.
No triangles in this mesh are labelled as the 1008 original chambers.
Requires Python standard library only.
"""
import json, math, hashlib
from collections import defaultdict, deque
from fractions import Fraction
from pathlib import Path
ROOT=Path(__file__).resolve().parent
N=7; NU=56; NV=32; R=2.; A=.6; D=2.; ZS=.36
TAU=2*math.pi
base=[]
for u in range(NU):
    for v in range(NV):
        a,b=TAU*u/NU,TAU*v/NV
        p=[D+(R+A*math.cos(b))*math.cos(a),(R+A*math.cos(b))*math.sin(a),ZS*A*math.sin(b)]
        if u==NU//2 and v in (NV//4,3*NV//4): p[:2]=[0.,0.]
        base.append(p)
def bi(u,v):return (u%NU)*NV+(v%NV)
def is_axis(i):return i in (bi(NU//2,NV//4),bi(NU//2,3*NV//4))
positions=[]; vertex_id={}; vertex_keys=[]
for i,p in enumerate(base):
    r=math.hypot(*p[:2]); angle=math.atan2(p[1],p[0])%TAU
    for j in range(1 if is_axis(i) else N):
        theta=(angle+TAU*j)/N
        # The holomorphic map (x+iy)^7 is the ambient branched cover.  Its
        # preimage of an offset torus is a compact seven-hole handlebody.
        q=[r**(1/N)*math.cos(theta),r**(1/N)*math.sin(theta),p[2]] if r else [0.,0.,p[2]]
        key=(i,j);vertex_id[key]=len(positions);vertex_keys.append(key);positions.append(q)
faces=[]; face_base=[]; upper=[]
for u in range(NU):
    for v in range(NV):
        for ids in ([bi(u,v),bi(u+1,v),bi(u+1,v+1)],[bi(u,v),bi(u+1,v+1),bi(u,v+1)]):
            angles=[None if is_axis(i) else math.atan2(base[i][1],base[i][0])%TAU for i in ids]
            nonzero=[a for a in angles if a is not None]
            # Choose the unique local argument interval shorter than pi.
            ref=nonzero[0]
            lifted=[None if a is None else a+TAU*round((ref-a)/TAU) for a in angles]
            if max(a for a in lifted if a is not None)-min(a for a in lifted if a is not None)>math.pi:
                raise ValueError('A base triangle crosses the branch point without a vertex there.')
            for j in range(N):
                tri=[]
                for i,a,b in zip(ids,angles,lifted):
                    k=0 if a is None else (j+round((b-a)/TAU))%N
                    tri.append(vertex_id[(i,k)])
                faces.append(tri);face_base.append(ids)
                upper.append(v<NV//2)

# Positive orientation inherited from the standard torus is outward.
# Verify exact mesh topology and geometric injectivity by planar projection:
# the top is a graph over a disk with seven holes, bottom is its mirror.
edges=defaultdict(list);neighbors=[set() for _ in positions]
for f,t in enumerate(faces):
    for a,b in zip(t,t[1:]+t[:1]):
        edges[tuple(sorted((a,b)))].append((f,a,b));neighbors[a].add(b);neighbors[b].add(a)
assert all(len(x)==2 and x[0][1:]==x[1][1:][::-1] for x in edges.values())
seen={0};q=deque([0])
while q:
    for w in neighbors[q.popleft()]:
        if w not in seen:seen.add(w);q.append(w)
assert len(seen)==len(positions)
chi=len(positions)-len(edges)+len(faces);assert chi==-12
min_area=1e100
for tri,top in zip(faces,upper):
    p,q,r=[positions[i] for i in tri]
    area=(q[0]-p[0])*(r[1]-p[1])-(q[1]-p[1])*(r[0]-p[0])
    # The top projects with positive orientation, and the bottom negative.
    assert area>0 if top else area<0
    min_area=min(min_area,abs(area)/2)
    assert all(p[2]>=-1e-15 if top else p[2]<=1e-15 for p in (p,q,r))
# Exact rational area signs, treating exported binary64 coordinates as rationals.
rat=[[Fraction(p[0]),Fraction(p[1])] for p in positions]
for tri,top in zip(faces,upper):
    p,q,r=[rat[i] for i in tri]
    area=(q[0]-p[0])*(r[1]-p[1])-(q[1]-p[1])*(r[0]-p[0])
    assert area>0 if top else area<0
# Parametric faces already have the outward orientation.

boundary_edges=[]
for pair,entries in edges.items():
    if upper[entries[0][0]]!=upper[entries[1][0]]:boundary_edges.append(pair)
boundary_neighbors=defaultdict(list)
for a,b in boundary_edges:boundary_neighbors[a].append(b);boundary_neighbors[b].append(a)
assert all(len(v)==2 for v in boundary_neighbors.values())
cycles=[];remaining=set(boundary_neighbors)
while remaining:
    start=min(remaining);cycle=[start];previous=None;v=start
    while True:
        w=next(w for w in boundary_neighbors[v] if w!=previous)
        if w==start:break
        cycle.append(w);previous,v=v,w
    remaining.difference_update(cycle);cycles.append(cycle)
assert len(cycles)==8
# All boundary curves are simple and pairwise disjoint.  Straight segment
# intersections are tested with exact rationals whenever bounding boxes meet.
def orient(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
def intersect(a,b,c,d):
    if max(min(a[0],b[0]),min(c[0],d[0]))>min(max(a[0],b[0]),max(c[0],d[0])):return False
    if max(min(a[1],b[1]),min(c[1],d[1]))>min(max(a[1],b[1]),max(c[1],d[1])):return False
    return orient(a,b,c)*orient(a,b,d)<=0 and orient(c,d,a)*orient(c,d,b)<=0
boundary_tests=0
for i,(a,b) in enumerate(boundary_edges):
    for c,d in boundary_edges[i+1:]:
        if {a,b}&{c,d}:continue
        # Float boxes are a fast conservative filter for exact stored vertices.
        pa,pb,pc,pd=[positions[v] for v in (a,b,c,d)]
        if max(min(pa[0],pb[0]),min(pc[0],pd[0]))>min(max(pa[0],pb[0]),max(pc[0],pd[0])):continue
        if max(min(pa[1],pb[1]),min(pc[1],pd[1]))>min(max(pa[1],pb[1]),max(pc[1],pd[1])):continue
        boundary_tests+=1;assert not intersect(rat[a],rat[b],rat[c],rat[d])

# Explicit combinatorial D7 generators: z-axis seventh turn and x-axis half turn.
rotation=[];halfturn=[]
for i,j in vertex_keys:
    rotation.append(vertex_id[(i,0 if is_axis(i) else (j+1)%N)])
    u,v=divmod(i,NV);other=bi(-u,-v)
    if is_axis(i):halfturn.append(vertex_id[(other,0)]);continue
    a=math.atan2(base[i][1],base[i][0])%TAU
    b=math.atan2(base[other][1],base[other][0])%TAU
    shift=round((-a-b)/TAU)
    halfturn.append(vertex_id[(other,(-j+shift)%N)])
face_sets={tuple(sorted(f)) for f in faces}
face_cycles={tuple(f[k:]+f[:k]) for f in faces for k in range(3)}
for perm in [rotation,halfturn]:
    assert all(tuple(perm[v] for v in f) in face_cycles for f in faces)
max_symmetry_error=0
for i,p in enumerate(positions):
    a=TAU/N;q=positions[rotation[i]]
    max_symmetry_error=max(max_symmetry_error,math.dist(q,[math.cos(a)*p[0]-math.sin(a)*p[1],math.sin(a)*p[0]+math.cos(a)*p[1],p[2]]))
    q=positions[halfturn[i]];max_symmetry_error=max(max_symmetry_error,math.dist(q,[p[0],-p[1],-p[2]]))
assert max_symmetry_error<1e-12
for i in range(len(positions)):
    j=i
    for _ in range(N):j=rotation[j]
    assert j==i and halfturn[halfturn[i]]==i
    assert rotation[halfturn[rotation[halfturn[i]]]]==i
fixed_rotation=sum(v==i for i,v in enumerate(rotation));fixed_halfturn=sum(v==i for i,v in enumerate(halfturn))
assert fixed_rotation==2 and fixed_halfturn==4
max_equation_error=0
for x,y,z in positions:
    w=complex(x,y)**7
    max_equation_error=max(max_equation_error,abs((abs(w-D)-R)**2+(z/ZS)**2-A*A))
assert max_equation_error<1e-12
out={
 'id':'macbeath-d7-target','title':'Fricke–Macbeath: maximal D7 spatial symmetry target',
 'status':'Geometric target. Transport of the 1008 original chambers is not yet supplied.',
 'positions':positions,'faces':faces,
 'symmetry':{'group':'D7','order':14,'rotationOrder':7,'rotation':rotation,'halfturn':halfturn},
 'construction':{'equation':'((hypot(Re((x+iy)^7)-2,Im((x+iy)^7))-2)^2+(z/0.36)^2)=0.6^2',
  'description':'Sevenfold cyclic branched cover of an offset torus. The axis meets the torus twice. The quotient torus has two order-seven branch points, giving genus seven by Riemann–Hurwitz.',
  'source':'https://math.berkeley.edu/~matthias/research/matthias_goerner_thesis_print.pdf#page=159'},
 'verification':{'vertices':len(positions),'edges':len(edges),'faces':len(faces),'euler':chi,'genus':7,
  'connected':True,'closedOrientedManifold':True,'upperAndLowerAreEmbeddedGraphs':True,
  'boundaryComponents':8,'minimumProjectedTriangleArea':min_area,
  'allProjectedAreaSignsCheckedExactly':True,'exactBoundaryIntersectionCandidates':boundary_tests,
  'extraneousBoundaryIntersections':0,'symmetryGeneratorsPreserveOrientedFaces':True,'dihedralRelationsVerified':True,
  'orderSevenFixedVertices':fixed_rotation,'halfturnFixedVertices':fixed_halfturn,
  'maxImplicitEquationError':max_equation_error,'maxSymmetryCoordinateError':max_symmetry_error,
  'originalChamberTransportIncluded':False}}
(ROOT/'macbeath-d7-target.json').write_text(json.dumps(out,separators=(',',':'))+'\n')
(ROOT/'macbeath-d7-target-certificate.json').write_text(json.dumps(out['verification'],indent=2)+'\n')
with (ROOT/'macbeath-d7-target.obj').open('w') as f:
    f.write('# D7 symmetric genus-7 target, not the original chamber triangulation\n')
    for p in positions:f.write('v '+' '.join(format(x,'.17g') for x in p)+'\n')
    for tri in faces:f.write('f '+' '.join(str(i+1) for i in tri)+'\n')
print(json.dumps(out['verification'],indent=2))
