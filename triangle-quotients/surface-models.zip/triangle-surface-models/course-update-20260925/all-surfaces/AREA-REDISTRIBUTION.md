# Redistributing area while preserving every chamber

The cut surface is a triangulated sphere with twice the genus many disks removed. Temporary fans cap these disks, and one original triangle becomes the outer face. The resulting capped disk is redrawn, without changing vertex IDs, triangle IDs, original chamber IDs, source barycentric coordinates, or boundary pairings.

`redistribution-planar.py` first computes a Euclidean circle packing. The three outer radii are fixed and Newton's method makes the angle sum at every interior vertex equal to 2π. Tangency determines an initial straight-edge planar drawing. This removes the extreme triangle shapes in the integer planar drawing, but it can still assign vastly different areas to different holes.

`redistribution-newton.py` then redistributes the planar area. It assigns 80 percent of the target area to the hole caps, divided equally among holes and then among each cap's fan triangles. The remaining 20 percent is divided among the original body triangles. The energy is a weighted negative logarithm of each triangle's doubled area, plus a scale-invariant shape penalty. A cap fan's reference triangles form a regular polygon; body triangles use equilateral references. The method projects each local Hessian to positive definiteness before solving the sparse Newton system.

Every trial displacement is limited by the first positive root of any triangle's signed-area quadratic. Backtracking then decreases the energy. Thus all triangles remain strictly positively oriented, and the outer triangle is fixed. These conditions, together with the unchanged triangulated-disk topology, make each resulting straight-edge map a global planar homeomorphism. Deleting the temporary cap fans again yields the same cut surface with larger, more evenly distributed holes. The tube construction subsequently joins precisely the same paired collar boundaries as before.

The earlier `redistribution-area.py` implements an alternative L-BFGS optimizer for the same energy. It was used for the initial A6 and Klein models. Projected Newton is substantially faster for the 69,072-vertex M11 planar mesh.

Verified runtime: Python 3.12, NumPy 2.5.3, SciPy 1.18.1. Requirements: Python 3, NumPy, SciPy. The circle-packing initial step and projected-Newton optimization are:

```sh
python redistribution-planar.py NAME-planar.json NAME-planar-balanced.json
python redistribution-newton.py NAME-planar-balanced.json NAME-planar-area.json 100
```

`AREA_SHAPE_WEIGHT` changes the shape penalty (default 0.003). `AREA_CHECKPOINT` optionally writes the current drawing after each Newton iteration. The output records minimum triangle area and minimum, median, and maximum hole clearances and hole areas. These conditioning checks supplement the independent final surface checks; they do not replace the edge-identification or triangle-intersection checks on the completed tubes.

## Produced layouts

- `a6-planar-area2.json`: circle packing, 3,000 ordinary L-BFGS steps, then 6,000 more L-BFGS steps. This is the initial accepted A6 balanced layout.
- `a6-planar-newton.json`: circle packing followed by 100 projected-Newton steps; an alternative A6 layout with even larger minimum hole clearance.
- `klein-planar-area.json`: circle packing followed by 6,000 L-BFGS steps with `AREA_PRECONDITION=1`.
- `klein-planar-rounded.json`: optional continuation of the preceding Klein layout, 80 Newton steps with `AREA_SHAPE_WEIGHT=.03`.
- `macbeath-planar-area.json`: circle packing followed by 150 projected-Newton steps.
- `m11-planar-newton.json`: circle packing followed by 61 projected-Newton steps. Stopped after every hole acquired substantial area and the median clearance stabilized; further iteration was not needed for the visibility improvement.

The chosen original cut data must be retained because there can be several mathematically valid cut systems. Regenerating `a6-planar.json` uses the `--tree-cycles` option of `cut_to_planar.py`; the other new layouts use its default homology-based cuts. `cut_to_planar.py` also requires NetworkX (see its separate license and requirements).

For the final M11 coordinates use `python redistribution-newton.py m11-planar-balanced.json m11-planar-newton.json 61`. For reproducible floating-point ordering, set `OPENBLAS_NUM_THREADS=1` and `OMP_NUM_THREADS=1` before running Python. Verification is independent of the optimizer: `python verify-planar-redraw.py NAME-planar.json NAME-planar-area.json NAME-planar-redistribution-verification.json` checks all oriented edges, the capped disk's Euler characteristic and simple outer boundary, unchanged source charts, strict face orientation, and area partition.
