#!/usr/bin/env python3
"""Verify the downloaded numerical surface models without third-party packages."""
import pathlib
import shutil
import subprocess
import sys
root=pathlib.Path(__file__).resolve().parent
node=shutil.which('node')
if not node:
    raise SystemExit('Node.js is required for the sphere, torus, and cut-net checks.')
for command in [
    [sys.executable,str(root/'surface-embedding/build_klein_embedding.py')],
    [node,str(root/'surface-embedding/test-sphere-torus.js')],
    [node,str(root/'quotient-data/test_cut_net.js')],
]:
    print('Running:', ' '.join(command),flush=True)
    subprocess.run(command,cwd=root,check=True)
print('All downloaded surface model checks passed.')
