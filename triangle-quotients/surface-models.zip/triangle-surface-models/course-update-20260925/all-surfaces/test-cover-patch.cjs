/* Mathematical checks for the cover → retained region animation.
 * Run from the Math 611 workspace with Node.js; no packages are required.
 */
const fs=require('fs'),path=require('path'),assert=require('assert');
const root=path.resolve(__dirname,'../..'),base=path.join(root,'github-homepage/triangle-quotients');
const M=require(path.join(base,'geometry.js')),N=require(path.join(base,'cut-net.js')),R=require(path.join(base,'fundamental-region.js')),C=require(path.join(base,'cover-patch.js'));
const area=p=>Math.abs((p[1][0]-p[0][0])*(p[2][1]-p[0][1])-(p[1][1]-p[0][1])*(p[2][0]-p[0][0]))/2;
const results=[];
for(const id of ['a4','s4','a5','torus','klein','a6','macbeath','m11']){
 const d=JSON.parse(fs.readFileSync(path.join(root,'course-update-20260925/quotient-data',id+'.json')));
 const g=M.makeGeometry(...d.signature),n=R.layout(d,g,M,N.build(d));if(n.region){n.boundary=n.region.boundary;n.seams=n.region.seams;n.treeEdges=n.region.internalEdges;}
 const c=C.build(d,g,M,n);assert.equal(c.verification.retainedChambers,d.counts.triangles);
 if(g.k!==1){
  assert(c.verification.maxRetainedCornerError<1e-9);
  for(const t of c.triangles){assert(t.points.flat().every(Number.isFinite));assert(area(t.points)>0);}
  const regionArea=Array.from({length:d.counts.triangles},(_,f)=>area(n.corners[f].map(k=>n.positions[k]))).reduce((a,b)=>a+b,0);
  const drawnArea=c.triangles.reduce((s,t)=>s+area(t.points),regionArea);
  if(g.k===-1){assert(drawnArea>Math.PI*.999);assert(drawnArea<Math.PI+1e-8);assert(c.triangles.every(t=>t.points.every(p=>Math.hypot(...p)<1)));}
  results.push({id,...c.verification,drawnArea});
 }else {assert(c.spherical);results.push({id,...c.verification,spherical:true});}
}
console.log(JSON.stringify({allPassed:true,results},null,2));
